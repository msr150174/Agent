<template>
  <div class="session-list">
    <div class="session-header">
      <div class="session-title">
        <span> 会话</span>
        <span class="session-count"> {{ filteredSessions.length }}</span>
      </div>
      <button class="create-btn" title="新建会话" @click="handleCreate">
        ＋
      </button>
    </div>
    <div class="search-box">
      <span class="search-icon"></span>
      <input
        v-model="searchText"
        type="text"
        class="search-input"
        placeholder="搜索会话…"
        @input="handleSearch" />
    </div>
    <div class="session-list-body">
      <div
        v-for="(item, index) in filteredSessions"
        :key="item.id"
        :class="
          Object.assign(
            { 'session-item': true },
            { active: item.id === activeId }
          )
        "
        @click="handleSelect(item)">
        <div class="session-item-main">
          <div class="session-name">
            {{ item.title }}
          </div>
          <div class="session-meta">
            <span class="session-tag"> {{ item.statusText }}</span>
            <span class="session-time"> {{ item.updatedAt }}</span>
          </div>
        </div>
      </div>
      <div v-if="filteredSessions.length === 0" class="empty-tip">暂无会话</div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref, computed } from 'vue';

  const __props = defineProps({
    sessions: {
      type: [Array],
      required: false,
      default: () => [
        {
          id: 's1',
          title: '我的职业兴趣探索',
          status: 'active',
          statusText: '进行中',
          updatedAt: '10:24'
        },
        {
          id: 's2',
          title: '新能源汽车行业前景',
          status: 'done',
          statusText: '已完成',
          updatedAt: '昨天'
        },
        {
          id: 's3',
          title: '简历优化建议',
          status: 'pending',
          statusText: '待处理',
          updatedAt: '周二'
        },
        {
          id: 's4',
          title: '机电一体化转岗规划',
          status: 'done',
          statusText: '已完成',
          updatedAt: '周一'
        }
      ]
    },
    activeId: {
      type: [String],
      required: false,
      default: 's1'
    }
  });
  const __emit = defineEmits(['search', 'select', 'create']);
  const __provider = useProvider({ id: '5r0c26ix', version: '1794454689560' });

  const searchText = ref('');
  const filteredSessions = computed(() => {
    const keyword = searchText.value.trim();
    if (!keyword) return __props.sessions;
    return __props.sessions.filter((item) => {
      return item.title.indexOf(keyword) > -1;
    });
  });
  const handleCreate = () => {
    __emit('create');
  };
  const handleSearch = () => {
    __emit('search', searchText.value);
  };
  const handleSelect = (item) => {
    __emit('select', item);
  }
</script>
<style lang="css" scoped>
  .session-list {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: #f8fafc;
    border-radius: 12px;
    overflow: hidden;
  }
  .session-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 14px 8px;
  }
  .session-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
  }
  .session-count {
    font-size: 11px;
    color: #2f6bff;
    background: #eef3fe;
    border-radius: 10px;
    padding: 1px 8px;
  }
  .create-btn {
    width: 26px;
    height: 26px;
    border: none;
    border-radius: 7px;
    background: #2f6bff;
    color: #fff;
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s ease;
  }
  .create-btn:hover {
    background: #1e56d6;
  }
  .search-box {
    position: relative;
    margin: 0 12px 8px;
  }
  .search-icon {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    width: 12px;
    height: 12px;
    border: 1.5px solid #9ca3af;
    border-radius: 50%;
    pointer-events: none;
  }
  .search-icon::after {
    content: '';
    position: absolute;
    right: -4px;
    bottom: -3px;
    width: 5px;
    height: 1.5px;
    background: #9ca3af;
    transform: rotate(45deg);
    border-radius: 2px;
  }
  .search-input {
    width: 100%;
    height: 32px;
    padding: 0 10px 0 30px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #fff;
    font-size: 12px;
    color: #1f2937;
    outline: none;
    transition:
      border-color 0.2s ease,
      box-shadow 0.2s ease;
    box-sizing: border-box;
  }
  .search-input:focus {
    border-color: #2f6bff;
    box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.1);
  }
  .search-input::placeholder {
    color: #9ca3af;
  }
  .session-list-body {
    flex: 1;
    overflow-y: auto;
    padding: 0 8px 12px;
  }
  .session-item {
    padding: 10px 12px;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 4px;
    transition: background 0.2s ease;
  }
  .session-item:hover {
    background: #eef2f7;
  }
  .session-item.active {
    background: #eef3fe;
  }
  .session-item-main {
    min-width: 0;
  }
  .session-name {
    font-size: 13px;
    font-weight: 500;
    color: #1f2937;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .session-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 5px;
  }
  .session-tag {
    font-size: 10px;
    padding: 1px 6px;
    border-radius: 4px;
    line-height: 1.4;
  }
  .tag-active {
    color: #2f6bff;
    background: #e0e7ff;
  }
  .tag-done {
    color: #16a34a;
    background: #dcfce7;
  }
  .tag-pending {
    color: #d97706;
    background: #fef3c7;
  }
  .session-time {
    font-size: 10px;
    color: #9ca3af;
  }
  .empty-tip {
    text-align: center;
    padding: 24px 0;
    font-size: 12px;
    color: #9ca3af;
  }
</style>
