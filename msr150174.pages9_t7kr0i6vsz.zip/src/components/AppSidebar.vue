<template>
  <aside class="app-sidebar">
    <div class="brand">
      <div class="brand-logo">AI</div>
      <div class="brand-info">
        <div class="brand-name">路书工作台</div>
        <div class="brand-sub">职业规划智能体</div>
      </div>
    </div>
    <nav class="nav">
      <div
        v-for="(item, index) in navItems"
        :key="item.route"
        :class="
          Object.assign({ 'nav-item': true }, { active: isActive(item.route) })
        "
        @click="handleNav(item.route)">
        <component :is="item.icon" class="nav-icon"></component>
        <span> {{ item.label }}</span>
      </div>
    </nav>
    <div class="current-user">
      <div class="user-avatar">
        {{ currentUser.avatarText }}
      </div>
      <div class="user-info">
        <div class="user-name">
          {{ currentUser.name }}
        </div>
        <div class="user-role">
          {{ currentUser.role }}
        </div>
      </div>
      <div class="logout-btn" title="退出登录" @click="handleLogout">
        <SwitchButton class="logout-icon"></SwitchButton>
      </div>
    </div>
  </aside>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref, reactive } from 'vue';
  import {
    SwitchButton,
    ChatDotRound,
    Collection,
    DataAnalysis,
    Document,
    Setting,
    User
  } from '@vtj/icons';
  import { useRoute, useRouter } from 'vue-router';

  const __provider = useProvider({ id: '2r0c0a38', version: '1794454171807' });

  const __route = useRoute();
  const __router = useRouter();
  const navItems = ref([
    { label: '对话工作台', route: '/page/chat-workspace', icon: ChatDotRound },
    { label: '知识库', route: '/page/knowledge-base', icon: Collection },
    { label: '职业库', route: '/page/career-library', icon: DataAnalysis },
    { label: '成长计划', route: '/page/growth-plan', icon: Document },
    { label: '调用日志', route: '/page/call-log', icon: Setting },
    { label: '知识库管理', route: '/page/kb-manager', icon: User }
  ]);
  const currentUser = reactive({
    name: '张老师',
    role: '教师 / 管理员',
    avatarText: '张'
  });
  const isActive = (route) => {
    return __route.path === route;
  };
  const handleNav = (route) => {
    if (__route.path !== route) {
      __router.push(route);
    }
  };
  const handleLogout = () => {
    __router.push('/page/login');
  }
</script>
<style lang="css" scoped>
  .app-sidebar {
    width: 264px;
    height: 100%;
    background: #ffffff;
    border-right: 1px solid #e5e7eb;
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
  }
  .brand {
    height: 64px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    border-bottom: 1px solid #f0f1f3;
    gap: 12px;
  }
  .brand-logo {
    width: 36px;
    height: 36px;
    background: #2f6bff;
    color: #fff;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
  }
  .brand-name {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    line-height: 1.2;
  }
  .brand-sub {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 2px;
  }
  .nav {
    flex: 1;
    padding: 12px 8px;
    overflow-y: auto;
  }
  .nav-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    margin-bottom: 4px;
    border-radius: 8px;
    color: #4b5563;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  .nav-item:hover {
    background: #f5f7fa;
    color: #1f2937;
  }
  .nav-item.active {
    background: #eef3fe;
    color: #2f6bff;
    font-weight: 500;
  }
  .nav-icon {
    width: 18px;
    height: 18px;
  }
  .current-user {
    height: 68px;
    border-top: 1px solid #f0f1f3;
    display: flex;
    align-items: center;
    padding: 0 16px;
    gap: 10px;
  }
  .user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: #e0e7ff;
    color: #2f6bff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 14px;
    flex-shrink: 0;
  }
  .user-info {
    flex: 1;
    min-width: 0;
  }
  .user-name {
    font-size: 14px;
    font-weight: 500;
    color: #1f2937;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .user-role {
    font-size: 11px;
    color: #9ca3af;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .logout-btn {
    width: 28px;
    height: 28px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #9ca3af;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  .logout-btn:hover {
    background: #f5f7fa;
    color: #ef4444;
  }
  .logout-icon {
    width: 16px;
    height: 16px;
  }
</style>
