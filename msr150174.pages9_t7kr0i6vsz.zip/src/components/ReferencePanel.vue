<template>
  <div class="reference-panel">
    <div class="tab-header">
      <button
        v-for="(tab, index) in tabs"
        :key="tab.key"
        :class="
          Object.assign({ 'tab-btn': true }, { active: activeTab === tab.key })
        "
        @click="handleTabChange(tab.key)">
        {{ tab.label }}
      </button>
    </div>
    <div class="tab-content">
      <div v-if="activeTab === 'references'" class="panel-section">
        <div class="section-title">引用来源</div>
        <div v-if="references.length" class="ref-list">
          <div
            v-for="(item, index) in references"
            :key="item.id"
            class="ref-card"
            @click="handleOpen(item.url)">
            <div class="ref-title">
              {{ item.title }}
            </div>
            <div class="ref-excerpt">
              {{ item.excerpt }}
            </div>
            <div class="ref-meta">
              <span>
                <span> {{ item.source }}</span>
                <span> ·</span>
                <span> {{ item.date }}</span></span
              >
            </div>
          </div>
        </div>
        <div v-else class="empty">暂无引用</div>
      </div>
      <div v-else-if="activeTab === 'knowledge'" class="panel-section">
        <div class="section-title">知识库</div>
        <div v-if="knowledgeList.length" class="kb-list">
          <div
            v-for="(kb, index) in knowledgeList"
            :key="kb.id"
            class="kb-card">
            <div class="kb-top">
              <span class="kb-name"> {{ kb.name }}</span>
              <span class="kb-badge">
                <span>
                  <span> {{ kb.count }}</span>
                  <span> 篇</span></span
                ></span
              >
            </div>
            <div class="kb-desc">
              {{ kb.description }}
            </div>
          </div>
        </div>
        <div v-else class="empty">暂无知识库</div>
      </div>
      <div v-else-if="activeTab === 'profile'" class="panel-section">
        <div class="section-title">学生画像</div>
        <div v-if="profile" class="profile-card">
          <div class="profile-header">
            <div class="profile-avatar">
              {{ profile.name ? profile.name.slice(0, 1) : '学' }}
            </div>
            <div class="profile-info">
              <div class="profile-name">
                {{ profile.name }}
              </div>
              <div class="profile-meta">
                <span>
                  <span> {{ profile.major }}</span>
                  <span> ·</span>
                  <span> {{ profile.grade }}</span></span
                >
              </div>
            </div>
          </div>
          <div v-if="profile.tags && profile.tags.length" class="profile-tags">
            <span
              v-for="(tag, index) in profile.tags"
              :key="tag"
              class="profile-tag">
              {{ tag }}</span
            >
          </div>
          <div class="profile-section">
            <div class="profile-label">职业兴趣</div>
            <div class="profile-value">
              {{ profile.interest }}
            </div>
          </div>
          <div class="profile-section">
            <div class="profile-label">能力优势</div>
            <div class="profile-value">
              {{ profile.strength }}
            </div>
          </div>
          <div class="profile-section">
            <div class="profile-label">规划目标</div>
            <div class="profile-value">
              {{ profile.goal }}
            </div>
          </div>
        </div>
        <div v-else class="empty">暂无画像数据</div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref } from 'vue';

  const __props = defineProps({
    references: {
      type: [Array],
      required: false,
      default: () => [
        {
          id: 'r1',
          title: '新能源汽车行业发展趋势与人才需求分析',
          excerpt:
            '报告指出，新能源汽车行业未来五年人才缺口持续扩大，机电一体化、电池技术等专业背景毕业生具有明显竞争优势。',
          source: '行业研究报告',
          date: '2025-03-12',
          url: 'https://example.com/report/new-energy'
        },
        {
          id: 'r2',
          title: '高职院校学生职业规划指导手册',
          excerpt:
            '手册明确职业规划应从自我认知、职业探索、目标设定、行动实施四个阶段逐步推进。',
          source: '校内教材',
          date: '2025-02-20',
          url: 'https://example.com/handbook/career'
        }
      ]
    },
    knowledgeList: {
      type: [Array],
      required: false,
      default: () => [
        {
          id: 'kb1',
          name: '专业与就业',
          description: '各专业对应岗位、就业方向与薪资水平',
          count: 128
        },
        {
          id: 'kb2',
          name: '行业图谱',
          description: '重点行业产业链、龙头企业与区域分布',
          count: 64
        },
        {
          id: 'kb3',
          name: '升学指南',
          description: '专升本、技能竞赛、证书考取路径',
          count: 42
        }
      ]
    },
    profile: {
      type: [Object],
      required: false,
      default: () => ({
        name: '张明',
        major: '机电一体化技术',
        grade: '2023级',
        tags: ['动手能力强', '班级技能竞赛一等奖', '对新能源感兴趣'],
        interest: '新能源汽车、智能制造、自动化设备',
        strength: 'PLC基础、机械制图、团队协作',
        goal: '成为新能源汽车动力电池工艺工程师'
      })
    }
  });
  const __emit = defineEmits(['tab-change', 'open-reference']);
  const __provider = useProvider({ id: 'br0cz38c', version: '1794455757499' });

  const tabs = ref([
    { key: 'references', label: '引用' },
    { key: 'knowledge', label: '知识库' },
    { key: 'profile', label: '画像' }
  ]);
  const activeTab = ref('references');
  const handleOpen = (url) => {
    __emit('open-reference', url);
    window.open(url, '_blank');
  };
  const handleTabChange = (key) => {
    activeTab.value = key;
    __emit('tab-change', key);
  }
</script>
<style lang="css" scoped>
  .reference-panel {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
    overflow: hidden;
  }
  .tab-header {
    display: flex;
    border-bottom: 1px solid #f0f1f3;
    padding: 0 12px;
  }
  .tab-btn {
    flex: 1;
    padding: 12px 4px;
    border: none;
    background: none;
    font-size: 14px;
    color: #6b7280;
    cursor: pointer;
    position: relative;
    transition: color 0.2s ease;
  }
  .tab-btn.active {
    color: #2f6bff;
    font-weight: 600;
  }
  .tab-btn.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 24px;
    height: 2px;
    background: #2f6bff;
    border-radius: 2px;
  }
  .tab-content {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    background: #fafbfc;
  }
  .panel-section {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .section-title {
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
  }
  .ref-list,
  .kb-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .ref-card {
    padding: 12px;
    background: #fff;
    border-radius: 8px;
    border: 1px solid #f0f1f3;
    cursor: pointer;
    transition:
      border-color 0.2s ease,
      box-shadow 0.2s ease;
  }
  .ref-card:hover {
    border-color: #2f6bff;
    box-shadow: 0 4px 12px rgba(47, 107, 255, 0.08);
  }
  .ref-title {
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 6px;
  }
  .ref-excerpt {
    font-size: 12px;
    color: #4b5563;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .ref-meta {
    margin-top: 8px;
    font-size: 11px;
    color: #9ca3af;
  }
  .kb-card {
    padding: 12px;
    background: #fff;
    border-radius: 8px;
    border: 1px solid #f0f1f3;
  }
  .kb-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 6px;
  }
  .kb-name {
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
  }
  .kb-badge {
    font-size: 11px;
    color: #2f6bff;
    background: #eef3fe;
    border-radius: 10px;
    padding: 2px 8px;
  }
  .kb-desc {
    font-size: 12px;
    color: #6b7280;
    line-height: 1.5;
  }
  .profile-card {
    background: #fff;
    border-radius: 8px;
    border: 1px solid #f0f1f3;
    padding: 14px;
  }
  .profile-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 14px;
  }
  .profile-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #2f6bff;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 600;
    flex-shrink: 0;
  }
  .profile-info {
    min-width: 0;
  }
  .profile-name {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
  }
  .profile-meta {
    font-size: 12px;
    color: #6b7280;
    margin-top: 3px;
  }
  .profile-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-bottom: 14px;
  }
  .profile-tag {
    font-size: 11px;
    color: #2f6bff;
    background: #e0e7ff;
    border-radius: 4px;
    padding: 3px 8px;
  }
  .profile-section {
    margin-bottom: 12px;
  }
  .profile-section:last-child {
    margin-bottom: 0;
  }
  .profile-label {
    font-size: 11px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .profile-value {
    font-size: 13px;
    color: #1f2937;
    line-height: 1.5;
  }
  .empty {
    text-align: center;
    font-size: 12px;
    color: #9ca3af;
    padding: 30px 0;
  }
</style>
