<template>
  <div class="chat-panel">
    <div class="chat-header">
      <div class="header-left">
        <span class="header-title"> 对话工作台</span>
        <span class="header-subtitle"> 基于知识库的智能回复</span>
      </div>
      <div class="header-actions">
        <span v-if="streaming" class="header-status"> 生成中…</span>
        <button class="icon-btn" title="清空输入" @click="clearInput">
          🗑️
        </button>
      </div>
    </div>
    <div ref="messageListRef" class="message-list">
      <div v-for="(msg, index) in messages" :key="msg.id" class="message-item">
        <div class="avatar">
          {{ msg.role === 'user' ? '我' : 'AI' }}
        </div>
        <div class="bubble">
          <div class="bubble-content">
            {{ msg.content }}
          </div>
          <div
            v-if="msg.references && msg.references.length"
            class="references">
            <div class="ref-title">📚 来源：</div>
            <div
              v-for="(ref, index) in msg.references"
              :key="ref.url"
              class="ref-item"
              @click="openRef(ref.url)">
              {{ ref.title }}
            </div>
          </div>
        </div>
      </div>
      <div v-if="toolStatus" class="tool-status">
        <span class="loading-dot"></span>
        <span> {{ toolStatus }}</span>
      </div>
    </div>
    <div class="input-area">
      <textarea
        v-model="inputText"
        class="input-textarea"
        :disabled="streaming"
        placeholder="请输入你的问题，例如：我想了解新能源汽车行业前景"
        @keydown.meta.enter="handleSend"></textarea>
      <div class="input-actions">
        <span class="input-tip"> Ctrl + Enter 发送</span>
        <button
          v-if="!streaming"
          class="send-btn"
          :disabled="!inputText.trim()"
          @click="handleSend">
          发送
        </button>
        <button v-else class="stop-btn" @click="handleStop">停止</button>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref, watch, nextTick } from 'vue';

  const __props = defineProps({
    messages: {
      type: [Array],
      required: false,
      default: () => []
    },
    streaming: {
      type: [Boolean],
      required: false,
      default: false
    },
    toolStatus: {
      type: [String],
      required: false,
      default: ''
    }
  });
  const __emit = defineEmits(['send', 'stop', 'clear']);
  const __provider = useProvider({ id: '8r0cd8oa', version: '1794455710099' });

  const inputText = ref('');
  const messageListRef = ref(null);
  const openRef = (url) => {
    window.open(url, '_blank');
  };
  const clearInput = () => {
    inputText.value = '';
  };
  const handleSend = () => {
    const text = inputText.value.trim();
    if (!text || __props.streaming) return;
    __emit('send', text);
    inputText.value = '';
  };
  const handleStop = () => {
    __emit('stop');
  };

  watch(
    () => [__props.messages.length, __props.streaming, __props.toolStatus],
    async () => {
      await nextTick();
      if (messageListRef.value) {
        messageListRef.value.scrollTop = messageListRef.value.scrollHeight;
      }
    },
    { deep: true }
  )
</script>
<style lang="css" scoped>
  .chat-panel {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
    overflow: hidden;
  }
  .chat-header {
    padding: 16px 20px;
    border-bottom: 1px solid #f0f1f3;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .header-title {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
  }
  .header-subtitle {
    font-size: 12px;
    color: #9ca3af;
    margin-left: 8px;
  }
  .header-status {
    font-size: 12px;
    color: #2f6bff;
    margin-right: 12px;
  }
  .icon-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 16px;
    color: #9ca3af;
  }
  .icon-btn:hover {
    color: #6b7280;
  }
  .message-list {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    background: #fafbfc;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .message-item {
    display: flex;
    gap: 12px;
    max-width: 80%;
  }
  .message-item.user {
    align-self: flex-end;
    flex-direction: row-reverse;
  }
  .message-item.assistant {
    align-self: flex-start;
  }
  .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 600;
    flex-shrink: 0;
  }
  .avatar.user {
    background: #2f6bff;
    color: #fff;
  }
  .avatar.assistant {
    background: #e0e7ff;
    color: #2f6bff;
  }
  .bubble {
    padding: 12px 14px;
    border-radius: 10px;
    background: #fff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
    position: relative;
    word-break: break-word;
  }
  .message-item.user .bubble {
    background: #2f6bff;
    color: #fff;
  }
  .bubble-content {
    font-size: 14px;
    line-height: 1.6;
    white-space: pre-wrap;
  }
  .references {
    margin-top: 10px;
    padding-top: 8px;
    border-top: 1px solid rgba(0, 0, 0, 0.06);
  }
  .ref-title {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 5px;
  }
  .ref-item {
    font-size: 12px;
    color: #2f6bff;
    cursor: pointer;
    margin: 2px 0;
    text-decoration: underline;
  }
  .ref-item:hover {
    color: #1e56d6;
  }
  .tool-status {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: #f3f4f6;
    border-radius: 8px;
    font-size: 12px;
    color: #6b7280;
    align-self: flex-start;
  }
  .loading-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #2f6bff;
    animation: pulse 1.2s infinite ease-in-out;
  }
  @keyframes pulse {
    0%,
    100% {
      opacity: 0.3;
    }
    50% {
      opacity: 1;
    }
  }
  .input-area {
    padding: 16px 20px;
    border-top: 1px solid #f0f1f3;
    background: #fff;
  }
  .input-textarea {
    width: 100%;
    min-height: 52px;
    max-height: 120px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 14px;
    line-height: 1.5;
    resize: vertical;
    outline: none;
    color: #1f2937;
    box-sizing: border-box;
    transition:
      border-color 0.2s ease,
      box-shadow 0.2s ease;
  }
  .input-textarea:focus {
    border-color: #2f6bff;
    box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.1);
  }
  .input-textarea::placeholder {
    color: #9ca3af;
  }
  .input-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 10px;
  }
  .input-tip {
    font-size: 11px;
    color: #9ca3af;
  }
  .send-btn {
    padding: 7px 20px;
    border: none;
    border-radius: 7px;
    background: #2f6bff;
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s ease;
  }
  .send-btn:hover {
    background: #1e56d6;
  }
  .send-btn:disabled {
    background: #c0c8d9;
    cursor: not-allowed;
  }
  .stop-btn {
    padding: 7px 20px;
    border: none;
    border-radius: 7px;
    background: #ef4444;
    color: #fff;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s ease;
  }
  .stop-btn:hover {
    background: #dc2626;
  }
</style>
