<template>
  <div class="kb-manager-page">
    <div class="km-header">
      <div class="km-title">
        <h2>知识库管理</h2>
        <p class="km-desc">
          上传、审核与维护职业规划知识文档，保证 AI 回答可溯源
        </p>
      </div>
      <div class="km-tools">
        <ElInput
          v-model="__state.keyword"
          class="km-search"
          clearable=""
          placeholder="搜索标题或上传人"></ElInput>
        <ElSelect
          v-model="__state.category"
          class="km-select"
          placeholder="全部分类">
          <ElOption label="全部分类" value="all"></ElOption>
          <ElOption label="职业认知" value="职业认知"></ElOption>
          <ElOption label="行业趋势" value="行业趋势"></ElOption>
          <ElOption label="升学政策" value="升学政策"></ElOption>
          <ElOption label="求职技能" value="求职技能"></ElOption>
          <ElOption label="成长计划" value="成长计划"></ElOption
        ></ElSelect>
        <ElButton type="primary" @click="() => (__state.uploadVisible = true)">
          上传文档</ElButton
        >
      </div>
    </div>
    <div class="km-stats">
      <div class="stat-item">
        <span class="stat-label"> 文档总数</span>
        <span class="stat-value"> {{ stats.total }}</span>
      </div>
      <div class="stat-item">
        <span class="stat-label"> 待审核</span>
        <span class="stat-value warning"> {{ stats.pending }}</span>
      </div>
      <div class="stat-item">
        <span class="stat-label"> 已发布</span>
        <span class="stat-value success"> {{ stats.published }}</span>
      </div>
      <div class="stat-item">
        <span class="stat-label"> 已驳回</span>
        <span class="stat-value danger"> {{ stats.rejected }}</span>
      </div>
    </div>
    <div class="km-table-wrap">
      <ElTable :data="pagedDocs" class="km-table" height="100%" stripe="">
        <ElTableColumn
          prop="title"
          label="文档标题"
          min-width="180"
          show-overflow-tooltip=""></ElTableColumn>
        <ElTableColumn prop="category" label="分类" width="110">
          <template #default="scope">
            <ElTag size="small" effect="plain"> {{ scope.row.category }}</ElTag>
          </template></ElTableColumn
        >
        <ElTableColumn
          prop="uploader"
          label="上传人"
          width="100"></ElTableColumn>
        <ElTableColumn
          prop="source"
          label="来源"
          width="140"
          show-overflow-tooltip=""></ElTableColumn>
        <ElTableColumn prop="status" label="状态" width="100">
          <template #default="scope">
            <ElTag size="small" :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}</ElTag
            >
          </template></ElTableColumn
        >
        <ElTableColumn
          prop="updatedAt"
          label="更新时间"
          width="160"></ElTableColumn>
        <ElTableColumn align="center" label="操作" width="130">
          <template #default="scope">
            <ElButton
              v-if="scope.row.status === '待审核'"
              link=""
              size="small"
              type="primary"
              @click="handleApprove(scope.row)">
              审核通过</ElButton
            >
            <ElButton
              v-if="scope.row.status === '待审核'"
              link=""
              size="small"
              type="warning"
              @click="handleReject(scope.row)">
              驳回</ElButton
            >
            <span v-if="scope.row.status !== '待审核'" class="done-hint">
              已完成</span
            >
          </template></ElTableColumn
        ></ElTable
      >
    </div>
    <div class="km-pagination">
      <ElPagination
        v-model:current-page="__state.currentPage"
        :total="filteredDocs.length"
        layout="prev, pager, next, sizes"
        :page-size="__state.pageSize"
        :page-sizes="[10, 20, 50]"></ElPagination>
    </div>
    <ElDialog
      v-model="__state.uploadVisible"
      title="上传知识文档"
      width="540px">
      <div class="upload-form">
        <div class="form-row">
          <span class="form-label"> 文档标题</span>
          <ElInput
            v-model="__state.uploadForm.title"
            placeholder="请输入文档标题"></ElInput>
        </div>
        <div class="form-row">
          <span class="form-label"> 文档分类</span>
          <ElSelect
            v-model="__state.uploadForm.category"
            :style="{ width: '100%' }"
            placeholder="请选择分类"
            class="ElSelect_t6mr0ebw0u">
            <ElOption label="职业认知" value="职业认知"></ElOption>
            <ElOption label="行业趋势" value="行业趋势"></ElOption>
            <ElOption label="升学政策" value="升学政策"></ElOption>
            <ElOption label="求职技能" value="求职技能"></ElOption>
            <ElOption label="成长计划" value="成长计划"></ElOption
          ></ElSelect>
        </div>
        <div class="form-row">
          <span class="form-label"> 文档文件</span>
          <ElUpload
            v-model:file-list="__state.uploadForm.files"
            drag=""
            class="upload-area"
            :limit="1"
            accept=".md,.txt,.pdf"
            :auto-upload="false">
            <div class="upload-tip">
              <span class="upload-icon"> 📄</span>
              <p>
                <span> 将文件拖拽到这里，或</span>
                <em> 点击上传</em>
              </p>
            </div>
            <template #tip="scope_t6ur0ebw0u">
              <div class="el-upload__tip">
                仅支持 .md / .txt / .pdf，须包含 front-matter 必填字段
              </div>
            </template></ElUpload
          >
        </div>
        <div class="form-row">
          <span class="form-label"> 备注</span>
          <ElInput
            v-model="__state.uploadForm.remark"
            :rows="3"
            type="textarea"
            placeholder="请输入文档说明或来源备注"></ElInput>
        </div>
      </div>
      <template #footer="scope_t6fr0ebw0u">
        <ElButton @click="() => (__state.uploadVisible = false)">
          取消</ElButton
        >
        <ElButton type="primary" @click="handleSubmitUpload">
          提交校验</ElButton
        >
      </template></ElDialog
    >
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { reactive, computed } from 'vue';
  import {
    ElInput,
    ElSelect,
    ElOption,
    ElButton,
    ElTable,
    ElTableColumn,
    ElTag,
    ElPagination,
    ElDialog,
    ElUpload,
    ElMessage
  } from 'element-plus';

  const __provider = useProvider({ id: 'zr0eap34', version: '1794457992734' });

  const stats = computed(() => {
    return {
      total: __state.docs.length,
      pending: __state.docs.filter((item) => item.status === '待审核').length,
      published: __state.docs.filter((item) => item.status === '已发布').length,
      rejected: __state.docs.filter((item) => item.status === '已驳回').length
    };
  });
  const pagedDocs = computed(() => {
    const start = (__state.currentPage - 1) * __state.pageSize;
    return filteredDocs.value.slice(start, start + __state.pageSize);
  });
  const filteredDocs = computed(() => {
    const keyword = __state.keyword.trim().toLowerCase();
    let list = __state.docs;
    if (__state.category !== 'all') {
      list = list.filter((item) => item.category === __state.category);
    }
    if (keyword) {
      list = list.filter(
        (item) =>
          item.title.toLowerCase().includes(keyword) ||
          item.uploader.toLowerCase().includes(keyword)
      );
    }
    return list;
  });
  const __state = reactive({
    docs: [
      {
        id: 1,
        title: '新能源汽车行业趋势与岗位机会',
        category: '行业趋势',
        uploader: '王老师',
        source: '校企合作白皮书',
        status: '已发布',
        updatedAt: '2025-03-12 16:20:08'
      },
      {
        id: 2,
        title: '电池检测岗位能力画像',
        category: '职业认知',
        uploader: '李老师',
        source: '岗位调研报告',
        status: '已发布',
        updatedAt: '2025-03-11 14:32:45'
      },
      {
        id: 3,
        title: '高职升学与就业路径指南',
        category: '升学政策',
        uploader: '张老师',
        source: '教务处整理',
        status: '已发布',
        updatedAt: '2025-03-10 09:12:31'
      },
      {
        id: 4,
        title: '求职简历撰写与面试表达',
        category: '求职技能',
        uploader: '刘老师',
        source: '就业指导中心',
        status: '待审核',
        updatedAt: '2025-03-13 08:45:22'
      },
      {
        id: 5,
        title: '智能制造新职业机会分析',
        category: '行业趋势',
        uploader: '陈老师',
        source: '工信部报告',
        status: '待审核',
        updatedAt: '2025-03-13 09:05:14'
      },
      {
        id: 6,
        title: '1+X 证书考试要求与备考建议',
        category: '成长计划',
        uploader: '赵老师',
        source: '证书管理中心',
        status: '已驳回',
        updatedAt: '2025-03-12 17:48:56'
      },
      {
        id: 7,
        title: '跨境电商运营入门知识',
        category: '职业认知',
        uploader: '孙老师',
        source: '行业教材整理',
        status: '已发布',
        updatedAt: '2025-03-09 11:27:03'
      },
      {
        id: 8,
        title: '技能成才典型案例汇编',
        category: '成长计划',
        uploader: '周老师',
        source: '教务系统',
        status: '已发布',
        updatedAt: '2025-03-08 15:38:42'
      },
      {
        id: 9,
        title: '订单班校企合作政策解读',
        category: '升学政策',
        uploader: '吴老师',
        source: '招生就业处',
        status: '待审核',
        updatedAt: '2025-03-13 10:02:49'
      },
      {
        id: 10,
        title: 'AI 训练师能力画像与学习路径',
        category: '职业认知',
        uploader: '郑老师',
        source: '企业调研',
        status: '已发布',
        updatedAt: '2025-03-07 10:18:15'
      }
    ],
    keyword: '',
    category: 'all',
    pageSize: 10,
    uploadForm: { title: '', category: '', files: [], remark: '' },
    currentPage: 1,
    uploadVisible: false
  });
  const handleReject = (row) => {
    row.status = '已驳回';
    ElMessage.warning(`《${row.title}》已驳回`);
  };
  const getStatusType = (status) => {
    if (status === '已发布') return 'success';
    if (status === '待审核') return 'warning';
    if (status === '已驳回') return 'danger';
    return 'info';
  };
  const handleApprove = (row) => {
    row.status = '已发布';
    ElMessage.success(`《${row.title}》已审核通过`);
  };
  const handleSubmitUpload = () => {
    const files = __state.uploadForm.files;
    if (!__state.uploadForm.title.trim()) {
      ElMessage.error('请填写文档标题');
      return;
    }
    if (!__state.uploadForm.category) {
      ElMessage.error('请选择文档分类');
      return;
    }
    if (files.length === 0) {
      ElMessage.error('请上传文档文件');
      return;
    }
    const file = files[0];
    if (file.name === 'bad.md') {
      ElMessage.error(
        'front-matter 校验失败：缺少必填字段 source，文档已被拒绝入库'
      );
      return;
    }
    ElMessage.success('文档上传成功，已进入待审核队列');
    __state.uploadVisible = false;
    __state.uploadForm.title = '';
    __state.uploadForm.category = '';
    __state.uploadForm.files = [];
    __state.uploadForm.remark = '';
  }
</script>
<style lang="css" scoped>
  .kb-manager-page {
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 12px;
  }
  .km-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px 14px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .km-title h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
  }
  .km-desc {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .km-tools {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .km-search {
    width: 220px;
  }
  .km-select {
    width: 140px;
  }
  .km-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 14px;
    padding: 16px 22px;
    flex-shrink: 0;
  }
  .stat-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 14px 16px;
    background: #f8faff;
    border: 1px solid #e6efff;
    border-radius: 10px;
  }
  .stat-label {
    font-size: 12px;
    color: #6b7280;
  }
  .stat-value {
    font-size: 22px;
    font-weight: 700;
    color: #1f2937;
  }
  .stat-value.warning {
    color: #e6a23c;
  }
  .stat-value.success {
    color: #67c23a;
  }
  .stat-value.danger {
    color: #f56c6c;
  }
  .km-table-wrap {
    flex: 1;
    padding: 0 22px;
    min-height: 0;
    overflow: hidden;
  }
  .km-table {
    width: 100%;
  }
  .done-hint {
    font-size: 12px;
    color: #b0b7c3;
  }
  .km-pagination {
    flex-shrink: 0;
    display: flex;
    justify-content: flex-end;
    padding: 14px 22px 16px;
  }
  .upload-form {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .form-row {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .form-label {
    font-size: 13px;
    font-weight: 600;
    color: #374151;
  }
  .upload-area {
    width: 100%;
  }
  .upload-tip {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    padding: 20px 0;
    color: #6b7280;
  }
  .upload-icon {
    font-size: 28px;
  }
  .upload-tip p {
    margin: 0;
    font-size: 13px;
  }
  .upload-tip em {
    color: #2f6bff;
    font-style: normal;
  }
</style>
