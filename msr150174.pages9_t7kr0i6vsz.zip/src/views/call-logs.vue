<template>
  <div class="call-logs-page">
    <div class="logs-header">
      <div class="logs-title">
        <h2>调用日志</h2>
        <p class="logs-desc">
          查看智能体调用记录、知识引用与安全熔断状态，仅限教师/管理员访问
        </p>
      </div>
      <div class="logs-tools">
        <ElSelect
          v-model="__state.user"
          class="logs-select"
          placeholder="全部用户">
          <ElOption label="全部用户" value="all"></ElOption>
          <ElOption label="张同学" value="张同学"></ElOption>
          <ElOption label="李同学" value="李同学"></ElOption>
          <ElOption label="王同学" value="王同学"></ElOption
        ></ElSelect>
        <ElSelect
          v-model="__state.level"
          class="logs-select"
          placeholder="全部日志级别">
          <ElOption label="全部级别" value="all"></ElOption>
          <ElOption :label="'正常'" :value="'正常'"></ElOption>
          <ElOption :label="'无出处提示'" :value="'无出处提示'"></ElOption>
          <ElOption :label="'安全熔断'" :value="'安全熔断'"></ElOption
        ></ElSelect>
        <ElButton type="primary" plain="" @click="handleRefresh">
          刷新</ElButton
        >
      </div>
    </div>
    <div class="logs-summary">
      <div class="summary-item">
        <span class="summary-label"> 今日调用</span>
        <span class="summary-value"> {{ __state.todayCount }}</span>
      </div>
      <div class="summary-item">
        <span class="summary-label"> 平均响应</span>
        <span class="summary-value"> 1.8s</span>
      </div>
      <div class="summary-item">
        <span class="summary-label"> 知识命中率</span>
        <span class="summary-value"> 87%</span>
      </div>
      <div class="summary-item">
        <span class="summary-label"> 无出处拦截</span>
        <span class="summary-value warning"> {{ __state.blockedCount }}</span>
      </div>
    </div>
    <div class="logs-table-wrap">
      <ElTable :data="filteredLogs" class="logs-table" height="100%" stripe="">
        <ElTableColumn prop="time" label="调用时间" width="160"></ElTableColumn>
        <ElTableColumn prop="user" label="用户" width="100">
          <template #default="scope">
            <span class="user-cell"> {{ scope.row.user }}</span>
          </template></ElTableColumn
        >
        <ElTableColumn
          prop="session"
          label="会话"
          min-width="140"
          show-overflow-tooltip=""></ElTableColumn>
        <ElTableColumn prop="intent" label="识别意图" width="130">
          <template #default="scope">
            <ElTag size="small" :type="getIntentType(scope.row.intent)">
              {{ scope.row.intent }}</ElTag
            >
          </template></ElTableColumn
        >
        <ElTableColumn prop="sources" label="引用知识" width="150">
          <template #default="scope">
            <div class="source-tags">
              <ElTag
                v-for="(source, index) in scope.row.sources"
                :key="source"
                size="small"
                effect="plain">
                {{ source }}</ElTag
              >
            </div>
          </template></ElTableColumn
        >
        <ElTableColumn prop="status" label="状态" width="110">
          <template #default="scope">
            <ElTag size="small" :type="getStatusTagType(scope.row.status)">
              {{ scope.row.status }}</ElTag
            >
          </template></ElTableColumn
        >
        <ElTableColumn
          prop="tokens"
          align="right"
          label="Tokens"
          width="90"></ElTableColumn>
        <ElTableColumn align="center" label="操作" width="90">
          <template #default="scope">
            <ElButton
              link=""
              size="small"
              type="primary"
              @click="handleView(scope.row)">
              详情</ElButton
            >
          </template></ElTableColumn
        ></ElTable
      >
    </div>
    <div class="logs-pagination">
      <ElPagination
        v-model:current-page="__state.currentPage"
        :total="filteredLogs.length"
        layout="prev, pager, next, sizes"
        :page-size="__state.pageSize"
        :page-sizes="[10, 20, 50]"></ElPagination>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { reactive, computed } from 'vue';
  import {
    ElSelect,
    ElOption,
    ElButton,
    ElTable,
    ElTableColumn,
    ElTag,
    ElPagination,
    ElMessage
  } from 'element-plus';

  const __provider = useProvider({ id: 'wr0ea12x', version: '1794457930808' });

  const filteredLogs = computed(() => {
    let list = __state.logs;
    if (__state.user !== 'all') {
      list = list.filter((log) => log.user === __state.user);
    }
    if (__state.level !== 'all') {
      list = list.filter((log) => log.status === __state.level);
    }
    return list;
  });
  const __state = reactive({
    logs: [
      {
        id: 1,
        time: '2025-03-13 10:32:18',
        user: '张同学',
        session: '新能源电池岗位咨询',
        intent: '职业认知',
        sources: ['新能源汽车行业趋势', '电池检测岗位画像'],
        status: '正常',
        tokens: 1240
      },
      {
        id: 2,
        time: '2025-03-13 10:31:05',
        user: '李同学',
        session: '升学还是就业',
        intent: '路径规划',
        sources: ['高职升学与就业路径指南'],
        status: '正常',
        tokens: 980
      },
      {
        id: 3,
        time: '2025-03-13 10:29:47',
        user: '王同学',
        session: '跨专业求职问题',
        intent: '求职技能',
        sources: [],
        status: '无出处提示',
        tokens: 360
      },
      {
        id: 4,
        time: '2025-03-13 10:28:33',
        user: '张同学',
        session: '电池工程师发展',
        intent: '成长计划',
        sources: ['成长计划模板', '1+X证书要求'],
        status: '正常',
        tokens: 1520
      },
      {
        id: 5,
        time: '2025-03-13 10:15:12',
        user: '李同学',
        session: '工业机器人学习',
        intent: '职业认知',
        sources: ['智能制造新职业机会'],
        status: '正常',
        tokens: 1180
      },
      {
        id: 6,
        time: '2025-03-13 09:58:40',
        user: '王同学',
        session: '情绪疏导咨询',
        intent: '危机干预',
        sources: [],
        status: '安全熔断',
        tokens: 220
      },
      {
        id: 7,
        time: '2025-03-13 09:45:03',
        user: '张同学',
        session: '简历修改建议',
        intent: '求职技能',
        sources: ['求职简历撰写与面试表达'],
        status: '正常',
        tokens: 1340
      },
      {
        id: 8,
        time: '2025-03-13 09:30:27',
        user: '王同学',
        session: '跨境电商选品',
        intent: '行业趋势',
        sources: ['跨境电商运营入门'],
        status: '正常',
        tokens: 1100
      },
      {
        id: 9,
        time: '2025-03-13 09:12:55',
        user: '李同学',
        session: '技能竞赛准备',
        intent: '路径规划',
        sources: ['技能成才典型案例'],
        status: '正常',
        tokens: 1460
      },
      {
        id: 10,
        time: '2025-03-12 21:08:16',
        user: '张同学',
        session: '薪资谈判咨询',
        intent: '求职技能',
        sources: [],
        status: '无出处提示',
        tokens: 450
      },
      {
        id: 11,
        time: '2025-03-12 18:22:09',
        user: '王同学',
        session: '人工智能训练师',
        intent: '职业认知',
        sources: ['AI训练师能力画像'],
        status: '正常',
        tokens: 1020
      },
      {
        id: 12,
        time: '2025-03-12 16:47:31',
        user: '李同学',
        session: '订单班政策咨询',
        intent: '升学政策',
        sources: ['高职升学路径指南'],
        status: '正常',
        tokens: 780
      }
    ],
    user: 'all',
    level: 'all',
    pageSize: 10,
    todayCount: 128,
    currentPage: 1,
    blockedCount: 7
  });
  const handleView = (row) => {
    ElMessage.info(`查看调用详情：${row.session}`);
  };
  const getIntentType = (intent) => {
    const map = {
      职业认知: 'primary',
      路径规划: 'success',
      求职技能: 'warning',
      成长计划: 'info',
      危机干预: 'danger',
      行业趋势: 'success',
      升学政策: 'info'
    };
    return map[intent] || 'info';
  };
  const handleRefresh = () => {
    ElMessage.success('日志已刷新');
  };
  const getStatusTagType = (status) => {
    if (status === '正常') return 'success';
    if (status === '无出处提示') return 'warning';
    if (status === '安全熔断') return 'danger';
    return 'info';
  }
</script>
<style lang="css" scoped>
  .call-logs-page {
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 12px;
  }
  .logs-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px 14px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .logs-title h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
  }
  .logs-desc {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .logs-tools {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .logs-select {
    width: 150px;
  }
  .logs-summary {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 14px;
    padding: 16px 22px;
    flex-shrink: 0;
  }
  .summary-item {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 14px 16px;
    background: #f8faff;
    border: 1px solid #e6efff;
    border-radius: 10px;
  }
  .summary-label {
    font-size: 12px;
    color: #6b7280;
  }
  .summary-value {
    font-size: 22px;
    font-weight: 700;
    color: #1f2937;
  }
  .summary-value.warning {
    color: #e6a23c;
  }
  .logs-table-wrap {
    flex: 1;
    padding: 0 22px;
    min-height: 0;
    overflow: hidden;
  }
  .logs-table {
    width: 100%;
  }
  .user-cell {
    font-weight: 500;
    color: #1f2937;
  }
  .source-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .logs-pagination {
    flex-shrink: 0;
    display: flex;
    justify-content: flex-end;
    padding: 14px 22px 16px;
  }
</style>
