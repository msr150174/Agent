<template>
  <div class="chat-workspace">
    <div class="workspace-placeholder">
      <div class="placeholder-icon">💬</div>
      <p class="placeholder-title">欢迎使用对话工作台</p>
      <p class="placeholder-sub">请在左侧选择会话或新建会话开始咨询</p>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';

  const __provider = useProvider({ id: 'kr0dwyr8', version: '1794457328796' })
</script>
<style lang="css" scoped>
  .chat-workspace {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f7fa;
  }
  .workspace-placeholder {
    text-align: center;
    color: #6b7280;
  }
  .placeholder-icon {
    font-size: 48px;
    margin-bottom: 16px;
  }
  .placeholder-title {
    font-size: 18px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 8px;
  }
  .placeholder-sub {
    font-size: 13px;
  }
</style>
