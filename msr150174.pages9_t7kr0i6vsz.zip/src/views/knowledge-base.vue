<template>
  <div class="knowledge-base-page">
    <div class="kb-header">
      <div class="kb-title">
        <h2>知识库</h2>
        <p class="kb-desc">
          查阅职业规划相关知识文档，所有回答均来自本库并支持溯源
        </p>
      </div>
      <div class="kb-tools">
        <ElInput
          v-model="__state.keyword"
          class="kb-search"
          clearable=""
          placeholder="搜索文档关键词"></ElInput>
        <ElSelect
          v-model="__state.category"
          class="kb-select"
          placeholder="全部分类">
          <ElOption label="全部" value="all"></ElOption>
          <ElOption label="行业趋势" value="行业趋势"></ElOption>
          <ElOption label="职业认知" value="职业认知"></ElOption>
          <ElOption label="升学路径" value="升学路径"></ElOption>
          <ElOption label="求职技能" value="求职技能"></ElOption
        ></ElSelect>
      </div>
    </div>
    <div v-if="filteredDocs.length === 0" class="kb-empty">
      <ElEmpty description="暂无匹配文档"></ElEmpty>
    </div>
    <div v-else class="kb-doc-grid">
      <div v-for="(doc, index) in pagedDocs" :key="doc.id" class="doc-card">
        <div class="doc-card-top">
          <ElTag size="small" :type="getTagType(doc.category)">
            {{ doc.category }}</ElTag
          >
          <span class="doc-citation">
            <span>
              <span> 引用</span>
              <span> {{ doc.citations }}</span></span
            ></span
          >
        </div>
        <h3 class="doc-title">
          {{ doc.title }}
        </h3>
        <p class="doc-summary">
          {{ doc.summary }}
        </p>
        <div class="doc-meta">
          <span class="doc-date"> {{ doc.updatedAt }}</span>
          <span class="doc-action" @click="handlePreview(doc)"> 查看 →</span>
        </div>
      </div>
    </div>
    <div v-if="filteredDocs.length > 0" class="kb-pagination">
      <ElPagination
        v-model:current-page="__state.currentPage"
        :total="filteredDocs.length"
        layout="prev, pager, next"
        :page-size="__state.pageSize"></ElPagination>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { reactive, computed } from 'vue';
  import {
    ElInput,
    ElSelect,
    ElOption,
    ElEmpty,
    ElTag,
    ElPagination,
    ElMessage
  } from 'element-plus';

  const __provider = useProvider({ id: 'nr0dxtni', version: '1794457829288' });

  const pagedDocs = computed(() => {
    const start = (__state.currentPage - 1) * __state.pageSize;
    return filteredDocs.value.slice(start, start + __state.pageSize);
  });
  const filteredDocs = computed(() => {
    const keyword = __state.keyword.trim().toLowerCase();
    let list = __state.docs;
    if (__state.category !== 'all') {
      list = list.filter((doc) => doc.category === __state.category);
    }
    if (keyword) {
      list = list.filter(
        (doc) =>
          doc.title.toLowerCase().includes(keyword) ||
          doc.summary.toLowerCase().includes(keyword)
      );
    }
    return list;
  });
  const __state = reactive({
    docs: [
      {
        id: 1,
        title: '新能源汽车行业发展趋势与人才需求分析',
        category: '行业趋势',
        summary:
          '报告指出未来五年新能源行业人才缺口持续扩大，电池技术、电控系统等方向需求旺盛。',
        citations: 32,
        updatedAt: '2025-03-12'
      },
      {
        id: 2,
        title: '高职学生升学与就业路径选择指南',
        category: '升学路径',
        summary:
          '系统梳理高职学生专升本、技能竞赛、订单班等多元发展路径的适用条件与准备要点。',
        citations: 28,
        updatedAt: '2025-03-10'
      },
      {
        id: 3,
        title: '制造业数字化转型下的新职业机会',
        category: '职业认知',
        summary:
          '智能产线运维、工业机器人调试等岗位成为制造业数字化人才主力需求。',
        citations: 25,
        updatedAt: '2025-03-08'
      },
      {
        id: 4,
        title: '求职简历撰写与面试表达技巧',
        category: '求职技能',
        summary:
          '针对职业院校学生特点，提供简历结构优化、项目经历提炼及结构化面试应答建议。',
        citations: 41,
        updatedAt: '2025-03-06'
      },
      {
        id: 5,
        title: '人工智能训练师职业能力画像',
        category: '职业认知',
        summary:
          '人工智能训练师岗位职责正在向数据治理、模型调优与业务协同方向演进。',
        citations: 19,
        updatedAt: '2025-03-04'
      },
      {
        id: 6,
        title: '跨境电商运营岗位入门与进阶策略',
        category: '行业趋势',
        summary:
          '跨境电商运营岗位对数据分析、多语言沟通与海外平台规则理解能力要求提升。',
        citations: 22,
        updatedAt: '2025-02-28'
      },
      {
        id: 7,
        title: '高职生技能成才典型路径案例集',
        category: '升学路径',
        summary:
          '汇集全国职业院校技能大赛获奖选手、技术能手的成长路径与关键节点经验。',
        citations: 35,
        updatedAt: '2025-02-26'
      },
      {
        id: 8,
        title: '新能源电池检测与维修岗位实训指南',
        category: '求职技能',
        summary:
          '围绕动力电池检测、均衡维护与故障诊断，给出岗位能力清单与实训项目建议。',
        citations: 17,
        updatedAt: '2025-02-24'
      }
    ],
    keyword: '',
    category: 'all',
    pageSize: 6,
    currentPage: 1
  });
  const getTagType = (category) => {
    const map = {
      行业趋势: 'primary',
      职业认知: 'success',
      升学路径: 'warning',
      求职技能: 'danger'
    };
    return map[category] || 'info';
  };
  const handlePreview = (doc) => {
    ElMessage.info(`正在准备《${doc.title}》预览`);
  }
</script>
<style lang="css" scoped>
  .knowledge-base-page {
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 12px;
  }
  .kb-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px 14px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .kb-title h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
  }
  .kb-desc {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .kb-tools {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .kb-search {
    width: 240px;
  }
  .kb-select {
    width: 130px;
  }
  .kb-empty {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .kb-doc-grid {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    padding: 20px 22px;
    overflow-y: auto;
    align-content: start;
  }
  .doc-card {
    padding: 16px;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    background: #fff;
    transition:
      border-color 0.2s,
      box-shadow 0.2s;
    cursor: default;
  }
  .doc-card:hover {
    border-color: #c7d7fe;
    box-shadow: 0 6px 16px rgba(47, 107, 255, 0.08);
  }
  .doc-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .doc-citation {
    font-size: 12px;
    color: #9ca3af;
  }
  .doc-title {
    margin: 0 0 8px;
    font-size: 15px;
    font-weight: 600;
    color: #111827;
    line-height: 1.4;
  }
  .doc-summary {
    margin: 0 0 14px;
    font-size: 13px;
    line-height: 1.65;
    color: #6b7280;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .doc-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;
    color: #9ca3af;
  }
  .doc-action {
    color: #2f6bff;
    cursor: pointer;
    font-weight: 500;
  }
  .doc-action:hover {
    color: #1e56d6;
  }
  .kb-pagination {
    flex-shrink: 0;
    display: flex;
    justify-content: center;
    padding: 12px 0 14px;
  }
</style>
