<template>
  <div class="growth-plan-page">
    <div class="growth-header">
      <div class="growth-title">
        <h2>成长计划</h2>
        <p class="growth-desc">聚焦目标岗位，按阶段补齐技能与证书短板</p>
      </div>
      <div class="growth-target">
        <span class="target-label"> 目标职业</span>
        <ElTag type="primary"> {{ __state.targetCareer }}</ElTag>
      </div>
    </div>
    <div class="overview-card">
      <div class="overview-left">
        <h3 class="overview-title">计划总进度</h3>
        <p class="overview-sub">
          <span>
            <span> 完成</span>
            <span> {{ __state.completedSteps }}</span>
            <span> /</span>
            <span> {{ __state.totalSteps }}</span>
            <span> 个成长任务</span></span
          >
        </p>
      </div>
      <div class="overview-right">
        <ElProgress
          type="circle"
          color="#2f6bff"
          :width="96"
          :percentage="__state.overallProgress"
          :stroke-width="10"></ElProgress>
      </div>
    </div>
    <div class="growth-content">
      <div class="timeline-block">
        <h3 class="block-title">阶段规划</h3>
        <ElTimeline class="growth-timeline">
          <ElTimelineItem
            v-for="(phase, index) in __state.phases"
            :key="phase.id"
            :type="getPhaseType(phase.status)"
            :hollow="phase.status === 'todo'"
            placement="top"
            :timestamp="phase.period">
            <div
              :class="
                Object.assign(
                  { 'phase-card': true },
                  { 'phase-done': phase.status === 'done' }
                )
              ">
              <div class="phase-head">
                <span class="phase-name"> {{ phase.name }}</span>
                <ElTag size="small" :type="getStatusType(phase.status)">
                  {{ getStatusLabel(phase.status) }}</ElTag
                >
              </div>
              <p class="phase-desc">
                {{ phase.desc }}
              </p>
              <div class="phase-steps">
                <div
                  v-for="(step, index) in phase.steps"
                  :key="step.id"
                  class="step-item">
                  <span
                    :class="
                      Object.assign(
                        { 'step-dot': true },
                        { completed: step.done }
                      )
                    "></span>
                  <span class="step-text"> {{ step.label }}</span>
                  <span v-if="step.cert" class="step-cert">
                    {{ step.cert }}</span
                  >
                </div>
              </div>
            </div></ElTimelineItem
          ></ElTimeline
        >
      </div>
      <div class="skill-block">
        <h3 class="block-title">技能增强</h3>
        <div class="skill-list">
          <div
            v-for="(skill, index) in __state.skills"
            :key="skill.name"
            class="skill-card">
            <div class="skill-head">
              <span class="skill-name"> {{ skill.name }}</span>
              <span class="skill-score">
                <span>
                  <span> {{ skill.score }}</span>
                  <span> %</span></span
                ></span
              >
            </div>
            <ElProgress
              :color="skill.score > 70 ? '#67c23a' : '#e6a23c'"
              :percentage="skill.score"
              :stroke-width="8"></ElProgress>
            <p class="skill-tip">
              {{ skill.tip }}
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="plan-actions">
      <ElButton type="primary" @click="handleRefreshPlan">
        重新生成计划</ElButton
      >
      <ElButton @click="handleExportPlan"> 导出计划</ElButton>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { reactive } from 'vue';
  import {
    ElTag,
    ElProgress,
    ElTimeline,
    ElTimelineItem,
    ElButton,
    ElMessage
  } from 'element-plus';

  const __provider = useProvider({ id: 'tr0e9af6', version: '1794457900147' });

  const __state = reactive({
    phases: [
      {
        id: 1,
        name: '基础能力巩固',
        period: '2025-03 ~ 2025-04',
        status: 'done',
        desc: '完成电学基础与电池检测入门知识学习，建立岗位认知。',
        steps: [
          { id: 11, label: '完成电学与电池基础知识学习', done: true, cert: null },
          { id: 12, label: '岗位说明书研读与职业访谈', done: true, cert: null }
        ]
      },
      {
        id: 2,
        name: '专业核心技能',
        period: '2025-05 ~ 2025-08',
        status: 'doing',
        desc: '系统掌握电池检测设备操作、BMS 数据读取与故障诊断方法。',
        steps: [
          {
            id: 21,
            label: '电池检测设备实操 40 学时',
            done: true,
            cert: '校内实训认证'
          },
          { id: 22, label: 'BMS 通讯协议与数据分析', done: true, cert: null },
          { id: 23, label: '故障诊断案例练习 20 例', done: true, cert: null }
        ]
      },
      {
        id: 3,
        name: '证书与实战',
        period: '2025-09 ~ 2025-12',
        status: 'doing',
        desc: '考取 1+X 证书并进入合作企业完成跟岗实践，积累真实项目经验。',
        steps: [
          {
            id: 31,
            label: '考取 1+X 电池检测证书',
            done: false,
            cert: '1+X 证书'
          },
          {
            id: 32,
            label: '企业跟岗实践 80 小时',
            done: false,
            cert: '企业实践证明'
          }
        ]
      },
      {
        id: 4,
        name: '求职冲刺',
        period: '2026-01 ~ 2026-03',
        status: 'todo',
        desc: '完善求职材料，准备企业面试，完成岗位匹配与入职对接。',
        steps: [
          { id: 41, label: '简历与作品集优化', done: false, cert: null },
          { id: 42, label: '模拟面试 3 次', done: false, cert: null }
        ]
      }
    ],
    skills: [
      {
        name: '电池检测实操',
        score: 80,
        tip: '已通过校内实训认证，建议增加高压安全操作训练'
      },
      {
        name: 'BMS 数据分析',
        score: 65,
        tip: '能读懂基础报文，建议学习 Python 数据处理'
      },
      { name: '故障诊断', score: 45, tip: '案例积累偏少，优先完成 20 例诊断练习' }
    ],
    totalSteps: 9,
    targetCareer: '新能源电池检测工程师',
    completedSteps: 5,
    overallProgress: 58
  });
  const getPhaseType = (status) => {
    if (status === 'done') return 'success';
    if (status === 'doing') return 'primary';
    return 'info';
  };
  const getStatusType = (status) => {
    if (status === 'done') return 'success';
    if (status === 'doing') return 'primary';
    return 'info';
  };
  const getStatusLabel = (status) => {
    if (status === 'done') return '已完成';
    if (status === 'doing') return '进行中';
    return '待开始';
  };
  const handleExportPlan = () => {
    ElMessage.success('成长计划已导出');
  };
  const handleRefreshPlan = () => {
    ElMessage.success('已根据最新测评结果更新成长计划');
  }
</script>
<style lang="css" scoped>
  .growth-plan-page {
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 12px;
  }
  .growth-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px 14px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .growth-title h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
  }
  .growth-desc {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .growth-target {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .target-label {
    font-size: 13px;
    color: #6b7280;
  }
  .overview-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 18px 22px;
    padding: 18px 24px;
    background: #f8faff;
    border: 1px solid #e6efff;
    border-radius: 12px;
    flex-shrink: 0;
  }
  .overview-title {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
  }
  .overview-sub {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .growth-content {
    flex: 1;
    display: grid;
    grid-template-columns: 1.2fr 0.8fr;
    gap: 24px;
    padding: 0 22px;
    overflow-y: auto;
  }
  .block-title {
    margin: 0 0 16px;
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
  }
  .growth-timeline {
    padding-left: 4px;
  }
  .phase-card {
    padding: 14px 16px;
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    transition:
      border-color 0.2s,
      box-shadow 0.2s;
  }
  .phase-card:hover {
    border-color: #c7d7fe;
    box-shadow: 0 6px 16px rgba(47, 107, 255, 0.08);
  }
  .phase-done {
    border-color: #d3f0d9;
    background: #f9fefb;
  }
  .phase-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
  }
  .phase-name {
    font-size: 14px;
    font-weight: 600;
    color: #111827;
  }
  .phase-desc {
    margin: 0 0 14px;
    font-size: 13px;
    line-height: 1.6;
    color: #6b7280;
  }
  .phase-steps {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .step-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: #4b5563;
  }
  .step-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #d1d5db;
    flex-shrink: 0;
  }
  .step-dot.completed {
    background: #67c23a;
  }
  .step-cert {
    margin-left: auto;
    padding: 2px 8px;
    font-size: 12px;
    color: #2f6bff;
    background: #eef3ff;
    border-radius: 4px;
  }
  .skill-list {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .skill-card {
    padding: 14px 16px;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    background: #fff;
  }
  .skill-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .skill-name {
    font-size: 14px;
    font-weight: 600;
    color: #111827;
  }
  .skill-score {
    font-size: 13px;
    font-weight: 600;
    color: #2f6bff;
  }
  .skill-tip {
    margin: 10px 0 0;
    font-size: 12px;
    line-height: 1.5;
    color: #9ca3af;
  }
  .plan-actions {
    flex-shrink: 0;
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    padding: 14px 22px 16px;
    border-top: 1px solid #f0f1f3;
  }
</style>
