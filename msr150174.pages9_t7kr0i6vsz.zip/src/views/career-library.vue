<template>
  <div class="career-library-page">
    <div class="career-header">
      <div class="career-title">
        <h2>职业库</h2>
        <p class="career-desc">
          查询目标职业的任职要求、技能标签与人才供需趋势
        </p>
      </div>
      <div class="career-tools">
        <ElInput
          v-model="__state.keyword"
          class="career-search"
          clearable=""
          placeholder="搜索职业名称或技能"></ElInput>
        <ElSelect
          v-model="__state.category"
          class="career-select"
          placeholder="全部领域">
          <ElOption label="全部" value="all"></ElOption>
          <ElOption label="新能源" value="新能源"></ElOption>
          <ElOption label="智能制造" value="智能制造"></ElOption>
          <ElOption label="人工智能" value="人工智能"></ElOption>
          <ElOption label="跨境电商" value="跨境电商"></ElOption
        ></ElSelect>
      </div>
    </div>
    <div v-if="filteredCareers.length === 0" class="career-empty">
      <ElEmpty description="暂无匹配职业"></ElEmpty>
    </div>
    <div v-else class="career-grid">
      <div
        v-for="(career, index) in pagedCareers"
        :key="career.id"
        class="career-card">
        <div class="career-card-top">
          <ElTag size="small" effect="plain"> {{ career.category }}</ElTag>
          <div class="career-badges">
            <ElTag size="small" :type="getMatchType(career.match)">
              <span>
                <span> 匹配</span>
                <span> {{ career.match }}</span></span
              ></ElTag
            >
            <ElTag size="small" :type="getDemandType(career.demand)">
              <span>
                <span> 需求</span>
                <span> {{ career.demand }}</span></span
              ></ElTag
            >
          </div>
        </div>
        <h3 class="career-name">
          {{ career.name }}
        </h3>
        <p class="career-summary">
          {{ career.summary }}
        </p>
        <div class="career-info">
          <span class="info-item">
            <span>
              <span> 薪资：</span>
              <span> {{ career.salary }}</span></span
            ></span
          >
          <span class="info-item">
            <span>
              <span> 经验：</span>
              <span> {{ career.experience }}</span></span
            ></span
          >
        </div>
        <div class="career-skills">
          <ElTag
            v-for="(skill, index) in career.skills"
            :key="skill"
            size="small"
            class="skill-tag">
            {{ skill }}</ElTag
          >
        </div>
        <div class="career-actions">
          <ElButton
            size="small"
            type="primary"
            plain=""
            @click="handleAnalyze(career)">
            分析匹配</ElButton
          >
        </div>
      </div>
    </div>
    <div v-if="filteredCareers.length > 0" class="career-pagination">
      <ElPagination
        v-model:current-page="__state.currentPage"
        :total="filteredCareers.length"
        layout="prev, pager, next"
        :page-size="__state.pageSize"></ElPagination>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { reactive, computed } from 'vue';
  import {
    ElInput,
    ElSelect,
    ElOption,
    ElEmpty,
    ElTag,
    ElButton,
    ElPagination,
    ElMessage
  } from 'element-plus';

  const __provider = useProvider({ id: 'qr0e8iq5', version: '1794457865323' });

  const pagedCareers = computed(() => {
    const start = (__state.currentPage - 1) * __state.pageSize;
    return filteredCareers.value.slice(start, start + __state.pageSize);
  });
  const filteredCareers = computed(() => {
    const keyword = __state.keyword.trim().toLowerCase();
    let list = __state.careers;
    if (__state.category !== 'all') {
      list = list.filter((career) => career.category === __state.category);
    }
    if (keyword) {
      list = list.filter(
        (career) =>
          career.name.toLowerCase().includes(keyword) ||
          career.skills.some((skill) => skill.toLowerCase().includes(keyword))
      );
    }
    return list;
  });
  const __state = reactive({
    careers: [
      {
        id: 1,
        name: '新能源汽车电池检测工程师',
        category: '新能源',
        match: '92%',
        demand: '高',
        salary: '8-15K',
        experience: '1-3年',
        summary:
          '负责动力电池性能检测、故障诊断与均衡维护，是新能源汽车售后与研发核心岗位。',
        skills: ['电池检测', 'BMS', '故障诊断']
      },
      {
        id: 2,
        name: '工业机器人调试员',
        category: '智能制造',
        match: '88%',
        demand: '高',
        salary: '7-12K',
        experience: '1-3年',
        summary:
          '完成工业机器人现场安装、程序调试与产线联动，支撑智能工厂高效运转。',
        skills: ['PLC', '机器人编程', '产线调试']
      },
      {
        id: 3,
        name: '人工智能训练师',
        category: '人工智能',
        match: '85%',
        demand: '中',
        salary: '6-10K',
        experience: '0-2年',
        summary: '负责数据标注、模型训练与效果评测，推动 AI 产品在垂直场景落地。',
        skills: ['数据标注', 'Python', '模型评测']
      },
      {
        id: 4,
        name: '跨境电商运营专员',
        category: '跨境电商',
        match: '82%',
        demand: '高',
        salary: '6-11K',
        experience: '0-3年',
        summary:
          '负责海外店铺运营、选品分析与推广投放，具备跨文化沟通能力者优先。',
        skills: ['店铺运营', '数据分析', '英语']
      },
      {
        id: 5,
        name: '智能产线运维技术员',
        category: '智能制造',
        match: '83%',
        demand: '高',
        salary: '7-13K',
        experience: '1-3年',
        summary:
          '对智能产线设备进行日常点检、预防性维护与快速排障，保障生产连续性。',
        skills: ['设备维护', '传感器', 'MES']
      },
      {
        id: 6,
        name: '动力电池系统集成助理',
        category: '新能源',
        match: '80%',
        demand: '中',
        salary: '7-12K',
        experience: '0-2年',
        summary: '协助电池包结构设计与系统集成，参与样品试制与可靠性验证。',
        skills: ['CAD', '电池结构', '测试验证']
      }
    ],
    keyword: '',
    category: 'all',
    pageSize: 6,
    currentPage: 1
  });
  const getMatchType = (match) => {
    const value = Number(match.replace('%', ''));
    if (value >= 90) return 'danger';
    if (value >= 85) return 'warning';
    return 'primary';
  };
  const getDemandType = (demand) => {
    if (demand === '高') return 'danger';
    if (demand === '中') return 'warning';
    return 'info';
  };
  const handleAnalyze = (career) => {
    ElMessage.success(`正在生成《${career.name}》的人岗匹配分析`);
  }
</script>
<style lang="css" scoped>
  .career-library-page {
    height: 100%;
    display: flex;
    flex-direction: column;
    padding: 8px 4px;
    box-sizing: border-box;
    background: #fff;
    border-radius: 12px;
  }
  .career-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 22px 14px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .career-title h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
  }
  .career-desc {
    margin: 6px 0 0;
    font-size: 13px;
    color: #6b7280;
  }
  .career-tools {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .career-search {
    width: 240px;
  }
  .career-select {
    width: 140px;
  }
  .career-empty {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .career-grid {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    padding: 20px 22px;
    overflow-y: auto;
    align-content: start;
  }
  .career-card {
    padding: 16px;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    background: #fff;
    transition:
      border-color 0.2s,
      box-shadow 0.2s;
    cursor: default;
  }
  .career-card:hover {
    border-color: #c7d7fe;
    box-shadow: 0 6px 16px rgba(47, 107, 255, 0.08);
  }
  .career-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .career-badges {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .career-name {
    margin: 0 0 8px;
    font-size: 15px;
    font-weight: 600;
    color: #111827;
    line-height: 1.4;
  }
  .career-summary {
    margin: 0 0 12px;
    font-size: 13px;
    line-height: 1.6;
    color: #6b7280;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .career-info {
    display: flex;
    gap: 20px;
    margin-bottom: 12px;
    font-size: 12px;
    color: #4b5563;
  }
  .info-item {
    white-space: nowrap;
  }
  .career-skills {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 14px;
  }
  .skill-tag {
    background: #f5f7fa;
    border-color: #e5e7eb;
    color: #4b5563;
  }
  .career-actions {
    display: flex;
    justify-content: flex-end;
    padding-top: 4px;
  }
  .career-pagination {
    flex-shrink: 0;
    display: flex;
    justify-content: center;
    padding: 12px 0 14px;
  }
</style>
