<template>
  <div class="main-layout">
    <aside class="left-sidebar">
      <div class="sidebar-top">
        <AppSidebar></AppSidebar>
      </div>
      <div class="sidebar-bottom">
        <SessionList></SessionList>
      </div>
    </aside>
    <main class="main-content">
      <ChatPanel
        :messages="messages"
        :streaming="streaming"
        :tool-status="toolStatus"
        @send="handleSend"
        @stop="handleStop"></ChatPanel>
    </main>
    <aside class="right-panel">
      <ReferencePanel
        :references="references"
        @open-reference="handleOpenReference"></ReferencePanel>
    </aside>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref, reactive } from 'vue';
  import AppSidebar from '@/components/AppSidebar.vue';
  import SessionList from '@/components/SessionList.vue';
  import ChatPanel from '@/components/ChatPanel.vue';
  import ReferencePanel from '@/components/ReferencePanel.vue';

  const __provider = useProvider({ id: 'hr0d0qx3', version: '1794457290420' });

  const messages = ref([
    {
      id: 'm1',
      role: 'assistant',
      content:
        '你好，我是路书 AI 职业规划助手。你可以问我任何关于专业选择、行业趋势、升学路径或求职规划的问题，我会基于知识库为你提供可溯源的解答。'
    }
  ]);
  const streaming = ref(false);
  const references = ref([]);
  const toolStatus = ref('');
  const __state = reactive({ currentSession: 'default' });
  const handleSend = (text) => {
    messages.value.push({
      id: `user-${Date.now()}`,
      role: 'user',
      content: text
    });
    streaming.value = true;
    toolStatus.value = '正在检索知识库…';
    setTimeout(() => {
      toolStatus.value = '正在分析匹配结果…';
    }, 600);
    setTimeout(() => {
      toolStatus.value = '';
      streaming.value = false;
      messages.value.push({
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content:
          '根据知识库检索结果，该问题与「新能源汽车行业发展趋势与人才需求分析」相关。该行业未来五年人才缺口持续扩大，机电一体化、电池技术等专业背景毕业生具有明显竞争优势。建议你结合自身专业基础，重点关注动力电池、电控系统等细分方向。',
        references: [
          {
            title: '新能源汽车行业发展趋势与人才需求分析',
            url: 'https://example.com/report/new-energy'
          }
        ]
      });
      references.value = [
        {
          id: 'r1',
          title: '新能源汽车行业发展趋势与人才需求分析',
          excerpt:
            '报告指出，新能源汽车行业未来五年人才缺口持续扩大，机电一体化、电池技术等专业背景毕业生具有明显竞争优势。',
          source: '行业研究报告',
          date: '2025-03-12',
          url: 'https://example.com/report/new-energy'
        }
      ];
    }, 1400);
  };
  const handleStop = () => {
    streaming.value = false;
    toolStatus.value = '';
  };
  const handleOpenReference = (url) => {
    window.open(url, '_blank');
  }
</script>
<style lang="css" scoped>
  .main-layout {
    display: flex;
    height: 100vh;
    min-width: 1280px;
    background: #f5f7fa;
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
    overflow: hidden;
  }
  .left-sidebar {
    width: 264px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    background: #fff;
    border-right: 1px solid #eef0f3;
  }
  .sidebar-top {
    flex-shrink: 0;
    border-bottom: 1px solid #f0f1f3;
  }
  .sidebar-bottom {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
  }
  .main-content {
    flex: 1;
    min-width: 0;
    padding: 12px;
    display: flex;
    background: #f5f7fa;
  }
  .main-content > :deep(*) {
    flex: 1;
    width: 100%;
  }
  .right-panel {
    width: 360px;
    flex-shrink: 0;
    padding: 12px 12px 12px 0;
    background: #f5f7fa;
  }
</style>
