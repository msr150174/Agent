import { reactive, computed } from 'vue';

/**
 * 材料与产出的共享账本。
 * 对话页负责往里写（上传的附件、生成的产物），「材料与产出」页负责读。
 * 为什么不放 sessionStorage：刷新后统计归零反而更像演示事故；
 * 也不做持久化 —— 这是原型，别把假数据写进用户的浏览器。
 */
export const files = reactive({
  materials: [] as any[],
  outputs: [] as any[]
});

let seq = 0;
const uid = (p) => p + Date.now().toString(36) + '-' + seq++;

export const addMaterials = (list: any[]) => {
  (list || []).forEach((f) => {
    // 同名同大小视为同一份，重复上传不叠账
    const dup = files.materials.find((m) => m.name === f.name && m.size === f.size);
    if (dup) {
      dup.status = f.status;
      dup.progress = f.progress;
      dup.chunks = f.chunks;
      dup.uploadedAt = f.uploadedAt || dup.uploadedAt;
      return;
    }
    // 存同一份对象引用：解析进度在附件条里推进，这边跟着变，不用二次同步
    f.id = f.id || uid('m');
    f.from = '对话上传';
    f.uploadedAt = f.uploadedAt || new Date().toISOString();
    f.error = f.error || '';
    files.materials.unshift(f);
  });
};

export const removeMaterial = (id: string) => {
  const i = files.materials.findIndex((m) => m.id === id);
  if (i > -1) files.materials.splice(i, 1);
};

export const addOutputs = (list: any[]) => {
  (list || []).forEach((f) => {
    if (files.outputs.find((o) => o.id === f.id)) return;
    // 同样存引用：产物从「生成中」走到「可下载」，两个页面同时更新
    files.outputs.unshift(f);
  });
};

export const removeOutput = (id: string) => {
  const i = files.outputs.findIndex((o) => o.id === id);
  if (i > -1) files.outputs.splice(i, 1);
};

export const fileStats = computed(() => {
  const mats = files.materials;
  const ok = mats.filter((m) => m.status === 'done');
  const bad = mats.filter((m) => m.status === 'error');
  return {
    count: mats.length,
    parsed: ok.length,
    failed: bad.length,
    outputs: files.outputs.length,
    bytes: mats.reduce((s, m) => s + (m.size || 0), 0),
    chunks: ok.reduce((s, m) => s + (m.chunks || 0), 0)
  };
});
