import { reactive } from 'vue';

/**
 * 全局视图状态。
 * 放在一个 reactive 里而不是层层 provide —— 顶栏、左栏、内容区都要读同一份，
 * 用注入会让「谁在谁里面」决定能不能用，反而更难改。
 */
export const ui = reactive({
  sidebarCollapsed: false,
  showSessions: true,
  showRefs: true,
  // 全局轻提示：文案 + 递增序号（序号变了说明是新的，动画重播）
  toast: '',
  toastSeq: 0,
  // 路由进度条：只在切换时递增一次，CSS 动画自己跑完再淡掉
  progressKey: 0
});

export const notify = (text) => {
  ui.toast = text;
  ui.toastSeq += 1;
  if (ui._timer) clearTimeout(ui._timer);
  ui._timer = setTimeout(() => {
    ui.toast = '';
  }, 2400);
};

/**
 * 路由切换时那条 2px 进度条。
 * 不用数值驱动宽度：那样「落地后归零」会看到往回缩一下。
 * 改成 key 变化 → 组件重挂 → CSS 动画从 0 冲到 1 → 延时淡出 → key 归零。
 */
export const startProgress = () => {
  ui.progressKey += 1;
  if (ui._pk) clearTimeout(ui._pk);
  ui._pk = setTimeout(() => {
    ui.progressKey = 0;
  }, 900);
};
