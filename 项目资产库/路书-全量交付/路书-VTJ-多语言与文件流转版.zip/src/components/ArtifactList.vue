<template>
  <div v-if="items.length" class="artifacts">
    <div class="art-head">
      <span class="art-title">{{ t('a.title') }}</span>
      <span class="art-count">{{ items.length }}</span>
    </div>

    <div class="art-list">
      <div v-for="(f, i) in items" :key="f.id" :class="['art-card', f.status]" :style="{ '--i': i }">
        <span :class="['art-ico', f.ext]">{{ f.ext.toUpperCase().slice(0, 3) }}</span>
        <div class="art-main">
          <div class="art-name" :title="f.name">{{ f.name }}</div>
          <div class="art-meta">
            <template v-if="f.status === 'generating'">
              {{ t('a.generating') }}
              <span class="art-pct">{{ f.progress }}%</span>
            </template>
            <template v-else>
              <span>{{ humanSize(f.size) }}</span>
              <span class="dot">·</span>
              <span>{{ t('a.rows', { n: f.items || 0 }) }}</span>
              <span class="dot">·</span>
              <span>{{ f.time }}</span>
            </template>
          </div>
          <div v-if="f.status === 'generating'" class="art-bar">
            <i :style="{ transform: 'scaleX(' + f.progress / 100 + ')' }"></i>
          </div>
        </div>
        <div v-if="f.status !== 'generating'" class="art-acts">
          <button class="aa" @click="preview(f)">{{ t('c.preview') }}</button>
          <button class="aa primary" @click="save(f)">{{ t('a.download') }}</button>
          <button class="aa icon" :title="t('a.copyLink')" @click="link(f)">⧉</button>
        </div>
        <span v-else class="art-spin" aria-hidden="true"></span>
      </div>
    </div>

    <div class="art-note">{{ t('a.demoLink') }}</div>

    <!-- 预览：不跳到新页面，就地摊开 -->
    <Teleport to="body">
      <Transition name="pv">
        <div v-if="pv" class="pv-mask" @click.self="pv = null">
          <div class="pv-box">
            <div class="pv-head">
              <span :class="['art-ico', pv.ext]">{{ pv.ext.toUpperCase().slice(0, 3) }}</span>
              <span class="pv-name">{{ pv.name }}</span>
              <span class="pv-size">{{ humanSize(pv.size) }}</span>
              <button class="pv-x" @click="pv = null">×</button>
            </div>
            <pre class="pv-body">{{ pv.previewText }}</pre>
            <div class="pv-foot">
              <span class="pv-hint">前 {{ PV_LINES }} 行 · 完整内容请下载</span>
              <button class="pv-dl" @click="save(pv)">{{ t('a.download') }}</button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref } from 'vue';
  import { useI18n } from '@/i18n';
  import { notify } from '@/store/ui';
  import { downloadText, humanSize, copyText } from '@/utils/download';

  const props = defineProps<{ items: any[] }>();
  const { t } = useI18n();
  const pv = ref(null);
  const PV_LINES = 40;

  const MIME = {
    md: 'text/markdown;charset=utf-8',
    csv: 'text/csv;charset=utf-8',
    txt: 'text/plain;charset=utf-8',
    json: 'application/json;charset=utf-8',
    pdf: 'application/pdf'
  };

  const preview = (f) => {
    const text = String(f.content || '');
    const lines = text.split('\n');
    pv.value = {
      ...f,
      previewText: lines.slice(0, PV_LINES).join('\n') + (lines.length > PV_LINES ? '\n…' : '')
    };
  };

  const save = (f) => {
    if (!f.content) {
      notify('这份文件没有可下载的内容');
      return;
    }
    downloadText(f.name, f.content, MIME[f.ext] || 'text/plain;charset=utf-8');
    notify(t('a.saved', { name: f.name }));
  };

  const link = async (f) => {
    const url = location.origin + location.pathname + '#/page/materials?f=' + f.id;
    const ok = await copyText(url);
    notify(ok ? t('a.copied') : '复制失败，请手动选中地址栏');
  };
</script>

<style lang="css" scoped>
  .artifacts {
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px dashed #e9edf3;
  }
  .art-head {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 7px;
  }
  .art-title {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.06em;
    color: #8a94a6;
  }
  .art-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 15px;
    height: 15px;
    padding: 0 4px;
    border-radius: 999px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .art-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .art-card {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 8px 9px;
    border: 1px solid #e9edf3;
    border-radius: 9px;
    background: #fff;
    animation: artIn 0.24s var(--m-ease) both;
    animation-delay: calc(var(--i) * 60ms);
    transition:
      border-color 0.16s var(--m-ease),
      box-shadow 0.16s var(--m-ease);
  }
  .art-card:hover {
    border-color: #cfdcf5;
    box-shadow: 0 4px 14px rgba(30, 60, 120, 0.06);
  }
  .art-ico {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 7px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.02em;
  }
  .art-ico.csv {
    background: #eaf7ef;
    color: #2c8a4b;
  }
  .art-ico.md {
    background: #f1f0ff;
    color: #5b53c8;
  }
  .art-main {
    flex: 1;
    min-width: 0;
  }
  .art-name {
    font-size: 12.5px;
    color: #1f2733;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .art-meta {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 2px;
    font-size: 10.5px;
    color: #98a1b0;
    font-variant-numeric: tabular-nums;
  }
  .art-meta .dot {
    color: #ccd3dd;
  }
  .art-pct {
    color: #2f6bff;
  }
  .art-bar {
    height: 2px;
    margin-top: 5px;
    border-radius: 2px;
    background: #eef1f6;
    overflow: hidden;
  }
  .art-bar i {
    display: block;
    height: 100%;
    background: linear-gradient(90deg, #2f6bff, #6f9bff);
    transform-origin: left center;
    transition: transform 0.2s linear;
  }
  .art-acts {
    display: flex;
    align-items: center;
    gap: 4px;
    flex-shrink: 0;
  }
  .aa {
    height: 24px;
    padding: 0 8px;
    border: 1px solid #e6eaf1;
    border-radius: 6px;
    background: #fff;
    color: #5a6473;
    font-size: 11px;
    cursor: pointer;
    transition:
      color 0.14s linear,
      border-color 0.14s linear,
      background 0.14s linear;
  }
  .aa:hover {
    color: #2f6bff;
    border-color: #c3d3fb;
    background: #f6f9ff;
  }
  .aa.primary {
    color: #2f6bff;
    border-color: #c9d8fb;
    background: #f4f8ff;
  }
  .aa.icon {
    width: 24px;
    padding: 0;
  }
  .art-spin {
    width: 13px;
    height: 13px;
    border: 1.6px solid #dfe6f3;
    border-top-color: #2f6bff;
    border-radius: 50%;
    animation: artSpin 0.7s linear infinite;
  }
  .art-note {
    margin-top: 6px;
    font-size: 10px;
    color: #b6bec9;
  }
  @keyframes artIn {
    from {
      opacity: 0;
      transform: translateY(4px);
    }
  }
  @keyframes artSpin {
    to {
      transform: rotate(360deg);
    }
  }

  .pv-mask {
    position: fixed;
    inset: 0;
    z-index: 3000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(18, 24, 36, 0.46);
    backdrop-filter: blur(2px);
  }
  .pv-box {
    width: min(680px, 82vw);
    max-height: 74vh;
    display: flex;
    flex-direction: column;
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 24px 60px rgba(12, 20, 36, 0.28);
    overflow: hidden;
  }
  .pv-head {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 12px 14px;
    border-bottom: 1px solid #eef1f6;
  }
  .pv-name {
    font-size: 13px;
    color: #1f2733;
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .pv-size {
    font-size: 11px;
    color: #98a1b0;
    font-variant-numeric: tabular-nums;
  }
  .pv-x {
    border: none;
    background: transparent;
    color: #9aa3b2;
    font-size: 18px;
    line-height: 1;
    cursor: pointer;
  }
  .pv-x:hover {
    color: #d64545;
  }
  .pv-body {
    flex: 1;
    margin: 0;
    padding: 14px 16px;
    overflow: auto;
    background: #fbfcfe;
    color: #33404f;
    font-family: 'SFMono-Regular', Consolas, monospace;
    font-size: 11.5px;
    line-height: 1.72;
    white-space: pre-wrap;
    word-break: break-word;
  }
  .pv-foot {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    border-top: 1px solid #eef1f6;
  }
  .pv-hint {
    font-size: 10.5px;
    color: #a5adba;
  }
  .pv-dl {
    height: 28px;
    padding: 0 12px;
    border: none;
    border-radius: 7px;
    background: #2f6bff;
    color: #fff;
    font-size: 12px;
    cursor: pointer;
  }
  .pv-dl:hover {
    background: #2559e0;
  }
  .pv-enter-active {
    animation: pvIn 0.2s var(--m-ease) both;
  }
  .pv-leave-active {
    transition: opacity 0.14s linear;
  }
  .pv-leave-to {
    opacity: 0;
  }
  @keyframes pvIn {
    from {
      opacity: 0;
      transform: translateY(6px) scale(0.99);
    }
  }
</style>
