<template>
  <div class="attach-tray">
    <!-- 已加的附件 -->
    <TransitionGroup v-if="files.length" name="chip" tag="div" class="chips">
      <div v-for="f in files" :key="f.id" :class="['file-chip', f.status]">
        <span :class="['fc-ico', f.kind]">
          <img v-if="f.kind === 'image' && f.thumb" :src="f.thumb" alt="" />
          <template v-else>{{ ICON[f.kind] || '▤' }}</template>
        </span>
        <span class="fc-main">
          <span class="fc-name" :title="f.name">{{ f.name }}</span>
          <span class="fc-meta">
            <template v-if="f.status === 'error'">
              <em class="fc-err">{{ f.error }}</em>
            </template>
            <template v-else-if="f.status === 'done'">
              {{ humanSize(f.size) }} · {{ t('u.done', { n: f.chunks }) }}
            </template>
            <template v-else>
              {{ humanSize(f.size) }} · {{ t('u.parsing') }}
              <span class="fc-pct">{{ f.progress }}%</span>
            </template>
          </span>
          <span v-if="f.status === 'parsing' || f.status === 'queued'" class="fc-bar">
            <i :style="{ transform: 'scaleX(' + f.progress / 100 + ')' }"></i>
          </span>
          <span v-if="f.excerpt" class="fc-excerpt">{{ f.excerpt }}</span>
        </span>
        <button class="fc-x" :title="t('c.remove')" @click="$emit('remove', f.id)">×</button>
      </div>
    </TransitionGroup>

    <div class="tray-foot">
      <button class="tray-btn" :title="t('u.attach')" @click="pickFiles">
        <span class="tb-ico">＋</span>
        <span>{{ t('u.attach') }}</span>
        <span v-if="files.length" class="tb-count">{{ files.length }}</span>
      </button>
      <span class="tray-note">{{ t('u.free') }}</span>
      <span v-if="files.length" class="tray-clear" @click="$emit('clear')">{{ t('u.removeAll') }}</span>
      <input
        ref="inputRef"
        type="file"
        multiple
        class="file-input"
        :accept="ACCEPT"
        @change="onPicked" />
    </div>

    <!-- 拖拽全屏遮罩：整页接住，不是只接输入框 -->
    <Transition name="veil">
      <div v-if="dragging" class="drop-veil">
        <div class="dv-box">
          <div class="dv-ico">⇩</div>
          <div class="dv-title">{{ t('u.drop') }}</div>
          <div class="dv-hint">{{ t('u.dropHint') }}</div>
        </div>
      </div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, watch, onMounted, onBeforeUnmount } from 'vue';
  import { useI18n } from '@/i18n';
  import { humanSize } from '@/utils/download';
  import { notify } from '@/store/ui';

  const props = defineProps<{ files: any[] }>();
  const emit = defineEmits(['add', 'remove', 'clear']);
  const { t } = useI18n();

  const ACCEPT = '.pdf,.doc,.docx,.txt,.md,.csv,.xls,.xlsx,.png,.jpg,.jpeg,.webp';
  const MAX = 20 * 1024 * 1024;
  const ICON = { doc: '▤', sheet: '▦', image: '▣', text: '≡' };

  const inputRef = ref(null);
  const dragging = ref(false);
  const pickFiles = () => inputRef.value && inputRef.value.click();
  const onPicked = (e) => {
    addFiles(Array.from(e.target.files || []));
    e.target.value = '';
  };

  const EXT_KIND = {
    pdf: 'doc',
    doc: 'doc',
    docx: 'doc',
    txt: 'text',
    md: 'text',
    csv: 'sheet',
    xls: 'sheet',
    xlsx: 'sheet',
    png: 'image',
    jpg: 'image',
    jpeg: 'image',
    webp: 'image'
  };

  let seq = 0;
  const timers = [];

  const addFiles = (list) => {
    if (!list || !list.length) return;
    const out = [];
    list.forEach((raw) => {
      const ext = (raw.name.split('.').pop() || '').toLowerCase();
      const kind = EXT_KIND[ext];
      const item = {
        id: 'f' + Date.now() + '-' + seq++,
        name: raw.name,
        ext,
        kind: kind || 'doc',
        size: raw.size,
        status: kind ? 'queued' : 'error',
        progress: 0,
        chunks: 0,
        error: kind ? '' : t('u.badType'),
        thumb: '',
        excerpt: ''
      };
      if (kind && raw.size > MAX) {
        item.status = 'error';
        item.error = t('u.tooBig');
      }
      if (kind === 'image' && item.status !== 'error') {
        try {
          item.thumb = URL.createObjectURL(raw);
        } catch (e) {
          /* 拿不到缩略图不影响上传 */
        }
      }
      // 原始 File 留着：真正读取放到父组件把对象装进响应式数组之后（见下面的 watch）
      item._file = raw;
      out.push(item);
    });
    emit('add', out);
  };

  /**
   * 父组件把文件 concat 进响应式数组之后，这里拿到的才是代理对象。
   * 直接改 emit 出去的那个原始对象，界面不会更新 —— 进度条会一直停在 0%。
   */
  watch(
    () => props.files,
    (list) => {
      (list || []).forEach((f) => {
        if (f.status === 'queued' && !f._started) {
          f._started = true;
          startParse(f);
          if (f.kind === 'text' && f._file && !f._read) {
            f._read = true;
            try {
              const reader = new FileReader();
              reader.onload = () => {
                f.excerpt = String(reader.result || '').replace(/\s+/g, ' ').slice(0, 90);
              };
              reader.readAsText(f._file.slice(0, 4000));
            } catch (e) {
              /* 读不出来就只显示文件名 */
            }
          }
        }
      });
    },
    { immediate: true }
  );

  /** 演示环境的解析：进度条按节奏推到 100%，再给一个稳定的段数（按文件名算，不随机跳） */
  const startParse = (item) => {
    timers.push(
      setTimeout(() => {
        item.status = 'parsing';
        const tick = setInterval(() => {
          item.progress = Math.min(100, item.progress + 6 + ((item.name.length * 3) % 9));
          if (item.progress >= 100) {
            clearInterval(tick);
            item.status = 'done';
            let h = 0;
            for (let i = 0; i < item.name.length; i++) h = (h * 31 + item.name.charCodeAt(i)) % 997;
            item.chunks = 3 + (h % 9);
          }
        }, 90);
        timers.push(tick);
      }, 180)
    );
  };

  /* 拖拽：window 级监听，但要挡住浏览器默认的「打开文件」 */
  let dragDepth = 0;
  const onDragEnter = (e) => {
    if (!e.dataTransfer || Array.from(e.dataTransfer.types || []).indexOf('Files') < 0) return;
    dragDepth += 1;
    dragging.value = true;
  };
  const onDragOver = (e) => {
    if (!e.dataTransfer || Array.from(e.dataTransfer.types || []).indexOf('Files') < 0) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  };
  const onDragLeave = () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) dragging.value = false;
  };
  const onDrop = (e) => {
    if (!e.dataTransfer) return;
    e.preventDefault();
    dragDepth = 0;
    dragging.value = false;
    const list = Array.from(e.dataTransfer.files || []);
    if (list.length) {
      addFiles(list);
      notify(t('u.attached', { n: list.length }));
    }
  };
  const onPaste = (e) => {
    const items = (e.clipboardData && e.clipboardData.items) || [];
    const picked = [];
    for (let i = 0; i < items.length; i++) {
      if (items[i].kind === 'file') {
        const f = items[i].getAsFile();
        if (f) picked.push(f);
      }
    }
    if (picked.length) addFiles(picked);
  };

  onMounted(() => {
    window.addEventListener('dragenter', onDragEnter);
    window.addEventListener('dragover', onDragOver);
    window.addEventListener('dragleave', onDragLeave);
    window.addEventListener('drop', onDrop);
    window.addEventListener('paste', onPaste);
  });
  onBeforeUnmount(() => {
    window.removeEventListener('dragenter', onDragEnter);
    window.removeEventListener('dragover', onDragOver);
    window.removeEventListener('dragleave', onDragLeave);
    window.removeEventListener('drop', onDrop);
    window.removeEventListener('paste', onPaste);
    timers.forEach((x) => {
      clearTimeout(x);
      clearInterval(x);
    });
    props.files.forEach((f) => {
      if (f.thumb) URL.revokeObjectURL(f.thumb);
    });
  });
</script>

<style lang="css" scoped>
  .attach-tray {
    display: flex;
    flex-direction: column;
    gap: 7px;
  }
  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    max-height: 108px;
    overflow: auto;
  }
  .file-chip {
    display: flex;
    align-items: flex-start;
    gap: 7px;
    max-width: 264px;
    padding: 6px 7px;
    border: 1px solid #e8ebf0;
    border-radius: 8px;
    background: #fafbfd;
    transition:
      border-color 0.16s var(--m-ease),
      background 0.16s var(--m-ease);
  }
  .file-chip:hover {
    border-color: #dce3ef;
    background: #f7f9fc;
  }
  .file-chip.error {
    border-color: #f4d3d3;
    background: #fff8f8;
  }
  .file-chip.done .fc-ico {
    background: #eaf7ef;
    color: #2c8a4b;
  }
  .fc-ico {
    width: 22px;
    height: 22px;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 11px;
    overflow: hidden;
  }
  .fc-ico img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .fc-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
    flex: 1;
  }
  .fc-name {
    font-size: 12px;
    color: #1f2733;
    max-width: 178px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.3;
  }
  .fc-meta {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 10.5px;
    color: #98a1b0;
    font-variant-numeric: tabular-nums;
  }
  .fc-err {
    color: #d64545;
    font-style: normal;
  }
  .fc-pct {
    color: #2f6bff;
  }
  .fc-bar {
    display: block;
    height: 2px;
    margin-top: 1px;
    border-radius: 2px;
    background: #e9edf4;
    overflow: hidden;
  }
  .fc-bar i {
    display: block;
    height: 100%;
    background: linear-gradient(90deg, #2f6bff, #6f9bff);
    transform-origin: left center;
    transition: transform 0.18s linear;
  }
  .fc-excerpt {
    font-size: 10px;
    color: #b3bac6;
    max-width: 178px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .fc-x {
    flex-shrink: 0;
    padding: 0 1px;
    border: none;
    background: transparent;
    color: #b6bec9;
    font-size: 14px;
    line-height: 1;
    cursor: pointer;
    transition: color 0.14s linear;
  }
  .fc-x:hover {
    color: #d64545;
  }
  .tray-foot {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .tray-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    height: 26px;
    padding: 0 9px;
    border: 1px dashed #d8dee8;
    border-radius: 7px;
    background: #fff;
    color: #5a6473;
    font-size: 12px;
    cursor: pointer;
    transition:
      border-color 0.16s var(--m-ease),
      color 0.16s var(--m-ease),
      background 0.16s var(--m-ease);
  }
  .tray-btn:hover {
    border-color: #b9cdfd;
    background: #f6f9ff;
    color: #2f6bff;
  }
  .tb-ico {
    font-size: 12px;
    line-height: 1;
  }
  .tb-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 15px;
    height: 15px;
    padding: 0 4px;
    border-radius: 999px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .tray-note {
    font-size: 10.5px;
    color: #b0b8c4;
  }
  .tray-clear {
    margin-left: auto;
    font-size: 10.5px;
    color: #98a1b0;
    cursor: pointer;
    text-decoration: underline dotted;
    text-underline-offset: 2px;
  }
  .tray-clear:hover {
    color: #d64545;
  }
  .file-input {
    display: none;
  }
  .chip-enter-active {
    animation: chipIn 0.2s var(--m-ease) both;
  }
  .chip-leave-active {
    transition:
      opacity 0.14s linear,
      transform 0.14s var(--m-ease);
  }
  .chip-leave-to {
    opacity: 0;
    transform: scale(0.94);
  }
  @keyframes chipIn {
    from {
      opacity: 0;
      transform: translateY(4px) scale(0.96);
    }
  }
  .drop-veil {
    position: fixed;
    inset: 0;
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(24, 32, 48, 0.42);
    backdrop-filter: blur(2px);
  }
  .dv-box {
    width: min(430px, 72vw);
    padding: 34px 26px;
    border: 2px dashed rgba(255, 255, 255, 0.62);
    border-radius: 18px;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    text-align: center;
  }
  .dv-ico {
    margin-bottom: 12px;
    font-size: 30px;
    line-height: 1;
    animation: dvBob 1.3s var(--m-ease) infinite;
  }
  .dv-title {
    font-size: 17px;
    font-weight: 600;
    letter-spacing: 0.01em;
  }
  .dv-hint {
    margin-top: 6px;
    font-size: 12px;
    opacity: 0.82;
  }
  .veil-enter-active,
  .veil-leave-active {
    transition: opacity 0.16s linear;
  }
  .veil-enter-from,
  .veil-leave-to {
    opacity: 0;
  }
  @keyframes dvBob {
    50% {
      transform: translateY(-5px);
    }
  }
</style>
