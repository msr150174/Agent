<template>
  <div class="tabbar" ref="barEl">
    <div class="tab-strip" ref="stripEl">
      <div
        v-for="(tab, i) in tabs"
        :key="tab.path"
        class="tab"
        :class="{
          active: tab.path === current,
          dragging: drag.active && drag.from === i,
          'is-home': i === 0
        }"
        :data-i="i"
        @pointerdown="onDown($event, i)"
        @click="onClick(tab)"
        @auxclick.middle.prevent="closeTab(i)">
        <span class="tab-idx">{{ String(i + 1).padStart(2, '0') }}</span>
        <span class="tab-label">{{ titleOf(tab.path) }}</span>
        <button
          v-if="tabs.length > 1"
          class="tab-x"
          :title="t('c.close') + ' ' + titleOf(tab.path)"
          @click.stop="closeTab(i)">
          <svg viewBox="0 0 10 10" width="9" height="9" aria-hidden="true">
            <path
              d="M2 2l6 6M8 2l-6 6"
              stroke="currentColor"
              stroke-width="1.4"
              stroke-linecap="round" />
          </svg>
        </button>
      </div>
      <!-- 滑动下划线：只有一条，靠 transform 移动，不逐标签重绘 -->
      <i class="tab-ink" :style="inkStyle"></i>
    </div>

    <div class="tab-tools">
      <LangMenu></LangMenu>
      <button class="tool-btn press" title="命令面板（Ctrl/⌘ + K）" @click="$emit('palette')">
        <svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true">
          <circle cx="7" cy="7" r="4.4" fill="none" stroke="currentColor" stroke-width="1.5" />
          <path d="M10.4 10.4L14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
        </svg>
      </button>
      <span class="tab-hint"><span class="kbd">Ctrl</span><span class="kbd">K</span></span>
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed, watch, onMounted, onBeforeUnmount, nextTick } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import LangMenu from '@/components/LangMenu.vue';
  import { useI18n } from '@/i18n';

  const { t, lang, isEn } = useI18n();

  // 标签标题不存快照：存 path，渲染时再翻 —— 否则切语言后旧标签还是旧文案
  const PATH_KEY = {
    '/page/chat-workspace': 'nav.chat',
    '/page/self-assessment': 'nav.assess',
    '/page/career-library': 'nav.career',
    '/page/growth-plan': 'nav.plan',
    '/page/knowledge-base': 'nav.kb',
    '/page/materials': 'nav.materials',
    '/page/call-logs': 'nav.logs',
    '/page/kb-manager': 'nav.manage'
  };

  const route = useRoute();
  const router = useRouter();
  const emit = defineEmits(['palette']);

  const HOME = '/page/chat-workspace';
  const tabs = ref([{ path: HOME }]);
  const current = ref(route.path);
  const barEl = ref(null);
  const stripEl = ref(null);

  const inkStyle = ref({ width: '0px', transform: 'translateX(0px)', opacity: 0 });

  const titleOf = (p) => (PATH_KEY[p] ? t(PATH_KEY[p]) : isEn.value ? 'Page' : '页面');

  /** 下划线跟着当前标签走：读 DOM 的 offset，不猜宽度 */
  const syncInk = () => {
    nextTick(() => {
      const strip = stripEl.value;
      if (!strip) return;
      const el = strip.querySelector('.tab.active');
      if (!el) {
        inkStyle.value = { ...inkStyle.value, opacity: 0 };
        return;
      }
      inkStyle.value = {
        width: el.offsetWidth - 12 + 'px',
        transform: `translateX(${el.offsetLeft + 6}px)`,
        opacity: 1
      };
    });
  };

  watch(lang, () => syncInk());

  watch(
    () => route.path,
    (p) => {
      if (!p || p.indexOf('/page/') !== 0) return;
      current.value = p;
      if (!tabs.value.some((t) => t.path === p)) {
        tabs.value.push({ path: p });
      }
      syncInk();
      // 新标签可能在可视区外，滚进来
      nextTick(() => {
        const strip = stripEl.value;
        const el = strip && strip.querySelector('.tab.active');
        if (el && strip) {
          const left = el.offsetLeft;
          const right = left + el.offsetWidth;
          if (left < strip.scrollLeft) strip.scrollTo({ left: left - 8, behavior: 'smooth' });
          else if (right > strip.scrollLeft + strip.clientWidth)
            strip.scrollTo({ left: right - strip.clientWidth + 8, behavior: 'smooth' });
        }
      });
    },
    { immediate: true }
  );

  /* ── 拖拽换位 ────────────────────────────────────────────────
     参考实现的三个要点：不用 HTML5 拖放（拖影不可控）、
     5px 阈值区分「点」和「拖」、拖完在 capture 阶段吞掉那次 click。 */
  const drag = ref({ from: -1, to: -1, startX: 0, active: false });
  const swallowClick = ref(false);

  const onDown = (e, i) => {
    if (e.button !== 0) return;
    if (e.target.closest('.tab-x')) return;
    drag.value = { from: i, to: i, startX: e.clientX, active: false };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp, { once: true });
  };

  const onMove = (e) => {
    const d = drag.value;
    if (d.from < 0) return;
    if (!d.active) {
      if (Math.abs(e.clientX - d.startX) < 5) return;
      d.active = true;
    }
    const strip = stripEl.value;
    if (!strip) return;
    const els = Array.from(strip.querySelectorAll('.tab'));
    let to = 0;
    for (let i = 0; i < els.length; i++) {
      const r = els[i].getBoundingClientRect();
      if (e.clientX > r.left + r.width / 2) to = i + 1;
    }
    d.to = to;
  };

  const onUp = () => {
    const d = drag.value;
    window.removeEventListener('pointermove', onMove);
    if (d.active && d.from >= 0) {
      swallowClick.value = true;
      const arr = tabs.value.slice();
      const [moved] = arr.splice(d.from, 1);
      const at = d.to > d.from ? d.to - 1 : d.to;
      arr.splice(at, 0, moved);
      tabs.value = arr;
      setTimeout(() => (swallowClick.value = false), 0);
      syncInk();
    }
    drag.value = { from: -1, to: -1, startX: 0, active: false };
  };

  const onClick = (tab) => {
    if (swallowClick.value) return;
    if (tab.path === current.value) return;
    router.push(tab.path);
  };

  const closeTab = (i) => {
    if (tabs.value.length <= 1) return;
    const closing = tabs.value[i];
    tabs.value.splice(i, 1);
    if (closing.path === current.value) {
      const next = tabs.value[Math.min(i, tabs.value.length - 1)];
      if (next) router.push(next.path);
    } else {
      syncInk();
    }
  };

  /* 滚轮转横向滚动：标签条最顺手的手势 */
  const onWheel = (e) => {
    const strip = stripEl.value;
    if (!strip) return;
    if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
    if (strip.scrollWidth <= strip.clientWidth) return;
    strip.scrollLeft += e.deltaY;
    e.preventDefault();
  };

  onMounted(() => {
    barEl.value && barEl.value.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('resize', syncInk);
    syncInk();
  });
  onBeforeUnmount(() => {
    barEl.value && barEl.value.removeEventListener('wheel', onWheel);
    window.removeEventListener('resize', syncInk);
    window.removeEventListener('pointermove', onMove);
  });

  defineExpose({ syncInk });
</script>

<style lang="css" scoped>
  .tabbar {
    flex-shrink: 0;
    display: flex;
    align-items: flex-end;
    gap: 8px;
    padding: 6px 10px 0;
    background: #fff;
    border-bottom: 1px solid var(--m-line);
    position: relative;
    z-index: 5;
  }
  .tab-strip {
    position: relative;
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: flex-end;
    gap: 2px;
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: none;
  }
  .tab-strip::-webkit-scrollbar {
    display: none;
  }
  .tab {
    position: relative;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    height: 30px;
    padding: 0 8px 0 7px;
    border-radius: 7px 7px 0 0;
    color: var(--m-ink-2);
    font-size: 12.5px;
    cursor: pointer;
    user-select: none;
    /* 只动 background / color / transform，不动宽度 */
    transition:
      background var(--m-fast) var(--m-ease),
      color var(--m-fast) var(--m-ease),
      transform var(--m-fast) var(--m-ease);
  }
  .tab:hover {
    background: #f6f8fb;
    color: var(--m-ink);
  }
  .tab.active {
    background: #fff;
    color: var(--m-ink);
    font-weight: 500;
  }
  .tab.dragging {
    transform: scale(1.03);
    background: #fff;
    color: var(--m-accent);
    box-shadow: var(--m-shadow-2);
    z-index: 3;
    cursor: grabbing;
  }
  .tab-idx {
    font-size: 10px;
    color: #c2c8d2;
    font-variant-numeric: tabular-nums;
    transition: color var(--m-fast) var(--m-ease);
  }
  .tab.active .tab-idx {
    color: var(--m-accent);
  }
  .tab-label {
    white-space: nowrap;
  }
  .tab-x {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 15px;
    height: 15px;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: #b6bdc9;
    cursor: pointer;
    opacity: 0;
    transform: scale(0.85);
    transition:
      opacity var(--m-fast) var(--m-ease),
      transform var(--m-fast) var(--m-ease),
      background var(--m-fast) var(--m-ease);
  }
  .tab:hover .tab-x,
  .tab.active .tab-x {
    opacity: 1;
    transform: none;
  }
  .tab-x:hover {
    background: #eef1f6;
    color: #e5484d;
  }
  /* 唯一的那条下划线 */
  .tab-ink {
    position: absolute;
    left: 0;
    bottom: 0;
    height: 2px;
    border-radius: 2px 2px 0 0;
    background: var(--m-accent);
    pointer-events: none;
    transition:
      transform var(--m-mid) var(--m-ease),
      width var(--m-mid) var(--m-ease),
      opacity var(--m-fast) linear;
  }
  .tab-tools {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding-bottom: 6px;
  }
  .tool-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    padding: 0;
    border: 1px solid var(--m-line);
    border-radius: 6px;
    background: #fff;
    color: var(--m-ink-2);
    cursor: pointer;
    transition:
      color var(--m-fast) var(--m-ease),
      border-color var(--m-fast) var(--m-ease),
      background var(--m-fast) var(--m-ease);
  }
  .tool-btn:hover {
    color: var(--m-accent);
    border-color: #cfdcff;
    background: #f7f9ff;
  }
  .tab-hint {
    display: inline-flex;
    gap: 2px;
    opacity: 0.9;
  }
  @media (max-width: 1100px) {
    .tab-hint {
      display: none;
    }
  }
</style>
