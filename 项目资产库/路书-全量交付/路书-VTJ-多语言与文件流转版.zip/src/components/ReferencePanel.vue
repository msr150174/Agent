<template>
  <div class="reference-panel">
    <div class="tab-header">
      <button
        v-for="tab in tabs"
        :key="tab.key"
        :class="['tab-btn', { active: activeTab === tab.key }]"
        @click="activeTab = tab.key">
        {{ tab.label }}
      </button>
      <!-- 滑动指示条：三个页签等宽，所以位移 = 下标 × 100% -->
      <span class="tab-indicator" :style="{ transform: `translateX(${activeIndex * 100}%)` }"></span>
    </div>

    <div class="tab-content">
      <div v-if="activeTab === 'references'" class="panel-section">
        <div class="section-title">本次来源 · 点一条可复制引用</div>
        <div class="ref-list">
          <div
            v-for="(item, i) in references"
            :key="i"
            class="ref-card"
            :style="{ animationDelay: i * 60 + 'ms' }"
            @click="emit('copy', item)">
            <div class="ref-title">{{ item.title }}</div>
            <div class="ref-excerpt">{{ item.excerpt }}</div>
            <div class="ref-meta">
              <span>{{ item.group }}</span>
              <span>{{ item.date }}</span>
            </div>
          </div>
        </div>
        <div v-if="references.length === 0" class="empty">
          这次回答没有引用 —— 没有出处的答案，我不给。
        </div>
      </div>

      <div v-if="activeTab === 'knowledge'" class="panel-section">
        <div class="section-title">知识库 · A–E 五组 37 篇</div>
        <div class="kb-list">
          <div
            v-for="(kb, ki) in knowledgeList"
            :key="kb.id"
            class="kb-card"
            :style="{ animationDelay: ki * 50 + 'ms' }">
            <div class="kb-top">
              <span class="kb-name">{{ kb.name }}</span>
              <span class="kb-badge">{{ kb.count }} 篇</span>
            </div>
            <div class="kb-desc">{{ kb.description }}</div>
          </div>
        </div>
      </div>

      <div v-if="activeTab === 'profile'" class="panel-section">
        <div class="section-title">我的档案</div>
        <div class="profile-card">
          <div class="profile-header">
            <div class="profile-avatar">
              {{ profile.name ? profile.name.slice(0, 1) : '学' }}
            </div>
            <div class="profile-info">
              <div class="profile-name">{{ profile.name }}</div>
              <div class="profile-meta">
                <span>{{ profile.major }}</span>
                <span> · </span>
                <span>{{ profile.grade }}</span>
              </div>
            </div>
          </div>

          <div class="profile-section">
            <div class="profile-label">现在想解决</div>
            <div class="profile-value">{{ profile.goal }}</div>
          </div>

          <div class="profile-section">
            <div class="profile-label">六类相对分</div>
            <template v-if="profile.dims && profile.dims.length">
              <div v-for="d in profile.dims" :key="d.name" class="dim-row">
                <span class="dim-name">{{ d.name }}</span>
                <div class="dim-track">
                  <div class="dim-fill" :style="{ width: d.rel + '%' }"></div>
                </div>
              </div>
            </template>
            <div v-else class="dim-hint">
              还没做「认识自己」的 12 道题，做完这里会显示六类偏好。
            </div>
          </div>

          <p class="profile-note">
            相对分只表示你在这六类里更偏向哪边，不是测评结论，也不代表你适合或不适合什么。
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed, useAttrs } from 'vue';

  const attrs = useAttrs();
  const pick = (name) => {
    const camel = name.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    return attrs[camel] !== undefined ? attrs[camel] : attrs[name];
  };
  const references = computed(() => pick('references') || []);
  const profile = computed(
    () =>
      pick('profile') || {
        name: '李同学',
        major: '计算机应用技术',
        grade: '大一',
        goal: '还没定：专插本 / 就业',
        dims: []
      }
  );
  const knowledgeList = computed(
    () =>
      pick('knowledge-list') || [
        { id: 'A', name: 'A 专业与岗位', count: 8, description: '各专业对口岗位、能力项与本校去向' },
        { id: 'B', name: 'B 证书与考试', count: 6, description: '1+X、等级考试、专插本科目说明' },
        { id: 'C', name: 'C 岗位与能力', count: 9, description: '按岗位拆到能力项，可逐条对照' },
        { id: 'D', name: 'D 行业与就业数据', count: 7, description: '本校回收样本与招聘观察' },
        { id: 'E', name: 'E 求职技能', count: 7, description: '简历、面试、项目表达' }
      ]
  );

  const tabs = [
    { key: 'references', label: '本次来源' },
    { key: 'knowledge', label: '知识库' },
    { key: 'profile', label: '我的档案' }
  ];
  const activeTab = ref('references');
  const activeIndex = computed(() => {
    const i = tabs.findIndex((t) => t.key === activeTab.value);
    return i < 0 ? 0 : i;
  });
  const emit = (name, ...args) => {
    const key = 'on' + name.charAt(0).toUpperCase() + name.slice(1);
    const handler = attrs[key];
    if (typeof handler === 'function') handler(...args);
  };
</script>

<style lang="css" scoped>
  @keyframes cardIn {
    from {
      opacity: 0;
      transform: translateY(6px);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  .reference-panel {
    height: 100%;
    display: flex;
    flex-direction: column;
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    box-sizing: border-box;
    overflow: hidden;
  }
  .tab-header {
    position: relative;
    display: flex;
    flex-shrink: 0;
    padding: 0 14px;
    border-bottom: 1px solid #f0f1f3;
  }
  .tab-btn {
    flex: 1;
    padding: 12px 0;
    border: none;
    background: transparent;
    color: #6b7280;
    font-size: 12.5px;
    cursor: pointer;
    transition: color 0.16s ease;
  }
  .tab-btn:hover {
    color: #1f2937;
  }
  .tab-btn.active {
    color: #2f6bff;
    font-weight: 500;
  }
  /* 指示条只动 transform，宽度固定 1/3 —— 不需要 JS 量位置 */
  .tab-indicator {
    position: absolute;
    left: 14px;
    bottom: -1px;
    width: calc((100% - 28px) / 3);
    height: 2px;
    border-radius: 2px 2px 0 0;
    background: #2f6bff;
    box-shadow: 0 0 8px rgba(47, 107, 255, 0.55);
    transition: transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .tab-content {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    padding: 14px;
  }
  .section-title {
    font-size: 12px;
    color: #9ca3af;
    margin-bottom: 10px;
    letter-spacing: 0.3px;
  }
  .ref-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .ref-card {
    border: 1px solid #eef0f3;
    border-radius: 8px;
    padding: 10px 12px;
    background: #fbfcfe;
    cursor: pointer;
    animation: cardIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
    transition: border-color 0.16s ease, background 0.16s ease,
      transform 0.16s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.16s ease;
  }
  .ref-card:hover {
    border-color: #c9d8ff;
    background: #f7f9ff;
    transform: translateY(-1px);
    box-shadow: 0 4px 14px rgba(47, 107, 255, 0.1);
  }
  .ref-card:active {
    transform: translateY(0) scale(0.995);
  }
  .ref-title {
    font-size: 12.5px;
    font-weight: 600;
    color: #1f2937;
    line-height: 1.6;
  }
  .ref-excerpt {
    margin-top: 4px;
    font-size: 11.5px;
    line-height: 1.7;
    color: #6b7280;
  }
  .ref-meta {
    margin-top: 6px;
    display: flex;
    gap: 8px;
    font-size: 11px;
    color: #9ca3af;
  }
  .kb-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .kb-card {
    border: 1px solid #eef0f3;
    border-radius: 8px;
    padding: 9px 12px;
    animation: cardIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .kb-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .kb-name {
    font-size: 12.5px;
    color: #1f2937;
    font-weight: 500;
  }
  .kb-badge {
    font-size: 11px;
    color: #2f6bff;
    background: #eef3fe;
    border-radius: 10px;
    padding: 1px 7px;
  }
  .kb-desc {
    margin-top: 4px;
    font-size: 11.5px;
    line-height: 1.6;
    color: #9ca3af;
  }
  .profile-card {
    border: 1px solid #eef0f3;
    border-radius: 8px;
    padding: 12px;
  }
  .profile-header {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .profile-avatar {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: #e0e7ff;
    color: #2f6bff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 13px;
  }
  .profile-name {
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
  }
  .profile-meta {
    font-size: 11.5px;
    color: #9ca3af;
    margin-top: 2px;
  }
  .profile-section {
    margin-top: 12px;
  }
  .profile-label {
    font-size: 11px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .profile-value {
    font-size: 12.5px;
    color: #374151;
  }
  .dim-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 6px;
  }
  .dim-name {
    width: 58px;
    flex-shrink: 0;
    font-size: 11.5px;
    color: #6b7280;
  }
  .dim-track {
    flex: 1;
    height: 6px;
    background: #f3f4f6;
    border-radius: 3px;
    overflow: hidden;
  }
  .dim-fill {
    height: 100%;
    background: #2f6bff;
    border-radius: 3px;
    transform-origin: left center;
    animation: barGrow 0.6s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  @keyframes barGrow {
    from {
      transform: scaleX(0);
    }
    to {
      transform: scaleX(1);
    }
  }
  .dim-hint {
    font-size: 11.5px;
    line-height: 1.7;
    color: #b9bdc4;
  }
  .profile-note {
    margin: 12px 0 0;
    padding-top: 10px;
    border-top: 1px dashed #eef0f3;
    font-size: 11px;
    line-height: 1.7;
    color: #9ca3af;
  }
  .empty {
    padding: 24px 0;
    text-align: center;
    font-size: 12px;
    line-height: 1.8;
    color: #b9bdc4;
  }
</style>
