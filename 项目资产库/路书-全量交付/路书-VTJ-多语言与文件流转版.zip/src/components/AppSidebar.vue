<template>
  <aside :class="['app-sidebar', { collapsed: collapsed }]">
    <div class="brand">
      <div class="brand-logo">路</div>
      <div class="brand-info">
        <div class="brand-name">{{ isEn ? 'Lushu Workbench' : '路书工作台' }}</div>
        <div class="brand-sub">{{ isEn ? 'Your own career planning assistant' : '你自己的职业规划助手' }}</div>
      </div>
    </div>

    <button
      class="collapse-btn"
      :title="collapsed ? '展开侧栏' : '收成图标条'"
      @click="collapsed = !collapsed">
      <span class="chev" :class="{ flip: collapsed }">‹</span>
    </button>

    <div class="demo-chip">演示数据 · 正式版接 A–E 五组知识库</div>

    <nav class="nav">
      <span class="nav-group-title">{{ t('nav.student') }}</span>
      <div
        v-for="item in navItems"
        :key="item.route"
        :class="['nav-item', { active: isActive(item.route) }]"
        @click="handleNav(item.route)">
        <span class="nav-ico">{{ item.icon }}</span>
        <span class="nav-label">{{ item.label }}</span>
        <span
          v-if="item.route === '/page/self-assessment'"
          class="nav-badge"
          >12 题</span
        >
        <span class="nav-tip">{{ item.label }}</span>
      </div>

      <div class="nav-group-title teacher-toggle" @click="teacherOpen = !teacherOpen">
        <span class="nav-label">{{ t('nav.teacher') }}</span>
        <span class="teacher-note">
          {{ isEn ? 'Hidden from students' : '学生不可见' }} · {{ teacherOpen ? t('c.less') : t('c.more') }}
        </span>
      </div>
      <div v-if="teacherOpen" class="teacher-block">
        <div class="teacher-hint">
          {{
            isEn
              ? 'These two pages are for teachers: chain logs and KB upkeep. Students do not see them.'
              : '这两页是给老师看链路和维护知识库的，学生端不显示。'
          }}
        </div>
        <div
          v-for="item in teacherNav"
          :key="item.route"
          :class="['nav-item', 'subtle', { active: isActive(item.route) }]"
          @click="handleNav(item.route)">
          <span class="nav-ico">{{ item.icon }}</span>
          <span class="nav-label">{{ item.label }}</span>
          <span class="nav-tip">{{ item.label }}</span>
        </div>
      </div>
    </nav>

    <div class="current-user">
      <div class="user-avatar">{{ currentUser.avatarText }}</div>
      <div class="user-info">
        <div class="user-name">{{ currentUser.name }}</div>
        <div class="user-role">{{ currentUser.role }}</div>
      </div>
    </div>

    <!-- 状态小字：把「我以为」变成「看得见」—— 参考实现要求每层写入都有可读落点 -->
    <div class="sys-line">
      <span class="dot live"></span>
      <span class="sys-text">
        {{ isEn ? 'KB 37 docs · updated 03-09' : '知识库 37 篇 · 最近更新 03-09' }}
      </span>
    </div>
  </aside>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { ui } from '@/store/ui';
  import { useI18n } from '@/i18n';

  const route = useRoute();
  const router = useRouter();

  const { t, isEn } = useI18n();

  // label 走 t()：切语言时 computed 重新算，不用各自监听
  const navItems = computed(() => [
    { label: t('nav.chat'), route: '/page/chat-workspace', icon: '❝' },
    { label: t('nav.assess'), route: '/page/self-assessment', icon: '✎' },
    { label: t('nav.career'), route: '/page/career-library', icon: '◎' },
    { label: t('nav.plan'), route: '/page/growth-plan', icon: '☰' },
    { label: t('nav.kb'), route: '/page/knowledge-base', icon: '▤' },
    { label: t('nav.materials'), route: '/page/materials', icon: '⇅' }
  ]);

  const teacherNav = computed(() => [
    { label: t('nav.logs'), route: '/page/call-logs', icon: '≡' },
    { label: t('nav.manage'), route: '/page/kb-manager', icon: '⚙' }
  ]);

  const teacherOpen = ref(false);
  // 折叠成图标条：264px ↔ 64px，宽度走同一条曲线（参考实现里「未激活标签收成图标」的同一招）
  // 状态放到全局 store —— 顶栏的 Ctrl+B 和命令面板都要能控制它
  const collapsed = computed({
    get: () => ui.sidebarCollapsed,
    set: (v) => (ui.sidebarCollapsed = v)
  });

  const currentUser = reactive({
    name: '李同学',
    role: '计算机应用技术 · 大一',
    avatarText: '李'
  });

  const isActive = (path: string) => route.path === path;
  const handleNav = (path: string) => {
    if (route.path !== path) router.push(path);
  };
</script>

<style lang="css" scoped>
  .app-sidebar {
    position: relative;
    width: 264px;
    height: 100%;
    flex-shrink: 0;
    background: #fff;
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    transition: width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .app-sidebar.collapsed {
    width: 64px;
  }

  /* ── 折叠把手：贴在右边界外，位置永远不变，箭头转 180° ── */
  .collapse-btn {
    position: absolute;
    right: -11px;
    top: 96px;
    z-index: 6;
    width: 22px;
    height: 44px;
    padding: 0;
    border: 1px solid #eef0f3;
    border-radius: 11px;
    background: #fff;
    color: #9ca3af;
    cursor: pointer;
    display: grid;
    place-items: center;
    box-shadow: 0 1px 4px rgba(20, 25, 35, 0.08);
    transition: color 0.16s ease, box-shadow 0.16s ease, background 0.16s ease;
  }
  .collapse-btn:hover {
    color: #2f6bff;
    background: #f7f9ff;
    box-shadow: 0 2px 10px rgba(47, 107, 255, 0.18);
  }
  .collapse-btn:active {
    transform: scale(0.94);
  }
  .chev {
    font-size: 15px;
    line-height: 1;
    transition: transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .chev.flip {
    transform: rotate(180deg);
  }

  .brand {
    height: 64px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    border-bottom: 1px solid #f0f1f3;
    gap: 12px;
    flex-shrink: 0;
    overflow: hidden;
  }
  .brand-logo {
    width: 36px;
    height: 36px;
    background: #2f6bff;
    color: #fff;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 16px;
    flex-shrink: 0;
    transition: transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .collapsed .brand {
    padding: 0 14px;
  }
  .collapsed .brand-logo {
    transform: scale(0.94);
  }
  .brand-info {
    min-width: 0;
    /* 收起时靠 max-width 过渡：两端都是确定值，能动画；用 auto 动不了 */
    max-width: 180px;
    opacity: 1;
    overflow: hidden;
    white-space: nowrap;
    transition: max-width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.16s ease,
      transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .collapsed .brand-info {
    max-width: 0;
    opacity: 0;
    transform: translateX(-4px);
  }
  .brand-name {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    line-height: 1.2;
  }
  .brand-sub {
    font-size: 11px;
    color: #9ca3af;
    margin-top: 2px;
  }

  .demo-chip {
    margin: 10px 12px 0;
    padding: 6px 10px;
    background: #fff7e6;
    border: 1px solid #ffe0a3;
    border-radius: 6px;
    font-size: 11px;
    line-height: 1.5;
    color: #a86a00;
    overflow: hidden;
    transition: opacity 0.16s ease, max-height 0.24s cubic-bezier(0.2, 0.8, 0.2, 1),
      margin 0.24s cubic-bezier(0.2, 0.8, 0.2, 1),
      padding 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
    max-height: 80px;
  }
  .collapsed .demo-chip {
    opacity: 0;
    max-height: 0;
    margin-top: 0;
    padding-top: 0;
    padding-bottom: 0;
    border-width: 0;
  }

  .nav {
    flex: 1;
    padding: 4px 8px 12px;
    overflow-y: auto;
    overflow-x: hidden;
  }
  .nav-group-title {
    display: flex;
    padding: 12px 12px 6px;
    font-size: 11px;
    letter-spacing: 0.5px;
    color: #9ca3af;
    white-space: nowrap;
    overflow: hidden;
    transition: opacity 0.16s ease, max-height 0.24s cubic-bezier(0.2, 0.8, 0.2, 1),
      padding 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
    max-height: 40px;
  }
  .collapsed .nav-group-title {
    opacity: 0;
    max-height: 0;
    padding-top: 0;
    padding-bottom: 0;
  }

  .nav-item {
    position: relative;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    margin-bottom: 4px;
    border-radius: 8px;
    color: #4b5563;
    font-size: 14px;
    cursor: pointer;
    white-space: nowrap;
    transition: background 0.16s ease, color 0.16s ease, padding 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  /* 激活指示条：从中间往两头长出来（scaleY 而不是 height，省重排） */
  .nav-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    width: 3px;
    height: 16px;
    margin-top: -8px;
    border-radius: 0 3px 3px 0;
    background: #2f6bff;
    transform: scaleY(0);
    transition: transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .nav-item.active::before {
    transform: scaleY(1);
  }
  .nav-item:hover {
    background: #f5f7fa;
    color: #1f2937;
  }
  .nav-item.active {
    background: #eef3fe;
    color: #2f6bff;
    font-weight: 500;
  }
  .nav-item.subtle {
    color: #6b7280;
    font-size: 13px;
  }
  .nav-ico {
    width: 18px;
    text-align: center;
    font-size: 13px;
    flex-shrink: 0;
  }
  .nav-label {
    display: inline-block;
    overflow: hidden;
    white-space: nowrap;
    max-width: 180px;
    transition: max-width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.16s ease,
      transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .collapsed .nav-item {
    padding-left: 0;
    padding-right: 0;
    gap: 0;
    justify-content: center;
  }
  .collapsed .nav-label {
    max-width: 0;
    opacity: 0;
    transform: translateX(-4px);
  }
  .nav-badge {
    margin-left: auto;
    font-size: 10.5px;
    padding: 1px 6px;
    border-radius: 10px;
    background: #eef3fe;
    color: #2f6bff;
    transition: opacity 0.16s ease;
  }
  .collapsed .nav-badge {
    opacity: 0;
    width: 0;
    padding: 0;
    margin: 0;
    overflow: hidden;
  }

  /* 折叠态的浮动标签：绝对定位，不推别人 */
  .nav-tip {
    position: absolute;
    left: 52px;
    top: 50%;
    z-index: 20;
    padding: 4px 9px;
    border-radius: 6px;
    background: #1f2937;
    color: #fff;
    font-size: 12px;
    line-height: 1.4;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transform: translateY(-50%) translateX(-4px);
    transition: opacity 0.16s ease, transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
    box-shadow: 0 4px 12px rgba(20, 25, 35, 0.16);
  }
  .collapsed .nav-item:hover .nav-tip {
    opacity: 1;
    transform: translateY(-50%) translateX(0);
  }

  .teacher-toggle {
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    margin-top: 6px;
    border-top: 1px dashed #eef0f3;
    padding-top: 14px;
  }
  .teacher-note {
    font-size: 10.5px;
    color: #b9bdc4;
    letter-spacing: 0;
  }
  .collapsed .teacher-note {
    display: none;
  }
  .teacher-block {
    padding-bottom: 6px;
    overflow: hidden;
  }
  .collapsed .teacher-toggle,
  .collapsed .teacher-block {
    display: none;
  }
  .teacher-hint {
    padding: 0 12px 8px;
    font-size: 11px;
    line-height: 1.6;
    color: #9ca3af;
  }

  .current-user {
    height: 68px;
    flex-shrink: 0;
    border-top: 1px solid #f0f1f3;
    display: flex;
    align-items: center;
    padding: 0 16px;
    gap: 10px;
    overflow: hidden;
    transition: padding 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .collapsed .current-user {
    padding: 0 0;
    justify-content: center;
  }
  /* 状态小字：只有展开时才占高度；折叠时整行收掉，不留空档 */
  .sys-line {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 16px 10px;
    max-height: 30px;
    overflow: hidden;
    color: #2f9e6a;
    transition:
      max-height 0.24s cubic-bezier(0.2, 0.8, 0.2, 1),
      opacity 0.16s ease,
      padding 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .sys-text {
    font-size: 11px;
    color: #9ca3af;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .collapsed .sys-line {
    max-height: 0;
    opacity: 0;
    padding-bottom: 0;
  }
  .user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: #e0e7ff;
    color: #2f6bff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 14px;
    flex-shrink: 0;
  }
  .user-info {
    flex: 1;
    min-width: 0;
    max-width: 180px;
    opacity: 1;
    overflow: hidden;
    transition: max-width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.16s ease;
  }
  .collapsed .user-info {
    max-width: 0;
    opacity: 0;
  }
  .user-name {
    font-size: 14px;
    font-weight: 500;
    color: #1f2937;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .user-role {
    font-size: 11px;
    color: #9ca3af;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  @media (max-width: 1100px) {
    .app-sidebar {
      width: 100%;
      flex-direction: row;
      align-items: center;
      height: 64px;
    }
    .app-sidebar.collapsed {
      width: 100%;
    }
    .collapse-btn {
      display: none;
    }
    .brand {
      border-bottom: none;
      height: 64px;
      width: 200px;
    }
    .demo-chip,
    .nav-group-title,
    .teacher-block,
    .nav-tip {
      display: none;
    }
    .nav {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 0 8px;
      overflow-x: auto;
    }
    .nav-item {
      margin-bottom: 0;
      white-space: nowrap;
      padding: 8px 10px;
      font-size: 13px;
    }
    .nav-item::before {
      display: none;
    }
    .nav-label {
      max-width: 180px !important;
      opacity: 1 !important;
      transform: none !important;
    }
    .current-user {
      border-top: none;
      height: 64px;
      width: 168px;
      padding: 0 16px;
      justify-content: flex-start;
    }
    .user-info {
      max-width: 180px !important;
      opacity: 1 !important;
    }
  }
</style>
