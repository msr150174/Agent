<template>
  <Teleport to="body">
    <div v-if="open" class="palette-mask" @mousedown.self="close">
      <div class="palette" role="dialog" aria-label="命令面板">
        <div class="palette-input">
          <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true">
            <circle cx="7" cy="7" r="4.4" fill="none" stroke="currentColor" stroke-width="1.5" />
            <path d="M10.4 10.4L14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
          </svg>
          <input
            ref="inputEl"
            v-model="q"
            placeholder="去哪个页面，或者做什么…"
            spellcheck="false"
            @keydown.down.prevent="move(1)"
            @keydown.up.prevent="move(-1)"
            @keydown.enter.prevent="run()"
            @keydown.esc.prevent="close" />
          <span class="kbd">Esc</span>
        </div>

        <div class="palette-body" ref="bodyEl">
          <div v-if="list.length === 0" class="palette-empty">
            没有匹配项 —— 换个词试试，或者直接问左边的对话。
          </div>
          <template v-for="group in grouped" :key="group.name">
            <div class="palette-group">{{ group.name }}</div>
            <button
              v-for="item in group.items"
              :key="item.id"
              class="palette-item"
              :class="{ on: item.id === activeId }"
              @mouseenter="activeId = item.id"
              @click="run(item)">
              <span class="pi-icon">{{ item.icon }}</span>
              <span class="pi-text">
                <span class="pi-title">{{ item.title }}</span>
                <span v-if="item.desc" class="pi-desc">{{ item.desc }}</span>
              </span>
              <span v-if="item.kbd" class="pi-kbd"><span class="kbd">{{ item.kbd }}</span></span>
              <span v-else class="pi-enter">↵</span>
            </button>
          </template>
        </div>

        <div class="palette-foot">
          <span><span class="kbd">↑</span><span class="kbd">↓</span> 选择</span>
          <span><span class="kbd">↵</span> 执行</span>
          <span class="pf-note">共 {{ items.length }} 项 · 输入即筛</span>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed, watch, nextTick, onMounted, onBeforeUnmount } from 'vue';

  const props = defineProps({
    items: { type: Array, default: () => [] },
    modelValue: { type: Boolean, default: false }
  });
  const emit = defineEmits(['update:modelValue', 'select']);

  const open = computed({
    get: () => props.modelValue,
    set: (v) => emit('update:modelValue', v)
  });

  const q = ref('');
  const activeId = ref('');
  const inputEl = ref(null);
  const bodyEl = ref(null);

  /** 子序列模糊匹配 + 连续命中加权：输入 "kl" 能命中「看清单/看清路」 */
  const score = (query, text) => {
    if (!query) return 1;
    const q0 = query.toLowerCase();
    const t0 = text.toLowerCase();
    let i = 0;
    let s = 0;
    let streak = 0;
    for (let k = 0; k < t0.length && i < q0.length; k++) {
      if (t0[k] === q0[i]) {
        i++;
        streak++;
        s += 1 + streak * 2;
      } else {
        streak = 0;
      }
    }
    return i === q0.length ? s : 0;
  };

  const list = computed(() => {
    const query = q.value.trim();
    return props.items
      .map((it) => ({ ...it, _s: score(query, it.title + ' ' + (it.keywords || '') + ' ' + (it.desc || '')) }))
      .filter((it) => it._s > 0)
      .sort((a, b) => b._s - a._s);
  });

  const grouped = computed(() => {
    const map = new Map();
    for (const it of list.value) {
      const g = it.group || '动作';
      if (!map.has(g)) map.set(g, []);
      map.get(g).push(it);
    }
    return Array.from(map, ([name, items]) => ({ name, items }));
  });

  const flat = computed(() => grouped.value.flatMap((g) => g.items));

  watch(
    () => [q.value, open.value],
    () => {
      const first = flat.value[0];
      activeId.value = first ? first.id : '';
    }
  );

  watch(open, async (v) => {
    if (v) {
      q.value = '';
      await nextTick();
      inputEl.value && inputEl.value.focus();
    }
  });

  const move = (dir) => {
    const arr = flat.value;
    if (!arr.length) return;
    const i = arr.findIndex((x) => x.id === activeId.value);
    const n = (i + dir + arr.length) % arr.length;
    activeId.value = arr[n].id;
    nextTick(() => {
      const el = bodyEl.value && bodyEl.value.querySelector('.palette-item.on');
      el && el.scrollIntoView({ block: 'nearest' });
    });
  };

  const run = (item) => {
    const target = item || flat.value.find((x) => x.id === activeId.value);
    if (!target) return;
    emit('select', target);
    close();
  };

  const close = () => {
    open.value = false;
  };

  onMounted(() => {
    // 全局快捷键挂在 window，页面切走后仍然有效
    const onKey = (e) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        open.value = !open.value;
      }
    };
    window.addEventListener('keydown', onKey);
    onBeforeUnmount(() => window.removeEventListener('keydown', onKey));
  });
</script>

<style lang="css" scoped>
  .palette-mask {
    position: fixed;
    inset: 0;
    z-index: 3000;
    background: rgba(17, 24, 39, 0.28);
    backdrop-filter: blur(2px);
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding-top: 12vh;
    animation: fadeMask 0.18s var(--m-ease) both;
  }
  @keyframes fadeMask {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  .palette {
    width: 560px;
    max-width: calc(100vw - 40px);
    background: #fff;
    border-radius: 14px;
    box-shadow: var(--m-shadow-3);
    overflow: hidden;
    animation: popIn 0.2s var(--m-ease) both;
  }
  .palette-input {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 12px 14px;
    border-bottom: 1px solid var(--m-line);
    color: var(--m-ink-3);
  }
  .palette-input input {
    flex: 1;
    min-width: 0;
    border: none;
    outline: none;
    background: transparent;
    font-size: 14px;
    color: var(--m-ink);
    font-family: inherit;
  }
  .palette-input input::placeholder {
    color: #b9c0cc;
  }
  .palette-body {
    max-height: 52vh;
    overflow-y: auto;
    padding: 6px 8px 8px;
  }
  .palette-group {
    padding: 8px 8px 4px;
    font-size: 10.5px;
    font-weight: 600;
    color: var(--m-ink-3);
    letter-spacing: 0.04em;
  }
  .palette-item {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    padding: 8px 9px;
    border: none;
    border-radius: 8px;
    background: transparent;
    text-align: left;
    cursor: pointer;
    font-family: inherit;
    transition: background var(--m-fast) var(--m-ease);
  }
  .palette-item.on {
    background: #f2f6ff;
  }
  .pi-icon {
    flex-shrink: 0;
    width: 20px;
    text-align: center;
    font-size: 13px;
    color: var(--m-accent);
  }
  .pi-text {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: baseline;
    gap: 8px;
  }
  .pi-title {
    font-size: 13px;
    color: var(--m-ink);
    white-space: nowrap;
  }
  .pi-desc {
    font-size: 11.5px;
    color: var(--m-ink-3);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .pi-enter {
    flex-shrink: 0;
    font-size: 11px;
    color: #c8cedb;
    opacity: 0;
    transition: opacity var(--m-fast) var(--m-ease);
  }
  .palette-item.on .pi-enter {
    opacity: 1;
  }
  .palette-empty {
    padding: 26px 12px;
    text-align: center;
    font-size: 12.5px;
    color: var(--m-ink-3);
  }
  .palette-foot {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 8px 14px;
    border-top: 1px solid var(--m-line);
    background: #fbfcfe;
    font-size: 11px;
    color: var(--m-ink-3);
  }
  .palette-foot span {
    display: inline-flex;
    align-items: center;
    gap: 3px;
  }
  .pf-note {
    margin-left: auto;
  }
</style>
