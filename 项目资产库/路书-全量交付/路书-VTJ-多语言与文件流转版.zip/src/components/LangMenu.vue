<template>
  <div ref="rootRef" class="lang-switch">
    <button :class="['lang-btn', { open: open }]" :title="t('lang.title')" @click="toggle">
      <span class="lang-globe" aria-hidden="true">文</span>
      <span class="lang-now">{{ lang === 'zh' ? '中' : 'EN' }}</span>
      <span :class="['lang-chev', { open: open }]">›</span>
    </button>

    <Transition name="langpop">
      <div v-if="open" class="lang-pop" role="listbox">
        <div class="lp-head">{{ t('lang.title') }}</div>
        <button
          v-for="(opt, i) in OPTIONS"
          :key="opt.id"
          :class="['lp-row', { on: lang === opt.id, focus: focusIdx === i }]"
          role="option"
          :aria-selected="lang === opt.id"
          @mouseenter="focusIdx = i"
          @click="apply(opt.id)">
          <span class="lp-mark">{{ lang === opt.id ? '✓' : '' }}</span>
          <span class="lp-main">
            <span class="lp-label">{{ t(opt.label) }}</span>
            <span class="lp-desc">{{ t(opt.desc) }}</span>
          </span>
        </button>
        <div class="lp-note">{{ t('lang.note') }}</div>
        <div class="lp-hint">{{ t('lang.hint') }}</div>
      </div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue';
  import { useI18n, setLang, type Lang } from '@/i18n';
  import { notify } from '@/store/ui';

  const { lang, t } = useI18n();
  const open = ref(false);
  const focusIdx = ref(0);
  const rootRef = ref(null);

  const OPTIONS: { id: Lang; label: any; desc: any }[] = [
    { id: 'zh', label: 'lang.zh', desc: 'lang.zhDesc' },
    { id: 'en', label: 'lang.en', desc: 'lang.enDesc' }
  ];

  const toggle = () => {
    open.value = !open.value;
    if (open.value) {
      focusIdx.value = lang.value === 'zh' ? 0 : 1;
      nextTick(() => window.addEventListener('keydown', onKey));
    } else {
      window.removeEventListener('keydown', onKey);
    }
  };

  const close = () => {
    open.value = false;
    window.removeEventListener('keydown', onKey);
  };

  const apply = (id: Lang) => {
    if (id === lang.value) {
      close();
      return;
    }
    setLang(id);
    notify(t('lang.applied') + (id === 'zh' ? '：中文' : '：English'));
    close();
  };

  const onKey = (e) => {
    if (!open.value) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      focusIdx.value = (focusIdx.value + (e.key === 'ArrowDown' ? 1 : -1) + 2) % 2;
    } else if (e.key === 'Enter') {
      e.preventDefault();
      apply(OPTIONS[focusIdx.value].id);
    }
  };

  const onDocClick = (e) => {
    if (!open.value) return;
    if (rootRef.value && !rootRef.value.contains(e.target)) close();
  };

  onMounted(() => document.addEventListener('mousedown', onDocClick));
  onBeforeUnmount(() => {
    document.removeEventListener('mousedown', onDocClick);
    window.removeEventListener('keydown', onKey);
  });
</script>

<style lang="css" scoped>
  .lang-switch {
    position: relative;
    flex-shrink: 0;
  }
  .lang-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    height: 26px;
    padding: 0 8px 0 6px;
    border: 1px solid #e6e9ee;
    border-radius: 7px;
    background: #fff;
    color: #4a5566;
    font-size: 12px;
    cursor: pointer;
    transition:
      border-color 0.16s var(--m-ease),
      background 0.16s var(--m-ease),
      color 0.16s var(--m-ease);
  }
  .lang-btn:hover,
  .lang-btn.open {
    border-color: #b9cdfd;
    background: #f4f7ff;
    color: #2f6bff;
  }
  .lang-globe {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    border-radius: 4px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 10px;
    font-weight: 600;
  }
  .lang-now {
    font-variant-numeric: tabular-nums;
    letter-spacing: 0.02em;
  }
  .lang-chev {
    display: inline-block;
    transform: rotate(90deg);
    transition: transform 0.16s var(--m-ease);
    opacity: 0.5;
    font-size: 11px;
  }
  .lang-chev.open {
    transform: rotate(-90deg);
  }
  .lang-pop {
    position: absolute;
    top: 32px;
    right: 0;
    z-index: 900;
    width: 262px;
    padding: 8px;
    border: 1px solid #e8ebf0;
    border-radius: 11px;
    background: #fff;
    box-shadow: var(--m-shadow-3, 0 12px 32px rgba(20, 30, 50, 0.14));
    transform-origin: top right;
  }
  .lp-head {
    padding: 2px 8px 7px;
    font-size: 11px;
    letter-spacing: 0.08em;
    color: #8a94a6;
    text-transform: uppercase;
  }
  .lp-row {
    display: flex;
    align-items: flex-start;
    gap: 7px;
    width: 100%;
    padding: 7px 8px;
    border: none;
    border-radius: 7px;
    background: transparent;
    text-align: left;
    cursor: pointer;
    transition: background 0.14s var(--m-ease);
  }
  .lp-row.focus {
    background: #f5f8ff;
  }
  .lp-row.on .lp-label {
    color: #2f6bff;
    font-weight: 600;
  }
  .lp-mark {
    width: 12px;
    flex-shrink: 0;
    color: #2f6bff;
    font-size: 11px;
    line-height: 18px;
  }
  .lp-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .lp-label {
    font-size: 12.5px;
    color: #1f2733;
    line-height: 1.35;
  }
  .lp-desc {
    font-size: 11px;
    color: #98a1b0;
    line-height: 1.35;
  }
  .lp-note {
    margin: 6px 4px 0;
    padding: 6px 8px;
    border-radius: 6px;
    background: #fafbfc;
    font-size: 11px;
    line-height: 1.5;
    color: #8d96a5;
  }
  .lp-hint {
    margin-top: 6px;
    padding: 0 8px 2px;
    font-size: 10.5px;
    color: #b0b8c4;
  }
  .langpop-enter-active {
    animation: langIn 0.18s var(--m-ease) both;
  }
  .langpop-leave-active {
    transition:
      opacity 0.13s linear,
      transform 0.13s var(--m-ease);
  }
  .langpop-leave-to {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  @keyframes langIn {
    from {
      opacity: 0;
      transform: translateY(-5px) scale(0.98);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
</style>
