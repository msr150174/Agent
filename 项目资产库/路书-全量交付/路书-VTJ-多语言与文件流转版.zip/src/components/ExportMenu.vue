<template>
  <div ref="rootRef" class="export-wrap">
    <button :class="['export-btn', { open }]" @click="toggle">
      <span class="eb-ico">⇩</span>
      <span>{{ t('c.export') }}</span>
    </button>
    <Transition name="epop">
      <div v-if="open" class="export-pop">
        <div class="ep-head">{{ t('e.title') }}</div>
        <button
          v-for="(o, i) in OPTIONS"
          :key="o.type"
          :class="['ep-row', { focus: focusIdx === i }]"
          @mouseenter="focusIdx = i"
          @click="pick(o.type)">
          <span class="ep-ico" :class="o.tone">{{ o.icon }}</span>
          <span class="ep-main">
            <span class="ep-label">{{ t(o.label) }}</span>
            <span class="ep-desc">{{ t(o.desc) }}</span>
          </span>
        </button>
        <div class="ep-foot">{{ t('e.free') }}</div>
      </div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue';
  import { useI18n } from '@/i18n';

  const emit = defineEmits(['export']);
  const { t } = useI18n();

  const open = ref(false);
  const focusIdx = ref(0);
  const rootRef = ref(null);

  const OPTIONS = [
    {
      type: 'csv',
      icon: '▦',
      tone: 'green',
      label: 'e.csv' as const,
      desc: 'e.csvDesc' as const
    },
    {
      type: 'md',
      icon: '≡',
      tone: 'violet',
      label: 'e.md' as const,
      desc: 'e.mdDesc' as const
    },
    {
      type: 'tsv',
      icon: '⧉',
      tone: 'blue',
      label: 'e.tsv' as const,
      desc: 'e.tsvDesc' as const
    }
  ];

  const toggle = () => {
    open.value = !open.value;
    if (open.value) {
      focusIdx.value = 0;
      nextTick(() => window.addEventListener('keydown', onKey));
    } else {
      window.removeEventListener('keydown', onKey);
    }
  };
  const close = () => {
    open.value = false;
    window.removeEventListener('keydown', onKey);
  };
  const pick = (type) => {
    emit('export', type);
    close();
  };

  const onKey = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      focusIdx.value = (focusIdx.value + (e.key === 'ArrowDown' ? 1 : -1) + 3) % 3;
    } else if (e.key === 'Enter') {
      e.preventDefault();
      pick(OPTIONS[focusIdx.value].type);
    }
  };
  const onDoc = (e) => {
    if (open.value && rootRef.value && !rootRef.value.contains(e.target)) close();
  };

  onMounted(() => document.addEventListener('mousedown', onDoc));
  onBeforeUnmount(() => {
    document.removeEventListener('mousedown', onDoc);
    window.removeEventListener('keydown', onKey);
  });
</script>

<style lang="css" scoped>
  .export-wrap {
    position: relative;
  }
  .export-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    height: 28px;
    padding: 0 10px;
    border: 1px solid #e4e9f0;
    border-radius: 7px;
    background: #fff;
    color: #4a5566;
    font-size: 12px;
    cursor: pointer;
    transition:
      color 0.16s var(--m-ease),
      border-color 0.16s var(--m-ease),
      background 0.16s var(--m-ease);
  }
  .export-btn:hover,
  .export-btn.open {
    color: #2f6bff;
    border-color: #c3d3fb;
    background: #f6f9ff;
  }
  .eb-ico {
    font-size: 12px;
    line-height: 1;
  }
  .export-pop {
    position: absolute;
    top: 34px;
    right: 0;
    z-index: 880;
    width: 236px;
    padding: 7px;
    border: 1px solid #e8ebf0;
    border-radius: 10px;
    background: #fff;
    box-shadow: var(--m-shadow-3, 0 12px 32px rgba(20, 30, 50, 0.14));
    transform-origin: top right;
  }
  .ep-head {
    padding: 2px 8px 6px;
    font-size: 10.5px;
    letter-spacing: 0.07em;
    color: #98a1b0;
    text-transform: uppercase;
  }
  .ep-row {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    width: 100%;
    padding: 6px 8px;
    border: none;
    border-radius: 7px;
    background: transparent;
    text-align: left;
    cursor: pointer;
  }
  .ep-row.focus {
    background: #f5f8ff;
  }
  .ep-ico {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    border-radius: 5px;
    font-size: 10px;
    background: #eef3ff;
    color: #2f6bff;
  }
  .ep-ico.green {
    background: #eaf7ef;
    color: #2c8a4b;
  }
  .ep-ico.violet {
    background: #f1f0ff;
    color: #5b53c8;
  }
  .ep-main {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .ep-label {
    font-size: 12px;
    color: #1f2733;
    line-height: 1.3;
  }
  .ep-desc {
    font-size: 10.5px;
    color: #9aa3b2;
    line-height: 1.35;
  }
  .ep-foot {
    margin-top: 5px;
    padding: 5px 8px 2px;
    border-top: 1px solid #f2f4f8;
    font-size: 10px;
    color: #b6bec9;
  }
  .epop-enter-active {
    animation: epIn 0.17s var(--m-ease) both;
  }
  .epop-leave-active {
    transition:
      opacity 0.13s linear,
      transform 0.13s var(--m-ease);
  }
  .epop-leave-to {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  @keyframes epIn {
    from {
      opacity: 0;
      transform: translateY(-5px) scale(0.98);
    }
  }
</style>
