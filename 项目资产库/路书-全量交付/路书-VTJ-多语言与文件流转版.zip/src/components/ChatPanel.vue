<template>
  <div class="chat-panel">
    <div class="chat-header">
      <div class="header-left">
        <span class="header-title">{{ t('nav.chat') }}</span>
        <span class="header-subtitle">{{ t('chat.sub') }}</span>
      </div>
      <div class="header-actions">
        <span v-if="streaming" class="header-status">{{ t('chat.generating') }}</span>
        <button
          :class="['view-btn', { off: !showSessions }]"
          title="显示 / 隐藏「我的提问」列"
          @click="emit('toggle-sessions')">
          ◧
        </button>
        <button
          :class="['view-btn', { off: !showRefs }]"
          title="显示 / 隐藏「来源」栏"
          @click="emit('toggle-refs')">
          ◨
        </button>
      </div>
    </div>

    <!-- 检索链：四段推进，当前段一条静态光晕只做透明度呼吸 -->
    <div v-if="streaming" class="chain">
      <div
        v-for="(step, i) in chainSteps"
        :key="step"
        :class="['chain-step', { done: i < toolStep, active: i === toolStep }]">
        <span class="chain-dot">{{ i < toolStep ? '✓' : i + 1 }}</span>
        <span class="chain-text">{{ step }}</span>
      </div>
    </div>

    <div ref="messageListRef" class="message-list">
      <!-- 开场：三问 + 快捷问题 -->
      <div v-if="msgs.length === 0" class="opener">
        <h2 class="opener-title">{{ t('chat.openerTitle') }}</h2>
        <p class="opener-lede">{{ t('chat.openerLede1') }}</p>
        <p class="opener-lede">{{ t('chat.openerLede2') }}</p>
        <div class="opener-form">
          <ElSelect v-model="major" class="opener-select" placeholder="你的专业">
            <ElOption label="计算机应用技术" value="计算机应用技术"></ElOption>
            <ElOption label="电子商务" value="电子商务"></ElOption>
            <ElOption label="其他专业" value="其他专业"></ElOption>
          </ElSelect>
          <ElSelect v-model="grade" class="opener-select" placeholder="你的年级">
            <ElOption label="大一" value="大一"></ElOption>
            <ElOption label="大二" value="大二"></ElOption>
            <ElOption label="大三" value="大三"></ElOption>
          </ElSelect>
          <ElSelect v-model="aim" class="opener-select" placeholder="现在最想解决">
            <ElOption label="不知道往哪走" value="不知道往哪走"></ElOption>
            <ElOption label="想确认能去哪些岗位" value="想确认能去哪些岗位"></ElOption>
            <ElOption label="想准备专插本" value="想准备专插本"></ElOption>
            <ElOption label="想找实习、改简历" value="想找实习、改简历"></ElOption>
          </ElSelect>
          <ElButton type="primary" @click="handleStart">{{ t('chat.start') }}</ElButton>
        </div>
        <div class="chips">
          <button
            v-for="(q, qi) in quickQuestions"
            :key="q"
            class="chip"
            :style="{ animationDelay: qi * 50 + 'ms' }"
            @click="handleQuick(q)">
            {{ q }}
          </button>
        </div>
      </div>

      <!-- 消息 -->
      <div
        v-for="(msg, mi) in msgs"
        :key="msg.id"
        :class="['message-item', msg.role]"
        :style="{ '--i': Math.min(mi, 6) }">
        <div class="avatar">{{ msg.role === 'user' ? '我' : '路' }}</div>
        <div :class="['bubble', { miss: !!msg.miss }]">
          <!-- 推理轨迹：回答之前先摊开「查了哪几组」—— 可折叠，默认收起 -->
          <div v-if="msg.hitGroups && msg.hitGroups.length" class="trace">
            <button class="trace-head" @click="toggleTrace(msg.id)">
              <span class="trace-ico">⌗</span>
              <span class="trace-label">{{ t('chat.traceAll', { n: msg.hitGroups.length }) }}</span>
              <span class="trace-toggle">{{ traceOpen[msg.id] ? t('c.less') : t('c.more') }}</span>
              <span :class="['trace-chev', { open: traceOpen[msg.id] }]">›</span>
            </button>
            <div v-if="traceOpen[msg.id]" class="trace-body">
              <div v-for="(g, gi) in msg.hitGroups" :key="gi" class="trace-row">
                <span class="idx">{{ String(gi + 1).padStart(2, '0') }}</span>
                <span class="trace-group">{{ g }}</span>
                <span class="trace-hit">命中</span>
              </div>
              <div class="trace-foot">{{ t('chat.traceFoot') }}</div>
            </div>
          </div>

          <!-- 英文界面下的摘要：明确标注「以中文原文为准」，不冒充原文 -->
          <div v-if="isEn && msg.enSummary" class="en-sum">
            <div class="en-tag">{{ t('chat.enNote') }}</div>
            <div class="en-body">{{ msg.enSummary }}</div>
          </div>

          <div :class="['bubble-content', { caret: msg.typing }]">{{ msg.content }}</div>

          <!-- 这条问题带进来的附件：只作上下文，不算出处 -->
          <div v-if="msg.attachments && msg.attachments.length" class="msg-files">
            <span v-for="(f, fi) in msg.attachments" :key="fi" class="mf-item">
              <span class="mf-ico">{{ String(f.ext || '').toUpperCase().slice(0, 3) }}</span>
              <span class="mf-name">{{ f.name }}</span>
              <span class="mf-chunks">{{ t('u.done', { n: f.chunks }) }}</span>
            </span>
          </div>

          <div v-if="msg.sources && msg.sources.length" class="sources">
            <div class="ref-title">📚 {{ t('chat.sources') }}</div>
            <div
              v-for="(src, i) in msg.sources"
              :key="i"
              class="ref-item"
              :style="{ animationDelay: i * 60 + 'ms' }">
              <span>{{ src.title }}</span>
              <span class="ref-meta">{{ src.group }} · {{ src.date }}</span>
            </div>
          </div>
          <div v-if="msg.footer" class="policy-footer">{{ msg.footer }}</div>

          <!-- 这次回答产出的文件：能预览、能下载，不是装饰 -->
          <ArtifactList v-if="msg.artifacts && msg.artifacts.length" :items="msg.artifacts"></ArtifactList>

          <!-- 悬停才出现的工具条：复制 / 朗读 / 就着这条追问 -->
          <div v-if="!msg.typing" class="msg-tools">
            <button class="mt-btn" :class="{ ok: copiedId === msg.id }" @click="copyMsg(msg)">
              <span v-if="copiedId === msg.id">✓ {{ t('c.copied') }}</span>
              <span v-else>⧉ {{ t('c.copy') }}</span>
            </button>
            <button
              v-if="msg.role === 'assistant' && !msg.miss"
              :class="['mt-btn', { reading: speakingId === msg.id }]"
              @click="toggleRead(msg)">
              <span v-if="speakingId === msg.id">◼ {{ t('v.reading') }}</span>
              <span v-else>▷ {{ t('v.read') }}</span>
            </button>
            <button
              v-if="msg.role === 'assistant'"
              class="mt-btn"
              @click="quoteMsg(msg)">↩ {{ t('chat.followUp') }}</button>
          </div>
        </div>
      </div>
    </div>

    <div class="input-area">
      <!-- 附件区：拖拽 / 粘贴 / 选择三条路都通到同一个列表 -->
      <AttachTray
        :files="attachments"
        @add="addFiles"
        @remove="removeFile"
        @clear="clearFiles"></AttachTray>

      <Transition name="vline">
        <div v-if="voiceHint" class="voice-line">
          <i class="vl-dot"></i>
          <span class="vl-text">{{ voiceHint }}</span>
        </div>
      </Transition>

      <div class="input-shell">
        <textarea
          v-model="inputText"
          class="input-textarea"
          rows="2"
          :placeholder="t('chat.ph')"
          @keydown.enter.exact.prevent="handleSend"></textarea>
        <div class="input-actions">
          <div class="ia-left">
            <VoiceButton @text="insertVoice" @hint="voiceHint = $event"></VoiceButton>
            <span class="input-tip">{{ t('chat.tip') }}</span>
          </div>
          <button v-if="!streaming" class="send-btn" @click="handleSend">{{ t('c.send') }}</button>
          <button v-else class="stop-btn" @click="handleStop">{{ t('c.stop') }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed, watch, nextTick, useAttrs, onBeforeUnmount } from 'vue';
  import { ElSelect, ElOption, ElButton } from 'element-plus';
  import { notify } from '@/store/ui';
  import { useI18n } from '@/i18n';
  import AttachTray from '@/components/AttachTray.vue';
  import VoiceButton from '@/components/VoiceButton.vue';
  import ArtifactList from '@/components/ArtifactList.vue';
  import { speak, hasSpeech } from '@/utils/speech';
  import { addMaterials } from '@/store/files';

  const { t, lang, isEn } = useI18n();

  const attrs = useAttrs();
  // useAttrs() 里保留的是原始 attr 名：父组件写 :tool-step，键就是 'tool-step'，不会自动转驼峰
  const pick = (name) => {
    const camel = name.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    return attrs[camel] !== undefined ? attrs[camel] : attrs[name];
  };
  const listener = (name) => {
    const key = 'on' + name.replace(/(^|-)([a-z])/g, (_, _d, c) => c.toUpperCase());
    return attrs[key];
  };

  const msgs = computed(() => pick('messages') || []);
  const streaming = computed(() => !!pick('streaming'));
  const toolStep = computed(() => (typeof pick('tool-step') === 'number' ? pick('tool-step') : -1));
  const showSessions = computed(() => pick('show-sessions') !== false);
  const showRefs = computed(() => pick('show-refs') !== false);
  const emit = (name, ...args) => {
    const handler = listener(name);
    if (typeof handler === 'function') handler(...args);
  };

  /* 推理轨迹展开状态：按消息 id 记，收起的是默认态 */
  const traceOpen = reactive({});
  const toggleTrace = (id) => {
    traceOpen[id] = !traceOpen[id];
  };

  /* 复制成功后按钮自己变 ✓，1.2s 后复原 —— 比弹一条 toast 更近 */
  const copiedId = ref('');
  const copyMsg = (msg) => {
    const text = msg.content + (msg.footer ? '\n\n' + msg.footer : '');
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text);
    } catch (e) {
      /* 剪贴板被拦不影响提示 */
    }
    copiedId.value = msg.id;
    notify('已复制这段回答');
    setTimeout(() => {
      if (copiedId.value === msg.id) copiedId.value = '';
    }, 1200);
  };

  /* 就着这条追问：把话题填回输入框，不直接发 —— 让人还有改的余地 */
  const quoteMsg = (msg) => {
    const head = String(msg.content || '').replace(/\s+/g, '').slice(0, 18);
    inputText.value = `关于「${head}…」，我还想问：`;
    nextTick(() => {
      const el = document.querySelector('.input-textarea');
      if (el) {
        el.focus();
        el.setSelectionRange(el.value.length, el.value.length);
      }
    });
  };

  // 与项目里那套链路同名，只是缩成四段给人看
  const chainSteps = ['理解问题', '检索 A–E', '挂载来源', '终审 V1.1'];

  const inputText = ref('');
  const messageListRef = ref(null);
  const major = ref('计算机应用技术');
  const grade = ref('大一');
  const aim = ref('');
  const quickQuestions = [
    '专插本报名要什么条件',
    '计算机应用技术能去哪些岗位',
    '大一该先准备什么',
    '简历没项目经历怎么写'
  ];

  const handleSend = () => {
    const text = inputText.value.trim();
    if (!text || streaming.value) return;
    // 只把解析完成的附件带进这条消息；失败/解析中的不带，免得回答引用半个文件
    const ready = attachments.value.filter((f) => f.status === 'done');
    emit(
      'send',
      text,
      ready.map((f) => ({ name: f.name, ext: f.ext, size: f.size, chunks: f.chunks }))
    );
    inputText.value = '';
    attachments.value = [];
  };
  const handleStop = () => {
    emit('stop');
  };

  /* ---------- 附件 ---------- */
  const attachments = ref([]);
  const addFiles = (list) => {
    attachments.value = attachments.value.concat(list);
    addMaterials(list);
    if (attachments.value.length > 8) {
      notify('一次最多带 8 个附件，多出来的先留在「材料与产出」里');
      attachments.value = attachments.value.slice(0, 8);
    }
  };
  const removeFile = (id) => {
    attachments.value = attachments.value.filter((f) => f.id !== id);
  };
  const clearFiles = () => {
    attachments.value = [];
  };

  /* ---------- 语音 ---------- */
  const voiceHint = ref('');
  const insertVoice = (text) => {
    const piece = String(text || '').trim();
    if (!piece) return;
    inputText.value = inputText.value ? inputText.value + ' ' + piece : piece;
    nextTick(() => {
      const el = document.querySelector('.input-textarea');
      if (el) {
        el.focus();
        el.setSelectionRange(el.value.length, el.value.length);
      }
    });
  };

  const speakingId = ref('');
  let speechHandle = null;
  const stopRead = () => {
    if (speechHandle) speechHandle.stop();
    speechHandle = null;
    speakingId.value = '';
  };
  const toggleRead = (msg) => {
    if (speakingId.value === msg.id) {
      stopRead();
      return;
    }
    if (!hasSpeech()) {
      notify(t('v.readUnsupported'));
      return;
    }
    stopRead();
    speechHandle = speak(msg.content, {
      lang: lang.value === 'zh' ? 'zh-CN' : 'en-US',
      onDone: () => {
        speakingId.value = '';
        speechHandle = null;
      }
    });
    if (!speechHandle) {
      notify(t('v.readUnsupported'));
      return;
    }
    speakingId.value = msg.id;
  };
  onBeforeUnmount(stopRead);
  const handleQuick = (text) => {
    if (streaming.value) return;
    emit('send', text);
  };
  const handleStart = () => {
    const m = major.value || '我的专业';
    const g = grade.value || '现在';
    const a = aim.value || '不知道往哪走';
    emit('send', `我是${m}的${g}学生，现在最想解决的问题是：${a}`);
  };

  watch(
    () => msgs.value.length,
    async () => {
      await nextTick();
      const el = messageListRef.value;
      if (el) el.scrollTop = el.scrollHeight;
    }
  );
</script>

<style lang="css" scoped>
  /* 这条曲线和全局那条是同一个：起步快、收尾软 */
  @keyframes msgIn {
    from {
      opacity: 0;
      transform: translateY(8px) scale(0.995);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes srcIn {
    from {
      opacity: 0;
      transform: translateX(-6px);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes chipIn {
    from {
      opacity: 0;
      transform: translateY(4px);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  /* 「正在工作」呼吸：光晕是静态的，只有透明度在动（动 box-shadow 会吃满 GPU） */
  @keyframes chainBreath {
    0%,
    100% {
      opacity: 0.45;
    }
    50% {
      opacity: 1;
    }
  }

  .chat-panel {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    overflow: hidden;
    box-sizing: border-box;
  }
  .chat-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px;
    border-bottom: 1px solid #f0f1f3;
    flex-shrink: 0;
  }
  .header-title {
    font-size: 15px;
    font-weight: 600;
    color: #1f2937;
    margin-right: 10px;
  }
  .header-subtitle {
    font-size: 11.5px;
    color: #9ca3af;
  }
  .header-actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .header-status {
    font-size: 11.5px;
    color: #2f6bff;
  }
  .view-btn {
    width: 26px;
    height: 24px;
    padding: 0;
    border: 1px solid #eef0f3;
    border-radius: 6px;
    background: #fff;
    color: #6b7280;
    font-size: 12px;
    line-height: 1;
    cursor: pointer;
    transition: color 0.16s ease, border-color 0.16s ease, background 0.16s ease;
  }
  .view-btn:hover {
    color: #2f6bff;
    border-color: #c9d8ff;
    background: #f7f9ff;
  }
  .view-btn.off {
    color: #c3c8d0;
    background: #f7f8fa;
    border-color: #f0f1f3;
  }
  .view-btn:active {
    transform: scale(0.94);
  }

  /* ── 检索链 ── */
  .chain {
    display: flex;
    gap: 6px;
    padding: 10px 18px 0;
    border-bottom: 1px solid #f5f6f8;
    background: #fbfcfe;
    flex-shrink: 0;
  }
  .chain-step {
    position: relative;
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding-bottom: 10px;
    font-size: 11.5px;
    color: #c3c8d0;
    transition: color 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .chain-step::after {
    content: '';
    position: absolute;
    left: 0;
    right: 10px;
    bottom: 0;
    height: 3px;
    border-radius: 3px;
    background: #eef0f3;
    transform-origin: left center;
    transition: background 0.24s ease;
  }
  .chain-dot {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    border-radius: 50%;
    border: 1px solid #e5e7eb;
    background: #fff;
    font-size: 9.5px;
    line-height: 14px;
    text-align: center;
    color: #b9bdc4;
    transition: all 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .chain-text {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .chain-step.done {
    color: #6b7280;
  }
  .chain-step.done::after {
    background: #c9d8ff;
  }
  .chain-step.done .chain-dot {
    border-color: #c9d8ff;
    background: #eef3fe;
    color: #2f6bff;
  }
  .chain-step.active {
    color: #2f6bff;
    font-weight: 600;
  }
  .chain-step.active .chain-dot {
    border-color: #2f6bff;
    background: #2f6bff;
    color: #fff;
  }
  .chain-step.active::after {
    background: #2f6bff;
    box-shadow: 0 0 12px rgba(47, 107, 255, 0.85), 0 0 4px rgba(47, 107, 255, 0.85);
    animation: chainBreath 1.2s ease-in-out infinite;
  }

  .message-list {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    padding: 18px;
  }
  .opener {
    padding: 4px 2px 0;
  }
  .opener-title {
    font-size: 19px;
    font-weight: 600;
    color: #1f2937;
    margin: 0 0 10px;
  }
  .opener-lede {
    font-size: 13px;
    line-height: 1.8;
    color: #4b5563;
    margin: 0 0 8px;
  }
  .opener-form {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin: 18px 0 12px;
  }
  .opener-select {
    width: 148px;
  }
  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .chip {
    padding: 6px 12px;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    background: #fff;
    color: #374151;
    font-size: 12.5px;
    cursor: pointer;
    animation: chipIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
    transition: border-color 0.16s ease, color 0.16s ease, background 0.16s ease,
      transform 0.16s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .chip:hover {
    border-color: #2f6bff;
    color: #2f6bff;
    background: #f4f7ff;
    transform: translateY(-1px);
  }
  .chip:active {
    transform: translateY(0) scale(0.98);
  }
  .message-item {
    display: flex;
    gap: 10px;
    margin-bottom: 18px;
    animation: msgIn 0.32s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .avatar {
    width: 30px;
    height: 30px;
    flex-shrink: 0;
    border-radius: 50%;
    background: #eef3fe;
    color: #2f6bff;
    font-size: 12px;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .bubble {
    flex: 1;
    min-width: 0;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    padding: 12px 14px;
    background: #fcfdff;
  }
  .bubble-content {
    font-size: 13px;
    line-height: 1.85;
    color: #374151;
    white-space: pre-wrap;
  }
  .bubble.miss {
    background: #fffdf7;
    border: 1px dashed #ffd591;
  }
  .bubble.miss .bubble-content {
    color: #8a4b00;
  }

  /* ── 推理轨迹 ───────────────────────────────────────────── */
  .trace {
    margin: -2px 0 10px;
    border: 1px solid #edf1f8;
    border-radius: 8px;
    background: #fbfcff;
    overflow: hidden;
  }
  .trace-head {
    display: flex;
    align-items: center;
    gap: 6px;
    width: 100%;
    padding: 6px 9px;
    border: none;
    background: transparent;
    cursor: pointer;
    font-family: inherit;
    text-align: left;
    color: #6b7280;
    transition: background var(--m-fast) var(--m-ease);
  }
  .trace-head:hover {
    background: #f4f7ff;
  }
  .trace-ico {
    color: #2f6bff;
    font-size: 11px;
  }
  .trace-label {
    flex: 1;
    font-size: 11.5px;
    font-variant-numeric: tabular-nums;
  }
  .trace-toggle {
    font-size: 11px;
    color: #2f6bff;
  }
  .trace-chev {
    font-size: 12px;
    color: #c3cbd8;
    transition: transform var(--m-fast) var(--m-ease);
  }
  .trace-chev.open {
    transform: rotate(90deg);
  }
  .trace-body {
    padding: 2px 9px 7px;
    border-top: 1px dashed #e8eefb;
  }
  .trace-row {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 3px 0;
    font-size: 11.5px;
    color: #4b5563;
    animation: refIn 0.24s var(--m-ease) both;
  }
  .trace-group {
    flex: 1;
    min-width: 0;
  }
  .trace-hit {
    padding: 0 5px;
    border-radius: 3px;
    background: #eaf6ee;
    color: #2f9e6a;
    font-size: 10px;
  }
  .trace-foot {
    margin-top: 4px;
    font-size: 10.5px;
    color: #a8b0bd;
    line-height: 1.6;
  }

  /* ── 悬停工具条 ──────────────────────────────────────────── */
  .msg-tools {
    display: flex;
    gap: 6px;
    margin-top: 8px;
    height: 0;
    overflow: hidden;
    opacity: 0;
    transition:
      opacity var(--m-fast) var(--m-ease),
      height var(--m-fast) var(--m-ease);
  }
  .message-item:hover .msg-tools {
    height: 22px;
    opacity: 1;
  }
  .mt-btn {
    padding: 1px 8px;
    border: 1px solid #e7ecf5;
    border-radius: 6px;
    background: #fff;
    color: #6b7280;
    font-size: 11px;
    font-family: inherit;
    cursor: pointer;
    transition:
      color var(--m-fast) var(--m-ease),
      border-color var(--m-fast) var(--m-ease),
      background var(--m-fast) var(--m-ease);
  }
  .mt-btn:hover {
    color: #2f6bff;
    border-color: #cfdcff;
    background: #f7f9ff;
  }
  .mt-btn.ok {
    color: #2f9e6a;
    border-color: #bfe6cd;
    background: #f2fbf5;
  }
  .mt-btn.reading {
    color: #2f6bff;
    border-color: #c3d3fb;
    background: #f2f6ff;
    animation: readPulse 1.4s ease-in-out infinite;
  }
  @keyframes readPulse {
    50% {
      box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.1);
    }
  }

  /* 用户气泡下挂的附件条 */
  .msg-files {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    margin-top: 8px;
  }
  .mf-item {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    max-width: 220px;
    padding: 3px 7px 3px 4px;
    border: 1px solid #e6ecf7;
    border-radius: 6px;
    background: #f8faff;
    font-size: 11px;
    color: #4a5566;
  }
  .mf-ico {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 16px;
    border-radius: 3px;
    background: #e8f0ff;
    color: #2f6bff;
    font-size: 8px;
    font-weight: 700;
  }
  .mf-name {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .mf-chunks {
    flex-shrink: 0;
    color: #a3acba;
    font-variant-numeric: tabular-nums;
  }

  /* 英文摘要 */
  .en-sum {
    margin-top: 10px;
    padding: 9px 11px;
    border: 1px solid #e8ecf5;
    border-left: 3px solid #8fa8e8;
    border-radius: 6px;
    background: #f8fafd;
  }
  .en-tag {
    margin-bottom: 4px;
    font-size: 10px;
    letter-spacing: 0.04em;
    color: #8d99ad;
  }
  .en-body {
    font-size: 12px;
    line-height: 1.72;
    color: #4b5768;
  }
  .sources {
    margin-top: 10px;
    padding-top: 8px;
    border-top: 1px dashed #e5e7eb;
  }
  .sources .ref-title {
    font-size: 11.5px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .sources .ref-item {
    font-size: 12px;
    color: #2f6bff;
    line-height: 1.75;
    animation: srcIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .sources .ref-meta {
    margin-left: 6px;
    color: #9ca3af;
    font-size: 11px;
  }
  .policy-footer {
    margin-top: 10px;
    padding: 8px 10px;
    background: #f7f8fa;
    border-left: 3px solid #d1d5db;
    border-radius: 4px;
    font-size: 11.5px;
    line-height: 1.7;
    color: #6b7280;
  }
  .input-area {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
    border-top: 1px solid #f0f1f3;
    padding: 12px 16px 14px;
  }
  .input-shell {
    display: flex;
    flex-direction: column;
  }
  .voice-line {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 5px 9px;
    border-radius: 7px;
    background: #f4f7fd;
    border: 1px solid #e3eaf8;
    font-size: 11.5px;
    color: #4b5768;
  }
  .vl-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #2f6bff;
    animation: vlPulse 1.1s ease-in-out infinite;
  }
  .vl-text {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  @keyframes vlPulse {
    50% {
      opacity: 0.3;
    }
  }
  .vline-enter-active {
    animation: vlIn 0.18s var(--m-ease) both;
  }
  .vline-leave-active {
    transition: opacity 0.14s linear;
  }
  .vline-leave-to {
    opacity: 0;
  }
  @keyframes vlIn {
    from {
      opacity: 0;
      transform: translateY(-3px);
    }
  }
  .ia-left {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }
  .input-textarea {
    width: 100%;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 13px;
    line-height: 1.7;
    color: #1f2937;
    resize: none;
    outline: none;
    box-sizing: border-box;
    font-family: inherit;
    transition: border-color 0.16s ease, box-shadow 0.16s ease;
  }
  .input-textarea:focus {
    border-color: #2f6bff;
    box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.1);
  }
  .input-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 8px;
  }
  .input-tip {
    flex: 1;
    font-size: 11px;
    color: #9ca3af;
  }
  .send-btn {
    padding: 6px 20px;
    border: none;
    border-radius: 7px;
    background: #2f6bff;
    color: #fff;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.16s ease, transform 0.16s cubic-bezier(0.2, 0.8, 0.2, 1),
      box-shadow 0.16s ease;
  }
  .send-btn:hover {
    background: #1e56d6;
    box-shadow: 0 4px 12px rgba(47, 107, 255, 0.28);
  }
  .send-btn:active {
    transform: scale(0.97);
  }
  .stop-btn {
    padding: 6px 20px;
    border: 1px solid #e5e7eb;
    border-radius: 7px;
    background: #fff;
    color: #6b7280;
    font-size: 13px;
    cursor: pointer;
    transition: transform 0.16s cubic-bezier(0.2, 0.8, 0.2, 1), border-color 0.16s ease;
  }
  .stop-btn:active {
    transform: scale(0.97);
  }
</style>
