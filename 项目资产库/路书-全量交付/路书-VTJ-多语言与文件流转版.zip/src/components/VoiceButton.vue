<template>
  <div class="voice-wrap">
    <button
      :class="['voice-btn', state]"
      :title="state === 'idle' ? t('v.start') : t('v.readStop')"
      @click="toggle">
      <!-- 录音中：5 根柱子的波形；空闲：麦克风 -->
      <span v-if="state !== 'idle'" class="wave" aria-hidden="true">
        <i v-for="n in 5" :key="n" :style="{ animationDelay: (n - 1) * 90 + 'ms' }"></i>
      </span>
      <svg v-else viewBox="0 0 16 16" width="13" height="13" aria-hidden="true">
        <path
          d="M8 2.2c.9 0 1.6.7 1.6 1.6v3.4c0 .9-.7 1.6-1.6 1.6S6.4 8.1 6.4 7.2V3.8c0-.9.7-1.6 1.6-1.6Z"
          fill="currentColor" />
        <path
          d="M4.2 7.1v.6a3.8 3.8 0 0 0 7.6 0v-.6M8 11.5V14M6 14h4"
          fill="none"
          stroke="currentColor"
          stroke-width="1.2"
          stroke-linecap="round" />
      </svg>
    </button>

    <Transition name="vhint">
      <div v-if="hint" class="voice-hint">
        <span class="vh-dot" :class="state"></span>
        <span class="vh-text">{{ hint }}</span>
        <span v-if="live" class="vh-live">“{{ live }}”</span>
      </div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, onBeforeUnmount } from 'vue';
  import { useI18n } from '@/i18n';
  import { notify } from '@/store/ui';
  import { createRecognition, hasRecognition } from '@/utils/speech';

  const emit = defineEmits(['text', 'state']);
  const { t, lang } = useI18n();

  const state = ref<'idle' | 'listening' | 'recognizing'>('idle');
  const hint = ref('');
  const live = ref('');
  let rec: any = null;
  let demoTimers: any[] = [];

  const DEMO_LINES = {
    zh: '计算机应用技术能去哪些岗位，我想看看对口的',
    en: 'Which jobs fit my major, computer application technology?'
  };

  const clearDemo = () => {
    demoTimers.forEach((x) => {
      clearTimeout(x);
      clearInterval(x);
    });
    demoTimers = [];
  };

  const setState = (s) => {
    state.value = s;
    emit('state', s);
  };

  const finish = (text) => {
    setState('idle');
    hint.value = t('v.done');
    live.value = '';
    emit('text', text);
    demoTimers.push(setTimeout(() => (hint.value = ''), 2200));
  };

  /**
   * 演示输入：浏览器不给识别能力（或没授权麦克风）时的降级。
   * 明确写成「演示」，不假装是识别结果 —— 这里最容易被做假，
   * 一旦用户以为自己说的话被听懂了，后面全错。
   */
  const runDemo = (why) => {
    setState('listening');
    hint.value = why;
    live.value = '';
    demoTimers.push(
      setTimeout(() => {
        setState('recognizing');
        hint.value = t('v.recognizing');
      }, 1100)
    );
    demoTimers.push(
      setTimeout(() => {
        finish(DEMO_LINES[lang.value] || DEMO_LINES.zh);
        notify(t('v.demoFill'));
      }, 1750)
    );
  };

  const stop = () => {
    if (rec) {
      try {
        rec.stop();
      } catch (e) {
        /* 已经结束了 */
      }
      rec = null;
    }
    setState('recognizing');
    hint.value = t('v.recognizing');
    // 有的浏览器 onend 不回调，兜个底
    demoTimers.push(
      setTimeout(() => {
        if (state.value !== 'idle') {
          setState('idle');
          hint.value = '';
          live.value = '';
        }
      }, 2600)
    );
  };

  const start = () => {
    if (!hasRecognition()) {
      runDemo(t('v.demo'));
      return;
    }
    rec = createRecognition({
      lang: lang.value === 'zh' ? 'zh-CN' : 'en-US',
      onPartial: (text) => {
        live.value = text.slice(-26);
        hint.value = t('v.listening');
      },
      onFinal: (text) => {
        rec = null;
        finish(text.trim());
      },
      onError: (code) => {
        rec = null;
        if (code === 'not-allowed' || code === 'service-not-allowed') {
          runDemo(t('v.micDenied'));
        } else if (code === 'no-speech') {
          setState('idle');
          hint.value = '';
          notify('没听到声音，再试一次');
        } else {
          runDemo(t('v.unsupported'));
        }
      },
      onEnd: () => {
        rec = null;
        if (state.value === 'listening') {
          setState('idle');
          hint.value = '';
        }
      }
    });
    if (!rec) {
      runDemo(t('v.demo'));
      return;
    }
    try {
      rec.start();
      setState('listening');
      hint.value = t('v.listening');
      live.value = '';
    } catch (e) {
      runDemo(t('v.demo'));
    }
  };

  const toggle = () => {
    if (state.value === 'idle') start();
    else stop();
  };

  onBeforeUnmount(() => {
    clearDemo();
    if (rec) {
      try {
        rec.stop();
      } catch (e) {
        /* 卸载时停不掉也无所谓，页面都走了 */
      }
    }
  });
</script>

<style lang="css" scoped>
  .voice-wrap {
    position: relative;
    display: inline-flex;
  }
  .voice-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    border: 1px solid #e3e8ef;
    border-radius: 50%;
    background: #fff;
    color: #6b7585;
    cursor: pointer;
    transition:
      color 0.16s var(--m-ease),
      border-color 0.16s var(--m-ease),
      background 0.16s var(--m-ease),
      transform 0.16s var(--m-ease);
  }
  .voice-btn:hover {
    color: #2f6bff;
    border-color: #c3d3fb;
    background: #f6f9ff;
  }
  .voice-btn:active {
    transform: scale(0.94);
  }
  .voice-btn.listening {
    color: #fff;
    border-color: #2f6bff;
    background: #2f6bff;
    box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.16);
  }
  .voice-btn.recognizing {
    color: #2f6bff;
    border-color: #c3d3fb;
    background: #eef3ff;
  }
  .wave {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    height: 12px;
  }
  .wave i {
    display: block;
    width: 2px;
    height: 100%;
    border-radius: 2px;
    background: currentColor;
    transform-origin: center;
    animation: vwave 0.86s var(--m-ease) infinite;
  }
  .wave i:nth-child(2),
  .wave i:nth-child(4) {
    animation-duration: 0.7s;
  }
  .wave i:nth-child(3) {
    animation-duration: 1s;
  }
  @keyframes vwave {
    0%,
    100% {
      transform: scaleY(0.32);
      opacity: 0.7;
    }
    50% {
      transform: scaleY(1);
      opacity: 1;
    }
  }
  .voice-hint {
    position: absolute;
    bottom: 36px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 60;
    display: flex;
    align-items: center;
    gap: 6px;
    max-width: 340px;
    padding: 6px 10px;
    border-radius: 8px;
    background: rgba(24, 30, 42, 0.93);
    color: #fff;
    font-size: 11.5px;
    white-space: nowrap;
    box-shadow: var(--m-shadow-3, 0 10px 26px rgba(20, 30, 50, 0.18));
  }
  .vh-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #8ee6a8;
    flex-shrink: 0;
  }
  .vh-dot.listening {
    background: #ff8a8a;
    animation: vdot 1s ease-in-out infinite;
  }
  .vh-dot.recognizing {
    background: #ffd27a;
    animation: vdot 0.8s ease-in-out infinite;
  }
  @keyframes vdot {
    50% {
      opacity: 0.35;
    }
  }
  .vh-text {
    flex-shrink: 0;
  }
  .vh-live {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #9fc0ff;
  }
  .vhint-enter-active {
    animation: vhIn 0.18s var(--m-ease) both;
  }
  .vhint-leave-active {
    transition: opacity 0.14s linear;
  }
  .vhint-leave-to {
    opacity: 0;
  }
  @keyframes vhIn {
    from {
      opacity: 0;
      transform: translate(-50%, 4px);
    }
  }
</style>
