/**
 * 导出/下载的小工具。
 * 全部在前端生成 —— 演示环境没有后端，但下载下来的确实是一份能打开的文件，
 * 不是假按钮。CSV 带 BOM，Excel 双击打开中文不乱码。
 */

function pad(n: number) {
  return n < 10 ? '0' + n : String(n);
}

/** 文件名里的日期戳：20261112-2230 */
export function stamp(d = new Date()) {
  return (
    d.getFullYear() +
    pad(d.getMonth() + 1) +
    pad(d.getDate()) +
    '-' +
    pad(d.getHours()) +
    pad(d.getMinutes())
  );
}

export function downloadText(filename: string, text: string, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // 立刻 revoke 在部分浏览器会让下载失败，留一帧
  setTimeout(() => URL.revokeObjectURL(url), 1200);
}

function escCell(v: any) {
  const s = v === null || v === undefined ? '' : String(v);
  if (/[",\n\r]/.test(s)) return '"' + s.split('"').join('""') + '"';
  return s;
}

/** 二维数组 → CSV 文本（带 BOM） */
export function toCsv(rows: any[][]) {
  const body = rows.map((r) => r.map(escCell).join(',')).join('\r\n');
  return '\ufeff' + body;
}

/** 二维数组 → TSV，用来「复制为表格」直接粘进 Excel */
export function toTsv(rows: any[][]) {
  return rows
    .map((r) =>
      r
        .map((c) => {
          const s = c === null || c === undefined ? '' : String(c);
          return s.replace(/\t/g, ' ').replace(/\r?\n/g, ' ');
        })
        .join('\t')
    )
    .join('\n');
}

export function downloadCsv(name: string, rows: any[][]) {
  const file = name.endsWith('.csv') ? name : name + '.csv';
  downloadText(file, toCsv(rows), 'text/csv;charset=utf-8');
  return file;
}

export function downloadMarkdown(name: string, md: string) {
  const file = name.endsWith('.md') ? name : name + '.md';
  downloadText(file, md, 'text/markdown;charset=utf-8');
  return file;
}

export async function copyText(text: string) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) {
    /* 落到下面的 execCommand 兜底 */
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    return false;
  }
}

/** 字节数 → 人读的大小 */
export function humanSize(bytes: number) {
  if (!bytes && bytes !== 0) return '—';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}
