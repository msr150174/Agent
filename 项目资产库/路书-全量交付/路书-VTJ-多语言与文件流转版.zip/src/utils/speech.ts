/**
 * 语音：一条进（识别），一条出（朗读）。
 *
 * 两条都要「能力检测 + 诚实降级」：
 * - 识别依赖 Web Speech API，只有 Chrome / Edge 有，且必须用户给麦克风权限。
 *   拿不到就走演示输入，界面上明确写「演示模式 · 未接入真实语音识别」，
 *   不能假装识别成功。
 * - 朗读依赖 speechSynthesis。长文本一次喂进去有的浏览器会中途断，
 *   所以按标点切成小段排队读，读完一段再下一段。
 */

type RecHandlers = {
  onPartial?: (text: string) => void;
  onFinal?: (text: string) => void;
  onError?: (code: string) => void;
  onEnd?: () => void;
  lang?: string;
};

export function hasRecognition() {
  return typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function createRecognition(h: RecHandlers) {
  const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!Ctor) return null;
  const rec = new Ctor();
  rec.lang = h.lang || 'zh-CN';
  rec.interimResults = true;
  rec.continuous = false;
  rec.maxAlternatives = 1;

  let finalText = '';
  rec.onresult = (e: any) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (interim && h.onPartial) h.onPartial(finalText + interim);
    if (finalText && h.onFinal) h.onFinal(finalText);
  };
  rec.onerror = (e: any) => {
    if (h.onError) h.onError(e.error || 'unknown');
  };
  rec.onend = () => {
    if (h.onEnd) h.onEnd();
  };
  return rec;
}

export function hasSpeech() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

/** 找一个能读中文的声音；找不到就让浏览器用默认的 */
export function pickVoice(lang = 'zh-CN') {
  if (!hasSpeech()) return null;
  const list = window.speechSynthesis.getVoices() || [];
  if (!list.length) return null;
  const exact = list.find((v) => v.lang && v.lang.toLowerCase() === lang.toLowerCase());
  if (exact) return exact;
  const loose = list.find((v) => v.lang && v.lang.toLowerCase().indexOf(lang.slice(0, 2)) === 0);
  return loose || null;
}

/** 长文本按句切段：一句一段，最多 120 字一段，避免一口气读到一半断掉 */
export function splitForSpeech(text: string, max = 120) {
  const clean = String(text || '')
    .replace(/【[^】]*】/g, ' ')
    .replace(/[#*_`>]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) return [];
  const parts = clean.split(/(?<=[。！？；.!?;])\s*/g);
  const out: string[] = [];
  let buf = '';
  parts.forEach((p) => {
    if (!p) return;
    if ((buf + p).length > max && buf) {
      out.push(buf);
      buf = p;
    } else {
      buf += p;
    }
  });
  if (buf) out.push(buf);
  return out;
}

/**
 * 朗读一段长文本。返回句柄：stop 立刻停（并清空队列），
 * onDone 只在自然读完时触发 —— 手动停不该冒「读完了」。
 */
export function speak(text: string, opts: { lang?: string; onDone?: () => void; onStart?: () => void } = {}) {
  if (!hasSpeech()) return null;
  const segs = splitForSpeech(text);
  if (!segs.length) return null;

  const synth = window.speechSynthesis;
  const voice = pickVoice(opts.lang || 'zh-CN');
  let stopped = false;
  let idx = 0;

  const next = () => {
    if (stopped) return;
    if (idx >= segs.length) {
      if (opts.onDone) opts.onDone();
      return;
    }
    const u = new SpeechSynthesisUtterance(segs[idx]);
    u.lang = opts.lang || 'zh-CN';
    if (voice) u.voice = voice;
    u.rate = 1;
    u.pitch = 1;
    u.onend = () => {
      idx += 1;
      next();
    };
    u.onerror = () => {
      idx += 1;
      next();
    };
    synth.speak(u);
  };

  synth.cancel();
  if (opts.onStart) opts.onStart();
  next();

  return {
    stop() {
      stopped = true;
      try {
        synth.cancel();
      } catch (e) {
        /* 已经停了 */
      }
    },
    get stopped() {
      return stopped;
    }
  };
}
