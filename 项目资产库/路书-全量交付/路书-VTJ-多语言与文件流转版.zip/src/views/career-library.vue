<template>
  <div class="career-page">
    <div class="page-header">
      <div class="title-block">
        <h2>看清路</h2>
        <p class="page-desc">
          本专业的对口岗位，以及就业 / 专插本 / 考编三条路的差别。每个数字都标了来源，没有样本的不给数字。
        </p>
      </div>
      <div class="tip">匹配度是逐条比对算出来的参考值，不是录取概率。</div>
    </div>

    <div class="path-compare">
      <div class="path-head">
        <span class="path-title">三条路的差别</span>
        <span class="path-sub">就业与专插本按知识库原文；考编没收录，如实标出来</span>
      </div>
      <div class="path-grid">
        <div v-for="p in paths" :key="p.key" :class="['path-card', { miss: !p.covered }]">
          <span class="path-name">{{ p.name }}</span>
          <div class="path-row">
            <span class="path-k">起步门槛</span><span class="path-v">{{ p.threshold }}</span>
          </div>
          <div class="path-row">
            <span class="path-k">时间成本</span><span class="path-v">{{ p.time }}</span>
          </div>
          <div class="path-row">
            <span class="path-k">主要风险</span><span class="path-v">{{ p.risk }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="toolbar">
      <ElInput v-model="keyword" class="search" clearable placeholder="搜岗位名或技能" />
      <ElSelect v-model="category" class="sel" placeholder="全部方向">
        <ElOption label="全部" value="全部" />
        <ElOption label="后端" value="后端" />
        <ElOption label="前端" value="前端" />
        <ElOption label="测试" value="测试" />
        <ElOption label="运维" value="运维" />
        <ElOption label="电商" value="电商" />
      </ElSelect>
      <span class="count">共 {{ filtered.length }} 个方向</span>
    </div>

    <div class="job-grid" @mousemove="trackSpot" @mouseleave="clearSpot">
      <div
        v-for="(job, index) in filtered"
        :key="job.id"
        class="job-card spot"
        :style="{ animationDelay: index * 45 + 'ms' }">
        <div class="job-top">
          <ElTag size="small" effect="plain">{{ job.category }}</ElTag>
          <div class="badges">
            <ElTag size="small" type="info">需求 {{ job.demand }}</ElTag>
          </div>
        </div>
        <h3 class="job-name">{{ job.name }}</h3>
        <p class="job-summary">{{ job.summary }}</p>

        <!-- 匹配度用一条行内细条表示：长度就是数值，比单个百分比好比较 -->
        <div class="match-row">
          <span class="match-label">匹配度参考</span>
          <span class="match-track"><i :style="{ width: job.match }"></i></span>
          <span class="match-val num">{{ job.match }}</span>
        </div>

        <div class="job-info">
          <span>薪资：{{ job.salary ? job.salary + '（' + job.salaryNote + '）' : '现有资料未覆盖' }}</span>
          <span>经验：{{ job.experience }}</span>
        </div>
        <div class="job-skills">
          <ElTag v-for="s in job.skills" :key="s" size="small" effect="plain" class="skill">{{ s }}</ElTag>
        </div>

        <div class="why">
          <span class="why-title">为什么推荐</span>
          <div v-for="(r, i) in job.reasons" :key="i" class="why-item">
            <span class="why-dot">·</span><span>{{ r }}</span>
          </div>
        </div>
        <div class="gap">
          <span class="gap-title">还差什么</span><span class="gap-text">{{ job.gap }}</span>
        </div>
        <div class="job-source">{{ job.source }}</div>

        <!-- ▲ 展开：把同一条事实摊成可以逐条对着做的三步，不新增内容 -->
        <button class="job-more press" @click="toggleDetail(job.id)">
          <span>{{ opened[job.id] ? '收起' : '展开细看' }}</span>
          <span :class="['jm-chev', { open: opened[job.id] }]">▾</span>
        </button>
        <div v-if="opened[job.id]" class="job-detail">
          <div v-for="(t, i) in detailOf(job)" :key="i" class="jd-row">
            <span class="idx">{{ String(i + 1).padStart(2, '0') }}</span>
            <span class="jd-text">{{ t }}</span>
          </div>
          <div class="jd-note">这三条都能在知识库对上原文，不是额外的建议。</div>
        </div>
      </div>
    </div>

    <div class="page-note">
      岗位薪资没有样本的，这里不显示数字 —— 直接写「现有资料未覆盖」。这比给一个看起来很像真的区间要靠谱。
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import { ElInput, ElSelect, ElOption, ElTag } from 'element-plus';

  const keyword = ref('');
  const category = ref('全部');

  /* 展开状态：按 job.id 记，默认收起 */
  const opened = reactive({});
  const toggleDetail = (id) => {
    opened[id] = !opened[id];
  };
  /* 展开区只重排已有事实，不新增结论 —— 三条分别对应 经验 / 差距 / 薪资口径 */
  const detailOf = (job) => [
    `门槛：${job.experience}；核心技能 ${job.skills.join(' / ')}。`,
    `本轮要补的：${job.gap}`,
    job.salary
      ? `薪资口径：${job.salary}，来源说明为「${job.salaryNote}」。`
      : '薪资口径：本校近两届回收样本不足 5 条，按事实规则留空，不给区间。'
  ];

  /* 光标高光：在网格上监听一次，写 CSS 变量，比给每张卡各绑一个监听省得多 */
  let rafId = 0;
  const trackSpot = (e) => {
    if (rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      const card = e.target.closest('.job-card');
      if (!card) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', e.clientX - r.left + 'px');
      card.style.setProperty('--my', e.clientY - r.top + 'px');
    });
  };
  const clearSpot = (e) => {
    const card = e.target.closest('.job-card');
    if (card) {
      card.style.removeProperty('--mx');
      card.style.removeProperty('--my');
    }
  };

  const paths = [
    {
      key: 'job',
      name: '直接就业',
      threshold: '大专学历 + 一个能演示的项目',
      time: '大三上开始投递，边实习边定岗',
      risk: '起薪偏低，岗位集中在中小公司',
      covered: true
    },
    {
      key: 'zsb',
      name: '专插本',
      threshold: '应届毕业 + 无违纪 + 通过省考试院考试',
      time: '2 年全日制本科',
      risk: '名额少、专业受限，需提前确认目标院校',
      covered: true
    },
    {
      key: 'kb',
      name: '考编 / 考公',
      threshold: '现有资料未覆盖',
      time: '现有资料未覆盖',
      risk: '现有资料未覆盖（建议问招生就业处）',
      covered: false
    }
  ];

  const careers = [
    {
      id: 1,
      name: 'Java 后端开发（初级）',
      category: '后端',
      match: '82%',
      demand: '中',
      salary: '',
      salaryNote: '现有资料未覆盖',
      experience: '0–1 年',
      summary: '写接口、连数据库、把业务逻辑落到能跑的代码上。中小公司居多，看项目不看学校。',
      skills: ['Java 基础', 'MySQL', 'Git'],
      reasons: [
        'C 组岗位表列了 7 项要求，你在校期间能覆盖 5 项（Java 基础、MySQL、Git、Linux 常用命令、一个框架）',
        '本校近两届去向里有 6 人进了中小公司后端岗，这条路是通的'
      ],
      gap: '还差一个能讲清楚的项目，和一次真实的接口联调经历',
      source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
    },
    {
      id: 2,
      name: 'Web 前端开发',
      category: '前端',
      match: '78%',
      demand: '高',
      salary: '6–9K',
      salaryNote: '本校样本 12 条',
      experience: '0–1 年',
      summary: '把设计稿做成页面，调接口、处理交互。入门门槛相对低，作品能直接看。',
      skills: ['HTML/CSS', 'JavaScript', 'Vue'],
      reasons: [
        'C 组把前端列为「作品可替代经验」的岗位，在校做的页面能直接放进作品集',
        '本校 12 条回收样本里，9 条在毕业前有过自主项目'
      ],
      gap: '还差一个部署上线、能发链接给人看的作品',
      source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
    },
    {
      id: 3,
      name: '软件测试',
      category: '测试',
      match: '74%',
      demand: '高',
      salary: '5–8K',
      salaryNote: '本校样本 9 条',
      experience: '0–1 年',
      summary: '写用例、跑回归、提缺陷单。对细心程度要求高，入门比开发平缓。',
      skills: ['测试用例', '缺陷管理', '基础 SQL'],
      reasons: [
        'C 组列出的能力项里，测试岗对算法要求最低，更看你有没有耐心把流程走完',
        'D 组样本显示这个岗位近两届招聘量稳定，专科可投'
      ],
      gap: '还差一次完整的用例设计练习（从需求到缺陷单走一遍）',
      source: '《2024 届毕业生就业质量回收样本》D 组 · 2025-01-15'
    },
    {
      id: 4,
      name: 'IT 运维 / 桌面运维',
      category: '运维',
      match: '70%',
      demand: '中',
      salary: '5–7K',
      salaryNote: '本校样本 6 条',
      experience: '0–1 年',
      summary: '管机房、装系统、处理日常故障。稳定，但要能接受值班和琐碎。',
      skills: ['Windows/Linux', '网络基础', '故障排查'],
      reasons: [
        'C 组把这个岗位列为「上手快、需求稳」的方向，适合先就业再择业',
        '本校 6 条样本里，4 条来自校企合作单位'
      ],
      gap: '还差一张网络或系统方向的入门证书，或一次校内机房维护经历',
      source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
    },
    {
      id: 5,
      name: '电商运营专员',
      category: '电商',
      match: '80%',
      demand: '高',
      salary: '5–8K',
      salaryNote: '本校样本 11 条',
      experience: '应届可投',
      summary: '管店铺日常、做活动、看数据。电子商务专业的对口主方向。',
      skills: ['店铺后台', '活动策划', 'Excel 数据'],
      reasons: [
        'C 组把电商运营列为电子商务专业匹配度最高的岗位，专业课程能直接对上',
        '本校 11 条样本里，7 条在大三实习后转正'
      ],
      gap: '还差一次真实店铺的运营数据复盘（哪怕是校园店铺）',
      source: '《电子商务专业对口岗位表》C 组 · 2025-03-09'
    },
    {
      id: 6,
      name: '跨境电商运营',
      category: '电商',
      match: '76%',
      demand: '中',
      salary: '',
      salaryNote: '现有资料未覆盖',
      experience: '0–1 年',
      summary: '面向海外平台的选品、上架、投放。英语要求比国内运营高。',
      skills: ['平台规则', '选品', '英语读写'],
      reasons: [
        'C 组把跨境电商单列，因为它对英语的要求和国内运营不是一个标准',
        'D 组提到这个方向近两年岗位数在涨，但本校回收样本不足 5 条'
      ],
      gap: '还差英语能力的证明（四级或平台实操），否则简历初筛容易被跳过',
      source: '《电子商务专业对口岗位表》C 组 · 2025-03-09'
    }
  ];

  const filtered = computed(() => {
    const kw = keyword.value.trim().toLowerCase();
    return careers.filter((c) => {
      const okCat = category.value === '全部' || c.category === category.value;
      const okKw =
        !kw ||
        c.name.toLowerCase().includes(kw) ||
        c.skills.some((s) => s.toLowerCase().includes(kw));
      return okCat && okKw;
    });
  });
</script>

<style lang="css" scoped>
  .career-page {
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .page-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
    max-width: 720px;
  }
  .tip {
    flex-shrink: 0;
    font-size: 11.5px;
    color: #9ca3af;
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 8px;
    padding: 8px 12px;
    max-width: 240px;
    line-height: 1.6;
  }
  .path-compare {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 14px 16px;
    margin-bottom: 14px;
  }
  .path-head {
    display: flex;
    align-items: baseline;
    gap: 8px;
    margin-bottom: 10px;
  }
  .path-title {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
  }
  .path-sub {
    font-size: 11.5px;
    color: #9ca3af;
  }
  .path-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 10px;
  }
  .path-card {
    border: 1px solid #eef0f3;
    border-radius: 8px;
    padding: 10px 12px;
    background: #fbfcfe;
  }
  .path-card.miss {
    background: #fffdf7;
    border-color: #ffe0a3;
  }
  .path-name {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #2f6bff;
    margin-bottom: 6px;
  }
  .path-card.miss .path-name {
    color: #a86a00;
  }
  .path-row {
    display: flex;
    gap: 6px;
    font-size: 12px;
    line-height: 1.6;
    margin-bottom: 4px;
  }
  .path-row:last-child {
    margin-bottom: 0;
  }
  .path-k {
    flex-shrink: 0;
    width: 56px;
    color: #9ca3af;
  }
  .path-v {
    color: #4b5563;
  }
  .toolbar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
  }
  .search {
    width: 220px;
  }
  .sel {
    width: 140px;
  }
  .count {
    font-size: 11.5px;
    color: #9ca3af;
  }
  .job-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 12px;
  }
  .job-card {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 14px 16px;
    display: flex;
    flex-direction: column;
    animation: jobIn 0.34s cubic-bezier(0.2, 0.8, 0.2, 1) both;
    transition: border-color 0.16s ease, box-shadow 0.16s ease, transform 0.16s ease;
  }
  .job-card:hover {
    border-color: #dbe4ff;
    box-shadow: 0 6px 20px rgba(47, 107, 255, 0.09);
    transform: translateY(-2px);
  }
  @keyframes jobIn {
    from {
      opacity: 0;
      transform: translateY(8px);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes barGrow {
    from {
      transform: scaleX(0);
    }
    to {
      transform: scaleX(1);
    }
  }
  .match-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 2px 0 10px;
  }
  .match-label {
    font-size: 11px;
    color: #9ca3af;
    flex-shrink: 0;
  }
  .match-track {
    flex: 1;
    height: 5px;
    min-width: 0;
    border-radius: 3px;
    background: #f1f4f9;
    overflow: hidden;
  }
  .match-track i {
    display: block;
    height: 100%;
    border-radius: 3px;
    background: linear-gradient(90deg, #a9c2ff, #2f6bff);
    transform-origin: left center;
    animation: barGrow 0.55s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .match-val {
    width: 34px;
    text-align: right;
    font-size: 11.5px;
    font-weight: 600;
    color: #2f6bff;
    flex-shrink: 0;
  }
  .job-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .badges {
    display: flex;
    gap: 6px;
  }
  .job-name {
    margin: 10px 0 6px;
    font-size: 15px;
    color: #1f2937;
  }
  .job-summary {
    margin: 0 0 10px;
    font-size: 12.5px;
    line-height: 1.75;
    color: #6b7280;
  }
  .job-info {
    display: flex;
    gap: 16px;
    font-size: 12px;
    color: #4b5563;
  }
  .job-skills {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 10px;
  }
  .why {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px dashed #eef0f3;
  }
  .why-title {
    display: block;
    font-size: 11.5px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .why-item {
    display: flex;
    gap: 4px;
    font-size: 12px;
    line-height: 1.7;
    color: #374151;
  }
  .why-dot {
    color: #2f6bff;
  }
  .gap {
    margin-top: 8px;
    font-size: 12px;
    line-height: 1.7;
  }
  .gap-title {
    display: inline-block;
    margin-right: 6px;
    padding: 0 6px;
    border-radius: 4px;
    background: #fff2e8;
    color: #b25b00;
    font-size: 11px;
  }
  .gap-text {
    color: #4b5563;
  }
  .job-source {
    margin-top: 10px;
    font-size: 11px;
    color: #b9bdc4;
  }
  /* ▲ 展开到最高：同一条事实摊成三步 */
  .job-more {
    margin-top: 10px;
    align-self: flex-start;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    border: 1px solid #e7ecf5;
    border-radius: 6px;
    background: #fff;
    color: #6b7280;
    font-size: 11px;
    font-family: inherit;
    cursor: pointer;
    transition:
      color var(--m-fast) var(--m-ease),
      border-color var(--m-fast) var(--m-ease),
      background var(--m-fast) var(--m-ease);
  }
  .job-more:hover {
    color: #2f6bff;
    border-color: #cfdcff;
    background: #f7f9ff;
  }
  .jm-chev {
    font-size: 9px;
    transition: transform var(--m-fast) var(--m-ease);
  }
  .jm-chev.open {
    transform: rotate(180deg);
  }
  .job-detail {
    margin-top: 8px;
    padding: 8px 10px;
    border-radius: 8px;
    background: #fbfcff;
    border: 1px solid #eef3fc;
    animation: refIn 0.22s var(--m-ease) both;
  }
  .jd-row {
    display: flex;
    gap: 7px;
    padding: 3px 0;
    font-size: 11.5px;
    line-height: 1.7;
    color: #4b5563;
  }
  .jd-text {
    flex: 1;
    min-width: 0;
  }
  .jd-note {
    margin-top: 5px;
    padding-top: 5px;
    border-top: 1px dashed #e6ecf8;
    font-size: 10.5px;
    color: #a8b0bd;
  }
  .page-note {
    margin-top: 14px;
    font-size: 11.5px;
    line-height: 1.8;
    color: #9ca3af;
  }
</style>
