<template>
  <div class="logs-page">
    <div class="page-header">
      <div class="title-block">
        <div class="side-note">教师侧 · 学生不可见</div>
        <h2>调用日志</h2>
        <p class="page-desc">
          看每次回答走了哪条链路、命中几篇、终审删了什么。W-L0 是安全熔断，命中就短路转人工。
        </p>
      </div>
      <div class="tools">
        <ElSelect v-model="onlyAbnormal" class="sel" placeholder="全部状态">
          <ElOption label="全部状态" value="全部" />
          <ElOption label="只看正常" value="正常" />
          <ElOption label="只看未覆盖兜底" value="未覆盖兜底" />
          <ElOption label="只看无出处拦截" value="无出处拦截" />
          <ElOption label="只看安全熔断" value="安全熔断" />
        </ElSelect>
        <button class="refresh-btn" :class="{ spinning: refreshing }" @click="handleRefresh">
          <span class="rf-ico">↻</span>
        </button>
        <span class="refresh-at">更新于 {{ updatedAt }}</span>
      </div>
    </div>

    <div class="summary">
      <div
        v-for="(s, si) in stats"
        :key="s.label"
        class="stat"
        :style="{ animationDelay: si * 45 + 'ms' }">
        <span class="stat-label">{{ s.label }}</span>
        <span :class="['stat-value', 'num', s.tone]">{{ fmtStat(si) }}</span>
        <span class="stat-foot">{{ s.foot }}</span>
      </div>
    </div>

    <!-- 覆盖度：读不过的会话单独说清楚，不并进 0 -->
    <div class="coverage">
      <span class="cov-dot"></span>
      <span class="cov-text">
        今日 128 次里有 <b>3 条未计入</b>（宿主会话格式不受支持），下表是其中 8 条抽样。
      </span>
      <button class="cov-toggle" @click="covOpen = !covOpen">
        {{ covOpen ? '收起' : '怎么算的' }}
      </button>
    </div>
    <div v-if="covOpen" class="cov-detail">
      只统计能读通的会话：读失败、格式不支持、宿主没有会话接口的三类，单独列在覆盖度里，不按 0 计入，
      也不在数字前加「≥」假装成下界。全部读不过时这一栏显示「—」，宁可空着。
    </div>

    <div class="insight">
      <!-- 活跃热力图：14 天 × 6 个时段，每格 4 小时 -->
      <div class="card heat-card">
        <div class="card-head">
          <span class="card-title">活跃热力图</span>
          <span class="card-sub">近 28 天 · 每格 4 小时</span>
          <span class="legend">
            <span class="lg-text">少</span>
            <i class="hm-cell lv0"></i><i class="hm-cell lv1"></i><i class="hm-cell lv2"></i
            ><i class="hm-cell lv3"></i><i class="hm-cell lv4"></i>
            <span class="lg-text">多</span>
          </span>
        </div>
        <div class="hm-body">
          <div class="hm-axis-y">
            <span v-for="h in hourLabels" :key="h">{{ h }}</span>
          </div>
          <div class="hm-wrap">
            <div class="hm-grid">
              <i
                v-for="cell in heatCells"
                :key="cell.i"
                :class="['hm-cell', 'lv' + cell.lv, { today: cell.today }]"
                :style="{ animationDelay: cell.i * 3 + 'ms' }"
                :title="cell.label"></i>
            </div>
            <div class="hm-axis-x">
              <span>{{ dayLabel(0) }}</span>
              <span>{{ dayLabel(9) }}</span>
              <span>{{ dayLabel(18) }}</span>
              <span class="ax-today">今天 {{ dayLabel(27) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 命中分组占比：一条堆叠条 + 图例 -->
      <div class="card dist-card">
        <div class="card-head">
          <span class="card-title">命中分组分布</span>
          <span class="card-sub">今日 128 次</span>
        </div>
        <div class="stack">
          <span
            v-for="(g, gi) in groups"
            :key="g.key"
            class="stack-seg"
            :class="'seg-' + gi"
            :style="{ width: g.pct + '%', animationDelay: gi * 70 + 'ms' }"></span>
        </div>
        <div class="dist-list">
          <div v-for="(g, gi) in groups" :key="g.key" class="dist-row">
            <i class="dist-dot" :class="'seg-' + gi"></i>
            <span class="dist-name">{{ g.name }}</span>
            <span class="dist-num">{{ g.count }}</span>
            <span class="dist-pct">{{ g.pct }}%</span>
          </div>
        </div>
      </div>
    </div>

    <div class="table-wrap">
      <ElTable :data="filtered" size="default" stripe>
        <ElTableColumn prop="time" label="调用时间" width="176" />
        <ElTableColumn prop="user" label="学生" width="90" />
        <ElTableColumn prop="question" label="学生的问题" min-width="180" />
        <ElTableColumn label="W-M1 意图" width="140">
          <template #default="{ row }">
            <ElTag size="small" :type="intentType(row.intent)">{{ row.intent }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="groups" label="命中分组" width="176" />
        <ElTableColumn prop="verdict" label="终审 V1.1" min-width="150" />
        <ElTableColumn label="状态" width="110">
          <template #default="{ row }">
            <ElTag size="small" :type="statusType(row.status)">{{ row.status }}</ElTag>
          </template>
        </ElTableColumn>
      </ElTable>
    </div>

    <div class="page-note">
      下表是今日 8 条抽样，完整记录按日期分页。 终审只有减法权：删掉没有出处的句子，不改写、不补充。这条记录里「删
      1 条无出处」「降级为未覆盖」都是它干的。
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed, onMounted } from 'vue';
  import { ElTable, ElTableColumn, ElTag, ElSelect, ElOption } from 'element-plus';

  const onlyAbnormal = ref('全部');
  const covOpen = ref(false);
  const refreshing = ref(false);
  const updatedAt = ref('10:34');

  const stats = [
    { label: '今日调用', num: 128, unit: '', foot: '其中 3 条未计入', tone: '' },
    { label: '平均响应', num: 1.8, unit: 's', dec: 1, foot: 'P95 3.4s', tone: '' },
    { label: '知识命中率', num: 62, unit: '%', foot: '兜底占 31%', tone: '' },
    { label: '无出处拦截', num: 9, unit: '', foot: '终审删句合计 14 处', tone: 'warn' },
    { label: '安全熔断', num: 2, unit: '', foot: 'W-L0 · 已转人工', tone: 'danger' }
  ];

  /* 数字滚动：600ms easeOutCubic，按卡片错开 70ms —— 让「这个数是算出来的」有过程感 */
  const shown = ref(stats.map(() => 0));
  const fmtStat = (i) => {
    const s = stats[i];
    const v = shown.value[i] || 0;
    return (s.dec ? v.toFixed(s.dec) : String(Math.round(v))) + (s.unit || '');
  };
  const runCount = () => {
    stats.forEach((s, i) => {
      const t0 = performance.now() + i * 70;
      const dur = 620;
      const tick = () => {
        const p = Math.min(1, Math.max(0, (performance.now() - t0) / dur));
        const e = 1 - Math.pow(1 - p, 3);
        shown.value[i] = s.num * e;
        if (p < 1) requestAnimationFrame(tick);
        else shown.value[i] = s.num;
      };
      requestAnimationFrame(tick);
    });
  };

  // 14 天 × 6 时段（每格 4 小时），值 0–4 就是颜色深浅
  /**
   * 28 天 × 6 时段的活跃数据。
   * 手写 168 个数字既难维护又假得露骨，所以用固定种子的线性同余生成 ——
   * 每次刷新都一样（能截图对比），但分布像真的：白天的时段厚、周末薄。
   */
  const HEAT = (() => {
    let seed = 20250310;
    const rnd = () => {
      seed = (seed * 1103515245 + 12345) % 2147483648;
      return seed / 2147483648;
    };
    const rows = [];
    for (let r = 0; r < 6; r++) {
      const hour = r * 4;
      const dayBase = hour >= 8 && hour < 20 ? 1 : 0.34;
      const row = [];
      for (let c = 0; c < 28; c++) {
        const weekday = (c + 3) % 7;
        const weekendDip = weekday === 5 || weekday === 6 ? 0.45 : 1;
        // 越靠近今天越活跃（考试季）
        const trend = 0.55 + (c / 27) * 0.6;
        const v = rnd() * 4.5 * dayBase * weekendDip * trend;
        row.push(Math.max(0, Math.min(4, Math.round(v))));
      }
      rows.push(row);
    }
    return rows;
  })();
  const hourLabels = ['00', '04', '08', '12', '16', '20'];

  /* 28 列 = 28 天，最后一列是今天。日期用固定基准算，不依赖系统时间 */
  const dayLabel = (d) => {
    const base = new Date(2025, 1, 10); // 02-10
    const dt = new Date(base.getTime() + d * 86400000);
    return String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0');
  };

  const heatCells = computed(() => {
    const out = [];
    for (let d = 0; d < 28; d++) {
      for (let h = 0; h < 6; h++) {
        out.push({
          i: d * 6 + h,
          lv: HEAT[h][d],
          today: d === 27,
          label: `${dayLabel(d)} ${hourLabels[h]}:00 时段 · ${HEAT[h][d] * 7} 次`
        });
      }
    }
    return out;
  });

  const groups = [
    { key: 'a', name: 'A 组 · 专业与岗位', count: 34, pct: 27 },
    { key: 'b', name: 'B 组 · 证书与考试', count: 12, pct: 9 },
    { key: 'c', name: 'C 组 · 岗位与能力', count: 38, pct: 30 },
    { key: 'd', name: 'D 组 · 行业与就业数据', count: 15, pct: 12 },
    { key: 'e', name: 'E 组 · 求职技能', count: 9, pct: 7 },
    { key: 'miss', name: '未命中 · 走兜底', count: 20, pct: 15 }
  ];

  const logs = [
    {
      id: 1,
      time: '2025-03-13 10:32:18',
      user: '李同学',
      question: '专插本报名要什么条件',
      intent: 'W-M1 升学政策',
      groups: 'A 组 ×2',
      verdict: '只查不改 · 通过',
      status: '正常'
    },
    {
      id: 2,
      time: '2025-03-13 10:31:05',
      user: '陈同学',
      question: '计算机应用技术能去哪些岗位',
      intent: 'W-M1 职业认知',
      groups: 'C 组 ×2 · D 组 ×1',
      verdict: '删 1 条无出处',
      status: '正常'
    },
    {
      id: 3,
      time: '2025-03-13 10:29:47',
      user: '王同学',
      question: '跨境电商薪资多少',
      intent: 'W-M1 职业认知',
      groups: 'D 组（样本 4）',
      verdict: '降级为未覆盖',
      status: '未覆盖兜底'
    },
    {
      id: 4,
      time: '2025-03-13 10:28:33',
      user: '李同学',
      question: '大一该先准备什么',
      intent: 'W-M1 成长计划',
      groups: 'A 组 ×2 · C 组 ×1',
      verdict: '只查不改 · 通过',
      status: '正常'
    },
    {
      id: 5,
      time: '2025-03-13 10:15:12',
      user: '刘同学',
      question: '考编要考什么科目',
      intent: 'W-M1 升学政策',
      groups: '—',
      verdict: '短路 · 未检索',
      status: '未覆盖兜底'
    },
    {
      id: 6,
      time: '2025-03-13 09:58:40',
      user: '张同学',
      question: '不想读了，觉得没意义',
      intent: 'W-L0 安全熔断',
      groups: '—',
      verdict: '短路 · 转人工',
      status: '安全熔断'
    },
    {
      id: 7,
      time: '2025-03-13 09:45:03',
      user: '陈同学',
      question: '简历没项目经历怎么写',
      intent: 'W-M1 求职技能',
      groups: 'E 组 ×2',
      verdict: '只查不改 · 通过',
      status: '正常'
    },
    {
      id: 8,
      time: '2025-03-13 09:30:27',
      user: '王同学',
      question: '这个专业是不是没前途',
      intent: 'W-M1 职业认知',
      groups: '—',
      verdict: '拦截 · 无出处',
      status: '无出处拦截'
    }
  ];

  const filtered = computed(() =>
    onlyAbnormal.value === '全部' ? logs : logs.filter((l) => l.status === onlyAbnormal.value)
  );

  const intentType = (s) => {
    if (s.indexOf('W-L0') > -1) return 'danger';
    if (s.indexOf('升学') > -1) return 'warning';
    if (s.indexOf('成长') > -1) return 'info';
    return 'primary';
  };
  const statusType = (s) => {
    if (s === '正常') return 'success';
    if (s === '未覆盖兜底') return 'warning';
    if (s === '安全熔断') return 'danger';
    return 'info';
  };
  const handleRefresh = () => {
    if (refreshing.value) return;
    refreshing.value = true;
    shown.value = stats.map(() => 0);
    runCount();
    setTimeout(() => {
      refreshing.value = false;
      const d = new Date();
      const pad = (n) => String(n).padStart(2, '0');
      updatedAt.value = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }, 700);
  };

  onMounted(runCount);
</script>

<style lang="css" scoped>
  @keyframes cardIn {
    from {
      opacity: 0;
      transform: translateY(6px);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes cellIn {
    from {
      opacity: 0;
      transform: scale(0.6);
    }
    to {
      opacity: 1;
      transform: none;
    }
  }
  @keyframes segGrow {
    from {
      transform: scaleX(0);
    }
    to {
      transform: scaleX(1);
    }
  }
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  .logs-page {
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
  }
  .side-note {
    display: inline-block;
    margin-bottom: 8px;
    padding: 2px 8px;
    border-radius: 4px;
    background: #f3f4f6;
    color: #6b7280;
    font-size: 11px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .page-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
    max-width: 700px;
  }
  .tools {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
  }
  .sel {
    width: 170px;
  }
  .refresh-btn {
    width: 30px;
    height: 30px;
    padding: 0;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #fff;
    color: #6b7280;
    cursor: pointer;
    transition: color 0.16s ease, border-color 0.16s ease, background 0.16s ease;
  }
  .refresh-btn:hover {
    color: #2f6bff;
    border-color: #c9d8ff;
    background: #f7f9ff;
  }
  .rf-ico {
    display: inline-block;
    font-size: 14px;
    line-height: 1;
  }
  .refresh-btn.spinning .rf-ico {
    animation: spin 0.7s linear infinite;
  }
  .refresh-at {
    font-size: 11.5px;
    color: #9ca3af;
  }

  .summary {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 10px;
    margin-bottom: 10px;
  }
  .stat {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    padding: 12px 14px;
    animation: cardIn 0.32s cubic-bezier(0.2, 0.8, 0.2, 1) both;
    transition: border-color 0.16s ease, box-shadow 0.16s ease, transform 0.16s ease;
  }
  .stat:hover {
    border-color: #dbe4ff;
    box-shadow: 0 4px 14px rgba(47, 107, 255, 0.08);
    transform: translateY(-1px);
  }
  .stat-label {
    display: block;
    font-size: 11.5px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .stat-value {
    display: block;
    font-size: 18px;
    font-weight: 600;
    color: #1f2937;
    line-height: 1.3;
  }
  .stat-value.warn {
    color: #d97706;
  }
  .stat-value.danger {
    color: #dc2626;
  }
  .stat-foot {
    display: block;
    margin-top: 2px;
    font-size: 10.5px;
    color: #b9bdc4;
  }

  .coverage {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    margin-bottom: 12px;
    background: #fbfcfe;
    border: 1px solid #eef0f3;
    border-radius: 8px;
    font-size: 11.5px;
    color: #6b7280;
  }
  .cov-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #c3c8d0;
    flex-shrink: 0;
  }
  .cov-text b {
    color: #1f2937;
    font-weight: 600;
  }
  .cov-toggle {
    margin-left: auto;
    padding: 2px 8px;
    border: 1px solid #e5e7eb;
    border-radius: 999px;
    background: #fff;
    color: #6b7280;
    font-size: 11px;
    cursor: pointer;
    transition: color 0.16s ease, border-color 0.16s ease;
  }
  .cov-toggle:hover {
    color: #2f6bff;
    border-color: #c9d8ff;
  }
  .cov-detail {
    margin: -4px 0 12px;
    padding: 10px 12px;
    border-left: 3px solid #dbe4ff;
    background: #f7f9ff;
    border-radius: 6px;
    font-size: 11.5px;
    line-height: 1.9;
    color: #6b7280;
    animation: cardIn 0.24s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }

  .insight {
    display: grid;
    grid-template-columns: minmax(0, 1.35fr) minmax(0, 1fr);
    gap: 10px;
    margin-bottom: 12px;
  }
  .card {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 12px 14px 14px;
    animation: cardIn 0.34s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .card-head {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
  }
  .card-title {
    font-size: 12.5px;
    font-weight: 600;
    color: #1f2937;
  }
  .card-sub {
    font-size: 11px;
    color: #9ca3af;
  }
  .legend {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 3px;
  }
  .lg-text {
    font-size: 10px;
    color: #b9bdc4;
    margin: 0 3px;
  }

  .hm-body {
    display: flex;
    gap: 8px;
  }
  .hm-axis-y {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-size: 10px;
    color: #b9bdc4;
    padding: 1px 0;
  }
  .hm-wrap {
    flex: 1;
    min-width: 0;
  }
  .hm-grid {
    display: grid;
    grid-template-rows: repeat(6, minmax(0, 1fr));
    grid-auto-flow: column;
    grid-auto-columns: minmax(0, 1fr);
    gap: 4px;
    height: 132px;
  }
  .hm-cell {
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    background: #f0f3f8;
    transition: transform 0.16s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.16s ease;
  }
  .legend .hm-cell {
    width: 11px;
    height: 11px;
    border-radius: 3px;
  }
  .hm-grid .hm-cell {
    animation: cellIn 0.3s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .hm-cell:hover {
    transform: scale(1.35);
    box-shadow: 0 0 0 2px #fff, 0 2px 8px rgba(47, 107, 255, 0.35);
  }
  .hm-cell.lv0 {
    background: #f0f3f8;
  }
  .hm-cell.lv1 {
    background: #d6e2ff;
  }
  .hm-cell.lv2 {
    background: #a9c2ff;
  }
  .hm-cell.lv3 {
    background: #6f95ff;
  }
  .hm-cell.lv4 {
    background: #2f6bff;
  }
  .hm-axis-x {
    display: flex;
    justify-content: space-between;
    margin-top: 6px;
    font-size: 10px;
    color: #b9bdc4;
  }
  .hm-axis-x .ax-today {
    color: #5b6b84;
    font-weight: 600;
  }
  /* 今天那一列描个细边：一眼能找到「现在在哪」（参考实现用 label-secondary 描边） */
  .hm-grid .hm-cell.today {
    outline: 1px solid #aab4c4;
    outline-offset: -1px;
  }

  .stack {
    display: flex;
    height: 10px;
    border-radius: 5px;
    overflow: hidden;
    background: #f3f4f6;
    margin-bottom: 12px;
  }
  .stack-seg {
    height: 100%;
    transform-origin: left center;
    animation: segGrow 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) both;
  }
  .dist-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .dist-row {
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 11.5px;
    color: #6b7280;
  }
  .dist-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex-shrink: 0;
  }
  .dist-name {
    flex: 1;
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .dist-num {
    color: #1f2937;
    font-weight: 500;
  }
  .dist-pct {
    width: 34px;
    text-align: right;
    color: #9ca3af;
  }
  .seg-0 {
    background: #2f6bff;
  }
  .seg-1 {
    background: #6f95ff;
  }
  .seg-2 {
    background: #22b8a6;
  }
  .seg-3 {
    background: #f0a93b;
  }
  .seg-4 {
    background: #a78bfa;
  }
  .seg-5 {
    background: #d7dbe2;
  }

  :deep(.cell) {
    white-space: nowrap;
  }
  .table-wrap {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 6px 6px 2px;
  }
  .page-note {
    margin-top: 12px;
    font-size: 11.5px;
    line-height: 1.8;
    color: #9ca3af;
  }

  @media (max-width: 1280px) {
    .summary {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
    .insight {
      grid-template-columns: minmax(0, 1fr);
    }
  }
</style>
