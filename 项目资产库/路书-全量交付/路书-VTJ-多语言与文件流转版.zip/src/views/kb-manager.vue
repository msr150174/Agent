<template>
  <div class="km-page">
    <div class="page-header">
      <div class="title-block">
        <div class="side-note">教师侧 · 学生不可见</div>
        <h2>知识库管理</h2>
        <p class="page-desc">
          上传后必须过 front-matter 校验（title / group / source / effective_date），缺一项就退回。学生端能不能回答，取决于这里。
        </p>
      </div>
      <div class="tools">
        <ElInput v-model="keyword" class="search" clearable placeholder="搜文档标题" />
        <ElSelect v-model="category" class="sel" placeholder="全部分组">
          <ElOption label="全部" value="全部" />
          <ElOption label="A 专业与岗位" value="A 专业与岗位" />
          <ElOption label="B 证书与考试" value="B 证书与考试" />
          <ElOption label="C 岗位与能力" value="C 岗位与能力" />
          <ElOption label="D 行业与就业数据" value="D 行业与就业数据" />
          <ElOption label="E 求职技能" value="E 求职技能" />
        </ElSelect>
        <ElButton type="primary" @click="uploadVisible = true">上传文档</ElButton>
      </div>
    </div>

    <div class="stats">
      <div class="stat">
        <span class="stat-label">文档总数</span>
        <span class="stat-value">{{ counts.total }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">待审核</span>
        <span class="stat-value warn">{{ counts.pending }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">已发布</span>
        <span class="stat-value ok">{{ counts.published }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">已驳回</span>
        <span class="stat-value danger">{{ counts.rejected }}</span>
      </div>
    </div>

    <div class="table-wrap">
      <ElTable :data="filtered" size="default" stripe>
        <ElTableColumn prop="title" label="文档标题" min-width="240" />
        <ElTableColumn label="分组" width="160">
          <template #default="{ row }">
            <ElTag size="small" effect="plain">{{ row.category }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="uploader" label="上传人" width="90" />
        <ElTableColumn prop="source" label="来源" min-width="160" />
        <ElTableColumn label="状态" width="100">
          <template #default="{ row }">
            <ElTag size="small" :type="statusType(row.status)">{{ row.status }}</ElTag>
          </template>
        </ElTableColumn>
        <ElTableColumn prop="updatedAt" label="更新时间" width="160" />
        <ElTableColumn label="操作" width="150">
          <template #default="{ row }">
            <template v-if="row.status === '待审核'">
              <ElButton link type="primary" size="small" @click="approve(row)">审核通过</ElButton>
              <ElButton link type="danger" size="small" @click="reject(row)">驳回</ElButton>
            </template>
            <span v-else class="done-hint">已完成</span>
          </template>
        </ElTableColumn>
      </ElTable>
    </div>

    <ElDialog v-model="uploadVisible" title="上传文档" width="480px">
      <div class="form">
        <div class="row">
          <span class="label">文档标题</span>
          <ElInput v-model="form.title" placeholder="与知识库内标题一致" />
        </div>
        <div class="row">
          <span class="label">分组</span>
          <ElSelect v-model="form.category" placeholder="选择 A–E 分组">
            <ElOption label="A 专业与岗位" value="A 专业与岗位" />
            <ElOption label="B 证书与考试" value="B 证书与考试" />
            <ElOption label="C 岗位与能力" value="C 岗位与能力" />
            <ElOption label="D 行业与就业数据" value="D 行业与就业数据" />
            <ElOption label="E 求职技能" value="E 求职技能" />
          </ElSelect>
        </div>
        <div class="row">
          <span class="label">文件</span>
          <ElUpload v-model:file-list="form.files" class="upload" drag :auto-upload="false">
            <div class="upload-tip">
              <span class="upload-icon">📄</span>
              <p>将文件拖到这里，或<em>点击选择</em></p>
            </div>
            <template #tip>
              <div class="el-upload__tip">
                仅支持 .md / .txt / .pdf；front-matter 必填 title / group / source / effective_date
              </div>
            </template>
          </ElUpload>
        </div>
        <div class="row">
          <span class="label">备注</span>
          <ElInput v-model="form.remark" type="textarea" :rows="2" placeholder="给审核人看的说明" />
        </div>
      </div>
      <template #footer>
        <ElButton @click="uploadVisible = false">取消</ElButton>
        <ElButton type="primary" @click="submit">提交校验</ElButton>
      </template>
    </ElDialog>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import {
    ElTable,
    ElTableColumn,
    ElTag,
    ElInput,
    ElSelect,
    ElOption,
    ElButton,
    ElDialog,
    ElUpload,
    ElMessage
  } from 'element-plus';

  const keyword = ref('');
  const category = ref('全部');
  const uploadVisible = ref(false);
  const form = reactive({ title: '', category: '', files: [], remark: '' });

  const docs = reactive([
    { id: 1, title: '计算机应用技术专业对口岗位表', category: 'A 专业与岗位', uploader: '王老师', source: 'C 组岗位调研', status: '已发布', updatedAt: '2025-03-08 16:20:08' },
    { id: 2, title: '电子商务专业对口岗位表', category: 'A 专业与岗位', uploader: '李老师', source: '企业访谈整理', status: '已发布', updatedAt: '2025-03-09 14:32:45' },
    { id: 3, title: '专插本考试科目说明（校内整理）', category: 'B 证书与考试', uploader: '张老师', source: '教务处整理', status: '已发布', updatedAt: '2025-02-28 09:12:31' },
    { id: 4, title: '1+X Web 前端开发（初级）考核要求', category: 'B 证书与考试', uploader: '刘老师', source: '证书管理中心', status: '待审核', updatedAt: '2025-03-13 08:45:22' },
    { id: 5, title: '2024 届毕业生就业质量回收样本', category: 'D 行业与就业数据', uploader: '陈老师', source: '就业质量报告', status: '已发布', updatedAt: '2025-01-15 10:05:14' },
    { id: 6, title: '珠三角中小软件企业招聘观察', category: 'D 行业与就业数据', uploader: '赵老师', source: '招聘平台观测', status: '待审核', updatedAt: '2025-03-13 09:12:56' },
    { id: 7, title: '求职简历撰写与面试表达', category: 'E 求职技能', uploader: '孙老师', source: '就业指导中心', status: '已驳回', updatedAt: '2025-03-12 17:48:56' },
    { id: 8, title: 'Java 后端开发岗位能力清单', category: 'C 岗位与能力', uploader: '周老师', source: '岗位拆解（缺 source 字段）', status: '待审核', updatedAt: '2025-03-13 10:02:49' }
  ]);

  const filtered = computed(() => {
    const kw = keyword.value.trim();
    return docs.filter((d) => {
      const okCat = category.value === '全部' || d.category === category.value;
      const okKw = !kw || d.title.indexOf(kw) > -1;
      return okCat && okKw;
    });
  });

  const counts = computed(() => ({
    total: docs.length,
    pending: docs.filter((d) => d.status === '待审核').length,
    published: docs.filter((d) => d.status === '已发布').length,
    rejected: docs.filter((d) => d.status === '已驳回').length
  }));

  const statusType = (s) =>
    s === '已发布' ? 'success' : s === '待审核' ? 'warning' : 'danger';

  const approve = (row) => {
    row.status = '已发布';
    ElMessage.success(`《${row.title}》已审核通过`);
  };
  const reject = (row) => {
    row.status = '已驳回';
    ElMessage.warning(`《${row.title}》已驳回，需补齐 front-matter`);
  };
  const submit = () => {
    if (!form.title.trim()) return ElMessage.error('请填写文档标题');
    if (!form.category) return ElMessage.error('请选择分组');
    if (!form.files.length) return ElMessage.error('请上传文件');
    ElMessage.success('front-matter 校验通过，已进入待审核队列');
    uploadVisible.value = false;
    form.title = '';
    form.category = '';
    form.files = [];
    form.remark = '';
  };
</script>

<style lang="css" scoped>
  .km-page {
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
  }
  .side-note {
    display: inline-block;
    margin-bottom: 8px;
    padding: 2px 8px;
    border-radius: 4px;
    background: #f3f4f6;
    color: #6b7280;
    font-size: 11px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .page-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
    max-width: 700px;
  }
  .tools {
    display: flex;
    gap: 10px;
    flex-shrink: 0;
  }
  .search {
    width: 180px;
  }
  .sel {
    width: 170px;
  }
  .stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
    margin-bottom: 14px;
  }
  .stat {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 10px;
    padding: 12px 14px;
  }
  .stat-label {
    display: block;
    font-size: 11.5px;
    color: #9ca3af;
    margin-bottom: 4px;
  }
  .stat-value {
    font-size: 18px;
    font-weight: 600;
    color: #1f2937;
  }
  .stat-value.warn {
    color: #d97706;
  }
  .stat-value.ok {
    color: #16a34a;
  }
  .stat-value.danger {
    color: #dc2626;
  }
  .table-wrap {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 6px 6px 2px;
  }
  .done-hint {
    font-size: 11.5px;
    color: #b9bdc4;
  }
  .form {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .row {
    display: flex;
    align-items: flex-start;
    gap: 12px;
  }
  .label {
    width: 64px;
    flex-shrink: 0;
    font-size: 12.5px;
    color: #6b7280;
    line-height: 32px;
  }
  .row > :last-child {
    flex: 1;
    min-width: 0;
  }
  .upload {
    width: 100%;
  }
  .upload-tip {
    text-align: center;
    padding: 12px 0;
  }
  .upload-icon {
    font-size: 22px;
  }
  .upload-tip p {
    margin: 6px 0 0;
    font-size: 12px;
    color: #6b7280;
  }
  .upload-tip em {
    color: #2f6bff;
    font-style: normal;
  }
</style>
