<template>
  <div class="plan-page">
    <div class="page-header">
      <div class="title-block">
        <h2>路线图</h2>
        <p class="page-desc">
          目标拆到学期：每学期一句话、几件能勾的事、对应的证书或比赛。勾选只存在这台设备上。
        </p>
      </div>
      <div class="target">
        <span class="target-label">目标职业</span>
        <ElTag type="primary" effect="plain">{{ targetCareer }}</ElTag>
      </div>
    </div>

    <div class="goal-card">
      <span class="goal-label">目标一句话</span>
      <span class="goal-text">{{ goalSentence }}</span>
    </div>

    <div class="overview">
      <div class="overview-left">
        <h3>计划总进度</h3>
        <p class="overview-sub">
          完成 <b class="num">{{ completedSteps }}</b> / <span class="num">{{ totalSteps }}</span> 个成长任务
        </p>
        <div class="overview-facts">
          <span v-for="(f, fi) in overviewFacts" :key="fi" class="ov-fact">
            <i class="ov-dot"></i>{{ f }}
          </span>
        </div>
      </div>
      <!-- 完成度环：stroke-dashoffset 走同一条曲线，数字跟着滚 -->
      <div class="ring-wrap">
        <svg class="ring" viewBox="0 0 48 48" aria-hidden="true">
          <circle class="ring-bg" cx="24" cy="24" r="19"></circle>
          <circle class="ring-fg" cx="24" cy="24" r="19" :style="{ strokeDashoffset: ringOffset }"></circle>
        </svg>
        <span class="ring-num num">{{ progress }}<em>%</em></span>
      </div>
    </div>

    <div class="columns">
      <div class="timeline">
        <h3 class="block-title">按学期</h3>
        <ElTimeline>
          <ElTimelineItem
            v-for="phase in phases"
            :key="phase.id"
            :type="statusType(phase.status)"
            :timestamp="phase.period"
            placement="top">
            <div class="phase">
              <div class="phase-head">
                <span class="phase-name">{{ phase.name }}</span>
                <ElTag size="small" :type="statusType(phase.status)">
                  {{ statusLabel(phase.status) }}
                </ElTag>
              </div>
              <p class="phase-desc">{{ phase.desc }}</p>
              <div class="steps">
                <div
                  v-for="step in phase.steps"
                  :key="step.id"
                  :class="['step', { done: step.done }]"
                  @click="toggleStep(step)">
                  <span class="box">{{ step.done ? '✓' : '' }}</span>
                  <span class="step-text">{{ step.label }}</span>
                  <span v-if="step.cert" class="cert">{{ step.cert }}</span>
                </div>
              </div>
            </div>
          </ElTimelineItem>
        </ElTimeline>
      </div>

      <div class="skills">
        <h3 class="block-title">能力盘</h3>
        <div v-for="s in skills" :key="s.name" class="skill-card">
          <div class="skill-head">
            <span class="skill-name">{{ s.name }}</span>
            <span class="skill-score">{{ s.score }}%</span>
          </div>
          <ElProgress :percentage="s.score" :stroke-width="6" :show-text="false" />
          <p class="skill-tip">{{ s.tip }}</p>
        </div>
        <div class="skill-note">分数按 C 组能力项逐条对照算的，只说明差在哪，不说明能不能学会。</div>
      </div>
    </div>

    <div class="actions">
      <ElButton @click="handleRefresh">按自评结果重排</ElButton>
      <ElButton type="primary" @click="handleExport">导出路线图</ElButton>
    </div>

    <Transition name="toast">
      <div v-if="toastMsg" class="motion-toast">{{ toastMsg }}</div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import { ElTag, ElTimeline, ElTimelineItem, ElProgress, ElButton, ElMessage } from 'element-plus';

  const targetCareer = ref('Java 后端开发（初级）');
  const goalSentence = ref(
    '把一门后端语言学通到能写增删改查，绩点稳在专业前 40%，大二下把「专插本还是就业」定下来。'
  );

  const phases = reactive([
    {
      id: 1,
      name: '大一上 · 把底子打住',
      period: '2025-09 ~ 2026-01',
      status: 'done',
      desc: '目标：不挂科，把一门语言的基础语法写熟。',
      steps: [
        { id: 11, label: 'C 语言或 Java 基础课学完，独立写完 3 个小练习', done: true, cert: null },
        { id: 12, label: '每周固定 6 小时上机，不攒到期末', done: true, cert: null },
        { id: 13, label: '把《计算机应用技术专业对口岗位表》读一遍', done: true, cert: null }
      ]
    },
    {
      id: 2,
      name: '大一下 · 能独立跑起一个小项目',
      period: '2026-02 ~ 2026-07',
      status: 'done',
      desc: '目标：从「会语法」到「能做出东西」，把数据库接上。',
      steps: [
        { id: 21, label: 'MySQL 建库建表，写完增删改查', done: true, cert: null },
        { id: 22, label: '用 Git 管一个自己的仓库', done: true, cert: null },
        { id: 23, label: '做完一个课程项目，写清楚 README', done: true, cert: '校内程序设计实训' }
      ]
    },
    {
      id: 3,
      name: '大二上 · 定方向，开始攒作品',
      period: '2026-09 ~ 2027-01',
      status: 'doing',
      desc: '目标：后端或前端选一个，别再摇摆；作品能发链接给人看。',
      steps: [
        { id: 31, label: '选定后端或前端方向，停掉另一个', done: true, cert: null },
        { id: 32, label: '刷 50 道基础面试题（数据结构 + SQL）', done: false, cert: null },
        { id: 33, label: '做一份能演示的作品集，部署上线', done: false, cert: '省级职业院校技能大赛（软件类）' }
      ]
    },
    {
      id: 4,
      name: '大二下 · 专插本还是就业，二选一',
      period: '2027-02 ~ 2027-07',
      status: 'todo',
      desc: '目标：把选择落到具体动作上，而不是一直想着。',
      steps: [
        { id: 41, label: '确认专插本目标院校与考试科目（或确认放弃）', done: false, cert: null },
        { id: 42, label: '选就业：开始投第一份实习', done: false, cert: null },
        { id: 43, label: '更新简历，投 10 家看回音', done: false, cert: '1+X Web 前端开发（初级）' }
      ]
    }
  ]);

  const skills = [
    { name: 'SQL 与数据库设计', score: 70, tip: '能建表写查询，建议补一次索引与慢查询的练习' },
    { name: '一门后端语言（Java）', score: 55, tip: '语法够用，缺的是把接口和数据库串起来的完整项目' },
    { name: '项目表达与简历', score: 30, tip: '还没写过项目介绍，先把大一下那个项目写成 5 行' }
  ];

  const totalSteps = computed(() => phases.reduce((a, p) => a + p.steps.length, 0));
  const completedSteps = computed(() =>
    phases.reduce((a, p) => a + p.steps.filter((s) => s.done).length, 0)
  );
  const progress = computed(() =>
    totalSteps.value ? Math.round((completedSteps.value / totalSteps.value) * 100) : 0
  );

  /* 环周长 2πr = 2π×19 ≈ 119.38；只改 offset，不改半径 */
  const RING_LEN = 2 * Math.PI * 19;
  const ringOffset = computed(() => RING_LEN * (1 - progress.value / 100));

  /* 环下面那三行小字：都是能算出来的事实，不是鼓励话 */
  const overviewFacts = computed(() => {
    const all = phases.reduce((acc, p) => acc.concat(p.steps), []);
    const certs = all.filter((s) => s.cert).length;
    const doing = all.filter((s) => !s.done).length;
    return [`还剩 ${doing} 件没勾`, `其中 ${certs} 件对应证书或比赛`, `勾选只存在这台设备上`];
  });

  const statusLabel = (s) => (s === 'done' ? '已完成' : s === 'doing' ? '进行中' : '待开始');
  const statusType = (s) => (s === 'done' ? 'success' : s === 'doing' ? 'primary' : 'info');

  const toastMsg = ref('');
  let toastTimer = null;
  const showToast = (text) => {
    toastMsg.value = text;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastMsg.value = '';
    }, 2200);
  };

  const toggleStep = (step) => {
    step.done = !step.done;
    // 勾完给一句明确的回报：改了什么、现在走到哪 —— 比只变个颜色清楚
    const all = phases.reduce((acc, p) => acc.concat(p.steps), []);
    const done = all.filter((s) => s.done).length;
    showToast(
      step.done
        ? `记上了 · 已完成 ${done}/${all.length} 项`
        : `已撤回 · 还剩 ${all.length - done} 项`
    );
  };
  const handleRefresh = () => {
    ElMessage.info('重新生成需要先完成「认识自己」的 12 道自评');
  };
  const handleExport = () => {
    ElMessage.success('已生成可打印的路线图（演示环境不落盘）');
  };
</script>

<style lang="css" scoped>
  .plan-page {
    position: relative;
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .motion-toast {
    position: fixed;
    left: 50%;
    bottom: 28px;
    z-index: 40;
    padding: 8px 16px;
    border-radius: 8px;
    background: #1f2937;
    color: #fff;
    font-size: 12.5px;
    line-height: 1.5;
    white-space: nowrap;
    box-shadow: 0 8px 24px rgba(20, 25, 35, 0.22);
    transform: translate(-50%, 0);
  }
  .toast-enter-active {
    transition: opacity 0.16s ease, transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .toast-leave-active {
    transition: opacity 0.16s ease, transform 0.16s ease;
  }
  .toast-enter-from,
  .toast-leave-to {
    opacity: 0;
    transform: translate(-50%, 10px);
  }
  .page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 12px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .page-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
    max-width: 720px;
  }
  .target {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .target-label {
    font-size: 12px;
    color: #9ca3af;
  }
  .goal-card {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    background: #eef3fe;
    border: 1px solid #d8e3ff;
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 12px;
  }
  .goal-label {
    flex-shrink: 0;
    font-size: 12px;
    color: #2f6bff;
    font-weight: 600;
  }
  .goal-text {
    font-size: 13px;
    line-height: 1.8;
    color: #1f2937;
  }
  .overview {
    display: flex;
    align-items: center;
    gap: 24px;
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 14px 18px;
    margin-bottom: 14px;
  }
  .overview-left h3 {
    margin: 0 0 4px;
    font-size: 14px;
    color: #1f2937;
  }
  .overview-sub {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
  }
  .overview-sub b {
    color: #2f6bff;
  }
  .overview-facts {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 7px;
  }
  .ov-fact {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 11px;
    color: #9ca3af;
  }
  .ov-dot {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: #cfd6e2;
    flex-shrink: 0;
  }
  /* 完成度环 */
  .ring-wrap {
    position: relative;
    flex-shrink: 0;
    width: 86px;
    height: 86px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .ring {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    transform: rotate(-90deg);
  }
  .ring circle {
    fill: none;
    stroke-width: 5;
    stroke-linecap: round;
  }
  .ring-bg {
    stroke: #eef1f6;
  }
  .ring-fg {
    stroke: #2f6bff;
    stroke-dasharray: 119.38;
    transition: stroke-dashoffset 0.52s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .ring-num {
    position: relative;
    font-size: 19px;
    font-weight: 600;
    color: #1f2937;
    letter-spacing: -0.02em;
  }
  .ring-num em {
    font-style: normal;
    font-size: 10px;
    color: #9ca3af;
    margin-left: 1px;
  }
  .columns {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 300px;
    gap: 14px;
  }
  .timeline,
  .skills {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 16px 18px;
  }
  .block-title {
    margin: 0 0 12px;
    font-size: 13.5px;
    color: #1f2937;
  }
  .phase-name {
    font-size: 13.5px;
    font-weight: 600;
    color: #1f2937;
    margin-right: 8px;
  }
  .phase-desc {
    margin: 6px 0 8px;
    font-size: 12px;
    line-height: 1.7;
    color: #6b7280;
  }
  .steps {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .step {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 0;
    cursor: pointer;
    font-size: 12.5px;
    color: #374151;
  }
  .box {
    width: 15px;
    height: 15px;
    flex-shrink: 0;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-size: 10px;
    line-height: 13px;
    text-align: center;
    color: #fff;
  }
  .step.done .box {
    background: #2f6bff;
    border-color: #2f6bff;
  }
  .step.done .step-text {
    color: #9ca3af;
    text-decoration: line-through;
  }
  .cert {
    font-size: 10.5px;
    color: #a86a00;
    background: #fff7e6;
    border-radius: 4px;
    padding: 0 6px;
  }
  .skill-card {
    margin-bottom: 14px;
  }
  .skill-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    margin-bottom: 6px;
  }
  .skill-name {
    font-size: 12.5px;
    color: #374151;
  }
  .skill-score {
    font-size: 12px;
    color: #2f6bff;
  }
  .skill-tip {
    margin: 6px 0 0;
    font-size: 11.5px;
    line-height: 1.7;
    color: #9ca3af;
  }
  .skill-note {
    margin-top: 4px;
    padding-top: 10px;
    border-top: 1px dashed #eef0f3;
    font-size: 11px;
    line-height: 1.7;
    color: #b9bdc4;
  }
  .actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 14px;
  }
</style>
