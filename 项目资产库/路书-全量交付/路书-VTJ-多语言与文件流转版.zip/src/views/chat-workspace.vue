<template>
  <div :class="['chat-page', { 'hide-sessions': !showSessions, 'hide-refs': !showRefs }]">
    <div class="session-col">
      <SessionList :sessions="sessions"></SessionList>
    </div>
    <div class="chat-main">
      <ChatPanel
        :messages="messages"
        :streaming="streaming"
        :tool-step="toolStep"
        :show-sessions="showSessions"
        :show-refs="showRefs"
        @send="handleSend"
        @stop="handleStop"
        @toggle-sessions="showSessions = !showSessions"
        @toggle-refs="showRefs = !showRefs"></ChatPanel>
    </div>
    <aside class="ref-col">
      <ReferencePanel
        :references="references"
        :profile="profile"
        @copy="handleCopy"></ReferencePanel>
    </aside>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import SessionList from '@/components/SessionList.vue';
  import ChatPanel from '@/components/ChatPanel.vue';
  import ReferencePanel from '@/components/ReferencePanel.vue';
  import { ui, notify } from '@/store/ui';
  import { addOutputs } from '@/store/files';

  const messages = ref([]);
  const streaming = ref(false);
  // 检索链走到第几段：0 理解问题 / 1 检索 / 2 挂载来源 / 3 终审；-1 空闲
  const toolStep = ref(-1);
  const references = ref([]);
  // 三档视图：三栏 / 双栏 / 单栏，列宽靠 width 过渡滑出滑入
  // 状态放全局 —— 顶栏的 Ctrl+J / Ctrl+\ 和命令面板改的是同一份
  const showSessions = computed({
    get: () => ui.showSessions,
    set: (v) => (ui.showSessions = v)
  });
  const showRefs = computed({
    get: () => ui.showRefs,
    set: (v) => (ui.showRefs = v)
  });

  const handleCopy = (item) => {
    const text = `《${item.title}》 ${item.group} · ${item.date}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
      }
    } catch (e) {
      // 剪贴板被浏览器拦了不影响提示，这里只是演示
    }
    notify('已复制：' + item.title);
  };

  const sessions = ref([
    { id: 's1', title: '专插本要什么条件', status: 'active', statusText: '进行中', updatedAt: '10:24' },
    { id: 's2', title: '计算机应用技术能去哪些岗位', status: 'done', statusText: '已完成', updatedAt: '昨天' },
    { id: 's3', title: '大一该先准备什么', status: 'done', statusText: '已完成', updatedAt: '周二' },
    { id: 's4', title: '简历没项目经历怎么写', status: 'pending', statusText: '待处理', updatedAt: '周一' }
  ]);

  const profile = reactive({
    name: '李同学',
    major: '计算机应用技术',
    grade: '大一',
    goal: '还没定：专插本 / 就业',
    dims: []
  });

  const FAQ = [
    {
      id: 'zhuanchaben',
      keys: ['专插本', '升本', '插本', '升学'],
      en: 'For a final-year vocational student: graduate on time, no disciplinary record; the exam is usually two general papers plus one subject paper, set by the provincial exam authority each year. Three things you can start now: keep maths and English going, hold your GPA in the top 40% of your major, and from the second half of year two practise against the target college’s subjects. Registration dates, colleges and quotas are not in our knowledge base, so I do not give them.',
      content:
        '按 A 组《高职学生升学与就业路径选择指南》：专插本面向应届高职毕业生，一般要求能如期毕业、在校期间无违纪记录；考试科目通常是 2 门公共课加 1 门专业基础课，具体科目由当年省考试院通知确定。\n\n你现在大一、计算机应用技术，能提前动的有三件：高数和英语的底子别断；专业课绩点稳在专业前 40%；大二下开始按目标院校的考试科目刷题。\n\n今年的报名时间、招生院校和计划数，知识库里没有收录，我不给具体日期 —— 这块要看你所在省考试院当年发布的招生工作通知。',
      sources: [
        { title: '《高职学生升学与就业路径选择指南》', group: 'A 组 · 专业与岗位', date: '2025-03-10' },
        { title: '《专插本考试科目说明（校内整理）》', group: 'B 组 · 证书与考试', date: '2025-02-28' }
      ],
      footer:
        '以上政策信息来自《高职学生升学与就业路径选择指南》，生效日期 2025-03-10，请以官方最新通知为准。'
    },
    {
      id: 'jobs',
      keys: ['哪些岗位', '什么岗位', '就业', '找工作', '对口', '能去'],
      en: 'Four directions rank highest for this major: junior Java backend, web frontend, software testing and IT operations. The common bar is shipping one small project on your own, using Git, and being able to read an error message. Salary ranges are only given for software testing (9 samples) and IT operations (6 samples); the other two have fewer than five samples, so no range is given.',
      content:
        '按 C 组「计算机应用技术 · 对口岗位」，匹配度参考值靠前的有 4 个方向：Java 后端开发（初级）、Web 前端开发、软件测试、IT 运维。\n\n这四个岗位的共同门槛是：能独立跑起来一个小项目、会用 Git、看得懂报错。学历要求基本是大专起，更看项目。\n\n起薪这块，只有软件测试和 IT 运维有本校近两届的回收样本（9 条和 6 条）；Java 后端和 Web 前端样本不足 5 条，我不给区间 —— 样本太少的数字看着像真的，其实是编的。',
      sources: [
        { title: '《计算机应用技术专业对口岗位表》', group: 'C 组 · 岗位与能力', date: '2025-03-08' },
        { title: '《2024 届毕业生就业质量回收样本》', group: 'D 组 · 行业与就业数据', date: '2025-01-15' }
      ],
      footer: ''
    },
    {
      id: 'year1',
      keys: ['先准备', '大一', '该学什么', '从哪开始'],
      en: 'Two things only in year one: get one language to the point of writing create-read-update-delete, and keep your GPA up. Pick Java or frontend — not both. The goal is a small database-backed system you can explain line by line.',
      content:
        '大一只用干两件事，别贪多。\n\n第一件，把一门语言学通到能写增删改查。计算机应用技术走 Java 或前端都行，选一个，别同时开两个。目标很具体：能自己写出一个带数据库的小系统，能讲清哪一行在干什么。\n\n第二件，绩点别掉。专插本看绩点，就业看能不能过简历初筛，两头都用得上。\n\nC 组里列了大一这一年的三个动作，你可以直接对着「路线图」勾：语言基础课、每周固定上机、一个能跑的小练习。',
      sources: [
        { title: '《计算机应用技术专业对口岗位表》', group: 'C 组 · 岗位与能力', date: '2025-03-08' },
        { title: '《高职学生成长路线图模板》', group: 'A 组 · 专业与岗位', date: '2025-03-05' }
      ],
      footer: ''
    },
    {
      id: 'resume',
      keys: ['简历', '实习', '面试', '项目经历'],
      en: 'With no internship, fill the project section from course projects, competitions and self-built work. One action per sentence: “built a library admin page in Vue with full CRUD, code on GitHub” beats “familiar with frontend”. Prepare three answers: why this direction, a bug you hit and how you solved it, what you are learning now.',
      content:
        '按 E 组《求职简历撰写与面试表达》：没有实习经历时，项目区用「课程项目 + 竞赛 + 自己练的」三块填，不要空着。\n\n写法上一句一个动作。写「用 Vue 做了个图书管理页面，能增删改查，代码在 GitHub」比写「熟悉前端」有用得多 —— 前者能被追问，后者只能被跳过。\n\n面试最常问的三个问题也在 E 组里：为什么选这个方向、遇到过什么坑怎么解决的、最近在学什么。这三个各准备两分钟，比背八股有效。',
      sources: [{ title: '《求职简历撰写与面试表达》', group: 'E 组 · 求职技能', date: '2025-03-06' }],
      footer: ''
    }
  ];

  /**
   * 产物模板：内容全部从上面几段回答里拆出来，不新增任何事实。
   * 所以「考编」那行照实写「现有资料未覆盖」，不给条件也不给目录。
   */
  const KIT = {
    zhuanchaben: [
      {
        name: '专插本准备清单.md',
        ext: 'md',
        items: 12,
        content: `# 专插本准备清单（大一 → 大二下）

> 依据：《高职学生升学与就业路径选择指南》2025-03-10；《专插本考试科目说明（校内整理）》2025-02-28
> 未覆盖：今年报名时间、招生院校、计划数 —— 以省考试院当年通知为准。

## 现在能动的三件
- [ ] 高数、英语不断线：每周各 3 次，每次 40 分钟
- [ ] 专业课绩点稳在专业前 40%
- [ ] 大二下开始按目标院校的考试科目刷题

## 报名条件（指南口径）
- 应届高职毕业生
- 能如期毕业
- 在校期间无违纪记录

## 考试科目
- 2 门公共课 + 1 门专业基础课
- 具体科目由当年省考试院通知确定
`
      },
      {
        name: '升学就业路径对照.csv',
        ext: 'csv',
        items: 4,
        content: `路径,适合谁,关键门槛,资料覆盖情况,下一步
专插本,想继续读本科的应届高职毕业生,如期毕业 + 无违纪 + 2 门公共课 1 门专业基础课,指南已覆盖；报名时间与院校计划未收录,按目标院校科目刷题
直接就业,想尽快上岗的,能独立跑起一个小项目 + 会用 Git + 看得懂报错,岗位表已覆盖；两个方向薪资样本不足,先做一个能讲清的项目
考编（事业单位）,想进体制内的,现有资料未覆盖,知识库未收录报名条件与岗位目录,问辅导员或招生就业处
`
      }
    ],
    jobs: [
      {
        name: '计算机应用技术-对口岗位.csv',
        ext: 'csv',
        items: 5,
        content: `方向,匹配度参考,学历门槛,共同要求,薪资口径
Java 后端开发（初级）,靠前,大专起,能独立跑起小项目 / 会用 Git / 看得懂报错,样本不足 5 条，不给区间
Web 前端开发,靠前,大专起,同上,样本不足 5 条，不给区间
软件测试,靠前,大专起,同上,本校近两届 9 条回收样本
IT 运维,靠前,大专起,同上,本校近两届 6 条回收样本
`
      },
      {
        name: '岗位对照说明.md',
        ext: 'md',
        items: 14,
        content: `# 岗位对照说明

来源：《计算机应用技术专业对口岗位表》2025-03-08（C 组）；《2024 届毕业生就业质量回收样本》2025-01-15（D 组）。

## 为什么只有两行写了薪资口径
软件测试有 9 条样本、IT 运维有 6 条样本；Java 后端与 Web 前端都不足 5 条。
样本不到 5 条时给区间，看着像真的，其实是编的 —— 所以这两行只写「不给区间」。

## 四个方向的共同门槛
- 能独立跑起来一个小项目
- 会用 Git
- 看得懂报错

学历要求基本是大专起，更看项目。
`
      }
    ],
    year1: [
      {
        name: '大一行动清单.md',
        ext: 'md',
        items: 10,
        content: `# 大一行动清单

> 来源：《高职学生成长路线图模板》2025-03-05（A 组）；《计算机应用技术专业对口岗位表》2025-03-08（C 组）

## 只做两件
- [ ] 把一门语言学通到能写增删改查（Java 或前端，选一个）
- [ ] 绩点别掉

## C 组里的三个动作
- [ ] 语言基础课
- [ ] 每周固定上机
- [ ] 一个能跑的小练习

## 验收标准
能自己写出一个带数据库的小系统，能讲清哪一行在干什么。
`
      }
    ],
    resume: [
      {
        name: '简历检查表.md',
        ext: 'md',
        items: 11,
        content: `# 简历检查表

> 来源：《求职简历撰写与面试表达》2025-03-06（E 组）

## 项目区（没有实习经历时）
- [ ] 课程项目
- [ ] 竞赛
- [ ] 自己练的

## 写法
- [ ] 一句一个动作
- [ ] 能被追问（做过什么、怎么做的、代码在哪）
- [ ] 不写「熟悉 XX」这类只能被跳过的句子

## 面试三问，各准备两分钟
- [ ] 为什么选这个方向
- [ ] 遇到过什么坑，怎么解决的
- [ ] 最近在学什么
`
      }
    ]
  };

  const nowHM = () => {
    const d = new Date();
    const pad = (n) => (n < 10 ? '0' + n : '' + n);
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  };

  const byteSize = (text) => {
    try {
      return new Blob([text]).size;
    } catch (e) {
      return String(text).length * 3;
    }
  };

  const MISS_EN =
    'Not covered by the current materials. Groups A–E hold nothing on this, and I will not answer from impression. Try naming a specific major, job or policy — or look it up under “Knowledge base”. For registration or paperwork, ask your counsellor or the careers office.';

  const MISS_TEXT =
    '这个问题现有资料未覆盖。\n\nA–E 五组知识库里没有收录相关内容，我不能凭印象给你答案。\n\n建议换一种问法：问具体专业、具体岗位或具体政策名；也可以去左侧「知识库」按分组自己找一遍。如果是要报名、交材料这类必须准确的事，直接问辅导员或学校招生就业处。';

  let timers = [];
  const clearTimers = () => {
    timers.forEach((t) => clearTimeout(t));
    timers = [];
  };

  /**
   * 打字机：不是「假装在生成」，是让长段落有阅读节奏。
   * 每帧吐 3 个字 —— 比逐字快，看起来像在写而不是在卡。
   * 全文存在 _full 里，中途点「停止」可以直接补全，不留半句话。
   */
  const typeInto = (msg) => {
    msg._full = msg.content;
    msg.content = '';
    msg.typing = true;
    const full = msg._full;
    let i = 0;
    const step = () => {
      i += 3;
      msg.content = full.slice(0, i);
      if (i < full.length) {
        timers.push(setTimeout(step, 16));
      } else {
        msg.content = full;
        msg.typing = false;
      }
    };
    step();
  };

  /** 产物生成：先占位再涨进度，涨到 100% 才算可下载 —— 不给一个点了没反应的空按钮 */
  const growArtifact = (art) => {
    art.progress = Math.min(100, art.progress + 11);
    if (art.progress < 100) {
      timers.push(setTimeout(() => growArtifact(art), 110));
    } else {
      art.progress = 100;
      art.status = 'done';
    }
  };

  const dropArtifacts = (msg, key) => {
    const list = KIT[key];
    if (!list || !list.length) return;
    timers.push(
      setTimeout(() => {
        msg.artifacts = list.map((a, i) => ({
          id: msg.id + '-a' + i,
          name: a.name,
          ext: a.ext,
          items: a.items,
          content: a.content,
          size: byteSize(a.content),
          status: 'generating',
          progress: 0,
          time: nowHM()
        }));
        msg.artifacts.forEach((art) => growArtifact(art));
        addOutputs(msg.artifacts);
      }, 480)
    );
  };

  const handleSend = (text, files) => {
    const q = String(text || '').trim();
    if (!q) return;
    clearTimers();
    const attached = Array.isArray(files) ? files : [];
    messages.value.push({
      id: `u-${Date.now()}`,
      role: 'user',
      content: q,
      attachments: attached
    });
    streaming.value = true;
    toolStep.value = 0;
    // 四段依次推进，节奏 380ms：太快看不清，太慢像卡住
    [1, 2, 3].forEach((step, i) => {
      timers.push(
        setTimeout(() => {
          if (streaming.value) toolStep.value = step;
        }, 380 * (i + 1))
      );
    });
    // 带了附件时，检索段多停 300ms —— 读文件要时间，装成瞬间读完反而假
    const settle = attached.length ? 1820 : 1520;
    timers.push(
      setTimeout(() => {
        const hit = FAQ.find((item) => item.keys.some((k) => q.indexOf(k) > -1));
        streaming.value = false;
        toolStep.value = -1;
        if (!hit) {
          const msg = {
            id: `a-${Date.now()}`,
            role: 'assistant',
            miss: true,
            content: MISS_TEXT,
            enSummary: MISS_EN,
            sources: []
          };
          messages.value.push(msg);
          typeInto(messages.value[messages.value.length - 1]);
          references.value = [];
          return;
        }
        const msg = {
          id: `a-${Date.now()}`,
          role: 'assistant',
          content: hit.content,
          enSummary: hit.en,
          sources: hit.sources,
          footer: hit.footer,
          attachmentsEcho: attached,
          // 命中的是哪几组：气泡上方那行小字可以展开看
          hitGroups: hit.sources.map((s) => s.group)
        };
        messages.value.push(msg);
        // push 之后要用数组里那个代理对象：直接改 push 前的原始对象，Vue 收不到通知
        const live = messages.value[messages.value.length - 1];
        typeInto(live);
        dropArtifacts(live, hit.id);
        references.value = hit.sources.map((s, i) => ({
          id: `r${i}`,
          title: s.title,
          group: s.group,
          date: s.date,
          excerpt: `摘自${s.group}，${s.date} 入库，可去「知识库」看原文。`
        }));
        // 附件作为补充材料挂在来源栏最后，标明「你提供的，不算出处」
        if (attached.length) {
          references.value = references.value.concat(
            attached.map((f, i) => ({
              id: `att${i}`,
              title: f.name,
              group: '你的附件',
              date: nowHM().slice(0, 5),
              excerpt: '仅作补充材料，不作为回答出处 —— 出处仍然只认 A–E 五组。',
              mine: true
            }))
          );
        }
      }, settle)
    );
  };

  const handleStop = () => {
    clearTimers();
    streaming.value = false;
    toolStep.value = -1;
    // 停在半句话上最难受，直接补全
    messages.value.forEach((m) => {
      if (m.typing && m._full) {
        m.content = m._full;
        m.typing = false;
      }
      // 产物也别卡在 60% —— 要么给完整的，要么不给
      (m.artifacts || []).forEach((a) => {
        if (a.status === 'generating') {
          a.progress = 100;
          a.status = 'done';
        }
      });
    });
  };
</script>

<style lang="css" scoped>
  .chat-page {
    position: relative;
    flex: 1;
    min-width: 0;
    display: flex;
    gap: 12px;
    padding: 12px;
    box-sizing: border-box;
    height: 100%;
    overflow: hidden;
  }
  /* 列宽走同一条曲线：收起时 width→0 + opacity→0，用负 margin 把那 12px 的 gap 也吃掉 */
  .session-col {
    width: 216px;
    flex-shrink: 0;
    min-height: 0;
    overflow: hidden;
    transition: width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.16s ease,
      margin 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .hide-sessions .session-col {
    width: 0;
    opacity: 0;
    margin-right: -12px;
    pointer-events: none;
  }
  .chat-main {
    flex: 1;
    min-width: 0;
    min-height: 0;
  }
  .ref-col {
    width: 332px;
    flex-shrink: 0;
    min-height: 0;
    overflow: hidden;
    transition: width 0.24s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.16s ease,
      margin 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  }
  .hide-refs .ref-col {
    width: 0;
    opacity: 0;
    margin-left: -12px;
    pointer-events: none;
  }

  @media (max-width: 1320px) {
    .session-col {
      display: none;
    }
    .ref-col {
      width: 288px;
    }
  }
  @media (max-width: 1100px) {
    .chat-page {
      flex-direction: column;
      height: auto;
    }
    .ref-col {
      width: 100%;
    }
    .hide-refs .ref-col {
      margin-left: 0;
    }
  }
</style>
