<template>
  <div class="self-page">
    <div class="self-header">
      <div class="title-block">
        <h2>认识自己</h2>
        <p class="self-desc">
          12 道题，六类。1 = 完全不像我，5 = 很像我 / 很愿意。结果只把偏好摆出来看，不做判定、不给类型名。
        </p>
      </div>
      <div class="progress-chip">{{ answered }} / 12 已答</div>
    </div>

    <div v-if="!showResult" class="self-form">
      <div v-for="g in dimGroups" :key="g.name" class="dim-block">
        <div class="dim-head">
          <span class="dim-name">{{ g.name }}</span>
          <span class="dim-count">{{ g.items.length }} 题</span>
        </div>
        <div class="q-list">
          <div v-for="(q, i) in g.items" :key="q.idx" class="q-row">
            <span class="q-idx">{{ q.idx + 1 }}</span>
            <span class="q-text">{{ q.text }}</span>
            <ElRate v-model="q.score" class="q-rate" :max="5" size="large" />
          </div>
        </div>
      </div>

      <div class="self-actions">
        <ElButton @click="handleReset">重新作答</ElButton>
        <ElButton type="primary" @click="handleSubmit">看结果</ElButton>
      </div>
    </div>

    <div v-else class="self-result">
      <div class="result-card">
        <span class="result-title">六类相对分</span>
        <span class="result-sub">相对分只表示你在这六类里更偏向哪边，不表示能力强弱。</span>

        <div v-for="d in dimScores" :key="d.name" class="score-row">
          <span class="score-name">{{ d.name }}</span>
          <div class="score-track">
            <div class="score-fill" :style="{ width: d.rel + '%' }"></div>
          </div>
          <span class="score-val">{{ d.rel }}%</span>
        </div>

        <p class="result-note">
          这只是把你刚才的选择摆出来看，不是测评结论，也不代表你适合或不适合什么。
        </p>

        <div class="result-actions">
          <ElButton type="primary" @click="handleToCareer">拿这份结果去看岗位</ElButton>
          <ElButton @click="handleReset">重新作答</ElButton>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, reactive, computed } from 'vue';
  import { useRouter } from 'vue-router';
  import { ElRate, ElButton, ElMessage } from 'element-plus';

  const router = useRouter();
  const showResult = ref(false);

  const DIMS = ['动手实践', '逻辑分析', '创意表达', '沟通协作', '组织统筹', '细节规范'];
  const RAW = [
    ['动手实践', '拆装、调试、把坏掉的东西弄好，这类事我愿意花时间'],
    ['动手实践', '比起先把文档看完，我更愿意直接上手试'],
    ['逻辑分析', '一个报错我能顺着往下查，非搞明白为什么不可'],
    ['逻辑分析', '数据、表格、规律这类需要坐得住的事，我不排斥'],
    ['创意表达', '做海报、短视频、页面这种要「好看」的东西，我有兴趣'],
    ['创意表达', '我常能想出让别人觉得新鲜的点子'],
    ['沟通协作', '我愿意主动去问、去把话说清楚'],
    ['沟通协作', '小组作业里，我常是那个把大家串起来的人'],
    ['组织统筹', '排计划、盯进度、把事情推着往前走，我愿意做'],
    ['组织统筹', '给我一个目标，我能自己拆成几步'],
    ['细节规范', '按规范一步步来、不漏步骤，我做得住'],
    ['细节规范', '错别字、对不齐这种小问题，我一眼能看出来']
  ];

  const questions = reactive(
    RAW.map(([dim, text], idx) => ({ idx, dim, text, score: 0 }))
  );

  const answered = computed(() => questions.filter((q) => q.score > 0).length);

  const dimGroups = computed(() =>
    DIMS.map((name) => ({ name, items: questions.filter((q) => q.dim === name) }))
  );

  const dimScores = computed(() => {
    const totals = dimGroups.value.map((g) => ({
      name: g.name,
      score: g.items.reduce((a, q) => a + (q.score || 0), 0)
    }));
    const max = Math.max(...totals.map((t) => t.score));
    return totals.map((t) => ({
      name: t.name,
      score: t.score,
      rel: max > 0 ? Math.round((t.score / max) * 100) : 0
    }));
  });

  const handleSubmit = () => {
    if (answered.value < 12) {
      ElMessage.warning(`还剩 ${12 - answered.value} 题没答`);
      return;
    }
    showResult.value = true;
  };
  const handleReset = () => {
    questions.forEach((q) => {
      q.score = 0;
    });
    showResult.value = false;
  };
  const handleToCareer = () => {
    router.push('/page/career-library');
  };
</script>

<style lang="css" scoped>
  .self-page {
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .self-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .self-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
    max-width: 700px;
  }
  .progress-chip {
    flex-shrink: 0;
    font-size: 12px;
    color: #2f6bff;
    background: #eef3fe;
    border-radius: 14px;
    padding: 4px 12px;
  }
  .self-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
    max-width: 880px;
  }
  .dim-block {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 14px 18px;
  }
  .dim-head {
    display: flex;
    align-items: baseline;
    gap: 8px;
    margin-bottom: 4px;
  }
  .dim-name {
    font-size: 13.5px;
    font-weight: 600;
    color: #1f2937;
  }
  .dim-count {
    font-size: 11px;
    color: #9ca3af;
  }
  .q-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 7px 0;
  }
  .q-idx {
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    border-radius: 50%;
    background: #f3f4f6;
    color: #6b7280;
    font-size: 11px;
  }
  .q-text {
    flex: 1;
    min-width: 0;
    font-size: 13px;
    color: #374151;
    line-height: 1.7;
  }
  .q-rate {
    flex-shrink: 0;
  }
  .self-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 4px 0 20px;
  }
  .self-result {
    max-width: 720px;
  }
  .result-card {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 18px 20px;
  }
  .result-title {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
  }
  .result-sub {
    display: block;
    margin-top: 4px;
    font-size: 11.5px;
    color: #9ca3af;
  }
  .score-row {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 12px;
  }
  .score-name {
    width: 76px;
    flex-shrink: 0;
    font-size: 12.5px;
    color: #4b5563;
  }
  .score-track {
    flex: 1;
    height: 8px;
    background: #f3f4f6;
    border-radius: 4px;
    overflow: hidden;
  }
  .score-fill {
    height: 100%;
    background: #2f6bff;
    border-radius: 4px;
  }
  .score-val {
    width: 42px;
    text-align: right;
    font-size: 12px;
    color: #6b7280;
  }
  .result-note {
    margin: 16px 0 0;
    padding: 10px 12px;
    background: #f7f8fa;
    border-radius: 6px;
    font-size: 12px;
    line-height: 1.8;
    color: #6b7280;
  }
  .result-actions {
    display: flex;
    gap: 10px;
    margin-top: 14px;
  }
</style>
