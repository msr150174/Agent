<template>
  <div class="materials-page">
    <div class="mp-head">
      <div class="mph-left">
        <h2 class="mp-title">{{ t('m.title') }}</h2>
        <p class="mp-lede">{{ t('m.lede') }}</p>
      </div>
      <div class="mph-acts">
        <button class="mp-go" @click="goChat">
          <span>＋</span>{{ t('m.goChat') }}
        </button>
        <ExportMenu @export="doExport"></ExportMenu>
      </div>
    </div>

    <div class="mp-stats">
      <div v-for="(s, i) in statCards" :key="s.label" class="stat" :style="{ '--i': i }">
        <span class="stat-label">{{ s.label }}</span>
        <span class="stat-value num">{{ s.value }}<em v-if="s.unit">{{ s.unit }}</em></span>
        <span class="stat-foot">{{ s.foot }}</span>
      </div>
    </div>

    <div class="mp-cols">
      <!-- 我上传的 -->
      <section class="panel">
        <header class="panel-head">
          <span class="ph-title">{{ t('m.materials') }}</span>
          <span class="ph-count">{{ files.materials.length }}</span>
          <span class="ph-hint">{{ t('u.free') }}</span>
        </header>

        <div v-if="!files.materials.length" class="empty">
          <span class="empty-ico">⇧</span>
          <p class="empty-title">{{ t('m.materialsEmpty') }}</p>
          <p class="empty-hint">{{ t('u.dropHint') }}</p>
          <button class="empty-btn" @click="goChat">{{ t('m.goChat') }}</button>
        </div>

        <TransitionGroup v-else name="row" tag="div" class="rows">
          <div v-for="m in files.materials" :key="m.id" class="row">
            <span :class="['row-ico', m.kind]">{{ String(m.ext || '').toUpperCase().slice(0, 3) }}</span>
            <div class="row-main">
              <div class="row-name" :title="m.name">{{ m.name }}</div>
              <div class="row-meta">
                <span>{{ humanSize(m.size) }}</span>
                <span class="dot">·</span>
                <span>{{ m.from === '对话上传' ? t('m.fromChat') : m.from }}</span>
                <span class="dot">·</span>
                <span>{{ shortTime(m.uploadedAt) }}</span>
              </div>
            </div>
            <span :class="['badge', m.status]">
              <template v-if="m.status === 'done'">{{ t('u.done', { n: m.chunks }) }}</template>
              <template v-else-if="m.status === 'error'">{{ m.error || t('u.failed') }}</template>
              <template v-else>{{ t('u.parsing') }} {{ m.progress }}%</template>
            </span>
            <button class="row-x" :title="t('c.remove')" @click="removeMaterial(m.id)">×</button>
          </div>
        </TransitionGroup>
      </section>

      <!-- 我产出的 -->
      <section class="panel">
        <header class="panel-head">
          <span class="ph-title">{{ t('m.outputs') }}</span>
          <span class="ph-count">{{ files.outputs.length }}</span>
          <span class="ph-hint">{{ t('a.demoLink') }}</span>
        </header>

        <div v-if="!files.outputs.length" class="empty">
          <span class="empty-ico">⇩</span>
          <p class="empty-title">{{ t('m.outputsEmpty') }}</p>
          <p class="empty-hint">{{ t('a.emptyHint') }}</p>
          <button class="empty-btn" @click="goChat">{{ t('nav.chat') }}</button>
        </div>

        <div v-else class="out-wrap">
          <ArtifactList :items="files.outputs"></ArtifactList>
        </div>
      </section>
    </div>

    <p class="mp-foot">{{ t('m.foot') }}</p>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { computed } from 'vue';
  import { useRouter } from 'vue-router';
  import ExportMenu from '@/components/ExportMenu.vue';
  import ArtifactList from '@/components/ArtifactList.vue';
  import { useI18n } from '@/i18n';
  import { notify } from '@/store/ui';
  import { files, fileStats, removeMaterial } from '@/store/files';
  import { humanSize, downloadCsv, downloadMarkdown, toTsv, copyText } from '@/utils/download';

  const router = useRouter();
  const { t, isEn } = useI18n();
  const stats = fileStats;

  const goChat = () => router.push('/page/chat-workspace');

  const statCards = computed(() => {
    const u = isEn.value ? '' : ' 份';
    return [
      {
        label: t('m.statFiles'),
        value: stats.value.count,
        unit: u,
        foot: stats.value.failed
          ? isEn.value
            ? stats.value.failed + ' could not be read'
            : stats.value.failed + ' 份没读成'
          : isEn.value
            ? 'Drop, paste or pick'
            : '三种方式都能加'
      },
      {
        label: t('m.statParsed'),
        value: stats.value.parsed,
        unit: u,
        foot: isEn.value ? stats.value.chunks + ' chunks' : '共 ' + stats.value.chunks + ' 段'
      },
      {
        label: t('m.statOutputs'),
        value: stats.value.outputs,
        unit: u,
        foot: isEn.value ? 'checklists / tables / notes' : '清单 / 表格 / 说明'
      },
      {
        label: t('m.statSize'),
        value: humanSize(stats.value.bytes),
        unit: '',
        foot: isEn.value ? 'Local only — not uploaded' : '都在本地，没上传服务器'
      }
    ];
  });

  const shortTime = (iso) => {
    if (!iso) return '—';
    const d = new Date(iso);
    const p = (n) => (n < 10 ? '0' + n : '' + n);
    return p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };

  const rowsForExport = () => {
    const head = ['类型', '文件名', '格式', '大小', '状态', '段数/行数', '时间'];
    const mats = files.materials.map((m) => [
      '材料',
      m.name,
      (m.ext || '').toUpperCase(),
      humanSize(m.size),
      m.status === 'done' ? '已解析' : m.status === 'error' ? m.error || '失败' : '解析中',
      m.chunks || 0,
      shortTime(m.uploadedAt)
    ]);
    const outs = files.outputs.map((o) => [
      '产出',
      o.name,
      (o.ext || '').toUpperCase(),
      humanSize(o.size),
      o.status === 'done' ? '可下载' : '生成中',
      o.items || 0,
      o.time || ''
    ]);
    return [head].concat(mats, outs);
  };

  const doExport = async (type) => {
    if (!files.materials.length && !files.outputs.length) {
      notify('还没有可导出的内容');
      return;
    }
    if (type === 'csv') {
      const name = downloadCsv('材料与产出清单', rowsForExport());
      notify(t('e.done', { name }));
    } else if (type === 'md') {
      const rows = rowsForExport();
      const md =
        '# 材料与产出清单\n\n' +
        rows
          .slice(1)
          .map((r) => '- **' + r[1] + '** · ' + r[0] + ' · ' + r[2] + ' · ' + r[3] + ' · ' + r[4])
          .join('\n') +
        '\n';
      const name = downloadMarkdown('材料与产出清单', md);
      notify(t('e.done', { name }));
    } else {
      const ok = await copyText(toTsv(rowsForExport()));
      notify(ok ? t('e.copied') : '复制失败');
    }
  };
</script>

<style lang="css" scoped>
  .materials-page {
    flex: 1;
    min-width: 0;
    overflow: auto;
    padding: 18px 22px 26px;
    box-sizing: border-box;
  }
  .mp-head {
    display: flex;
    align-items: flex-start;
    gap: 16px;
    margin-bottom: 14px;
  }
  .mph-left {
    flex: 1;
    min-width: 0;
  }
  .mp-title {
    margin: 0;
    font-size: 19px;
    font-weight: 600;
    color: #1b2431;
    letter-spacing: 0.01em;
  }
  .mp-lede {
    margin: 5px 0 0;
    max-width: 660px;
    font-size: 12.5px;
    line-height: 1.7;
    color: #7d8797;
  }
  .mph-acts {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }
  .mp-go {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    height: 28px;
    padding: 0 11px;
    border: 1px solid #cfdcfb;
    border-radius: 7px;
    background: #f4f8ff;
    color: #2f6bff;
    font-size: 12px;
    cursor: pointer;
    transition:
      background 0.16s var(--m-ease),
      border-color 0.16s var(--m-ease);
  }
  .mp-go:hover {
    background: #eaf1ff;
    border-color: #b9cdfd;
  }
  .mp-go span {
    font-size: 13px;
    line-height: 1;
  }
  .mp-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
    margin-bottom: 16px;
  }
  .stat {
    padding: 11px 13px;
    border: 1px solid #eef1f6;
    border-radius: 10px;
    background: #fff;
    animation: statIn 0.32s var(--m-ease) both;
    animation-delay: calc(var(--i) * 55ms);
  }
  .stat-label {
    display: block;
    font-size: 11px;
    color: #939cab;
  }
  .stat-value {
    display: block;
    margin: 3px 0 2px;
    font-size: 24px;
    font-weight: 600;
    color: #1b2431;
    line-height: 1.2;
  }
  .stat-value em {
    margin-left: 2px;
    font-style: normal;
    font-size: 12px;
    font-weight: 500;
    color: #9aa3b2;
  }
  .stat-foot {
    font-size: 10.5px;
    color: #b3bac6;
  }
  .mp-cols {
    display: grid;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr);
    gap: 12px;
    align-items: start;
  }
  .panel {
    border: 1px solid #eef1f6;
    border-radius: 12px;
    background: #fff;
    overflow: hidden;
  }
  .panel-head {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 10px 13px;
    border-bottom: 1px solid #f3f5f9;
  }
  .ph-title {
    font-size: 13px;
    font-weight: 600;
    color: #26303d;
  }
  .ph-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 17px;
    height: 16px;
    padding: 0 5px;
    border-radius: 999px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .ph-hint {
    margin-left: auto;
    font-size: 10px;
    color: #b6bec9;
  }
  .rows {
    display: flex;
    flex-direction: column;
  }
  .row {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 9px 13px;
    border-bottom: 1px solid #f7f8fb;
    transition: background 0.14s linear;
  }
  .row:last-child {
    border-bottom: none;
  }
  .row:hover {
    background: #fbfcfe;
  }
  .row-ico {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 6px;
    background: #eef3ff;
    color: #2f6bff;
    font-size: 8.5px;
    font-weight: 700;
  }
  .row-ico.sheet {
    background: #eaf7ef;
    color: #2c8a4b;
  }
  .row-ico.image {
    background: #fff4ea;
    color: #c07a20;
  }
  .row-main {
    flex: 1;
    min-width: 0;
  }
  .row-name {
    font-size: 12.5px;
    color: #1f2733;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .row-meta {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 2px;
    font-size: 10.5px;
    color: #9aa3b2;
    font-variant-numeric: tabular-nums;
  }
  .row-meta .dot {
    color: #d0d6e0;
  }
  .badge {
    flex-shrink: 0;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .badge.done {
    background: #f0faf3;
    color: #2c8a4b;
  }
  .badge.error {
    background: #fff5f5;
    color: #d64545;
  }
  .badge.parsing,
  .badge.queued {
    background: #f2f6ff;
    color: #2f6bff;
  }
  .row-x {
    flex-shrink: 0;
    border: none;
    background: transparent;
    color: #c3cad5;
    font-size: 14px;
    line-height: 1;
    cursor: pointer;
  }
  .row-x:hover {
    color: #d64545;
  }
  .out-wrap {
    padding: 10px 13px 12px;
  }
  .empty {
    padding: 34px 18px 32px;
    text-align: center;
  }
  .empty-ico {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    margin-bottom: 10px;
    border: 1px dashed #d7dfec;
    border-radius: 50%;
    color: #b8c3d4;
    font-size: 16px;
  }
  .empty-title {
    margin: 0 0 4px;
    font-size: 12.5px;
    color: #6b7585;
  }
  .empty-hint {
    margin: 0 0 12px;
    font-size: 11px;
    color: #a8b1bf;
  }
  .empty-btn {
    height: 27px;
    padding: 0 12px;
    border: 1px solid #dbe4f5;
    border-radius: 7px;
    background: #fff;
    color: #2f6bff;
    font-size: 11.5px;
    cursor: pointer;
  }
  .empty-btn:hover {
    background: #f5f9ff;
    border-color: #c3d3fb;
  }
  .mp-foot {
    margin: 14px 2px 0;
    font-size: 11px;
    line-height: 1.7;
    color: #a8b1bf;
  }
  .row-enter-active {
    animation: rowIn 0.22s var(--m-ease) both;
  }
  .row-leave-active {
    transition:
      opacity 0.14s linear,
      transform 0.14s var(--m-ease);
  }
  .row-leave-to {
    opacity: 0;
    transform: translateX(6px);
  }
  @keyframes rowIn {
    from {
      opacity: 0;
      transform: translateY(-3px);
    }
  }
  @keyframes statIn {
    from {
      opacity: 0;
      transform: translateY(5px);
    }
  }
  @media (max-width: 1180px) {
    .mp-stats {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .mp-cols {
      grid-template-columns: minmax(0, 1fr);
    }
  }
</style>
