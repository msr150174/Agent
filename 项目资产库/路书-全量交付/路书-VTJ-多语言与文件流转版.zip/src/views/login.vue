<template>
  <div class="login-page">
    <div class="login-bg">
      <div class="login-container">
        <div class="brand-panel">
          <div class="brand-logo">
            <span class="logo-icon"> 🧭</span>
            <span class="brand-name"> 路书</span>
          </div>
          <div class="brand-slogan">AI 职业规划智能体</div>
          <div class="brand-desc">
            面向高职学生的智能职业规划工作台，帮你发现方向、规划路径、找到答案。
          </div>
          <div class="brand-features">
            <div class="feature-item">
              <span class="feature-dot"></span>
              <span> 知识库可溯源回答</span>
            </div>
            <div class="feature-item">
              <span class="feature-dot"></span>
              <span> 行业与职业数据支撑</span>
            </div>
            <div class="feature-item">
              <span class="feature-dot"></span>
              <span> 个性化成长计划</span>
            </div>
          </div>
        </div>
        <div class="form-panel">
          <div class="form-header">
            <div class="form-title">欢迎登录</div>
            <div class="form-subtitle">请使用学号或教师账号登录工作台</div>
          </div>
          <div class="form-body">
            <div class="form-role">
              <button
                v-for="(role, index) in roleOptions"
                :key="role.value"
                type="button"
                :class="
                  Object.assign(
                    { 'role-btn': true },
                    { active: __state.role === role.value }
                  )
                "
                @click="() => (__state.role = role.value)">
                {{ role.label }}
              </button>
            </div>
            <div class="form-field">
              <label class="field-label"> 账号</label>
              <input
                v-model="__state.username"
                type="text"
                class="field-input"
                placeholder="请输入学号 / 工号"
                @keyup.enter="handleLogin" />
            </div>
            <div class="form-field">
              <label class="field-label"> 密码</label>
              <input
                v-model="__state.password"
                type="password"
                class="field-input"
                placeholder="请输入密码"
                @keyup.enter="handleLogin" />
            </div>
            <div class="form-remember">
              <label class="remember-label">
                <input
                  v-model="__state.remember"
                  type="checkbox"
                  class="remember-checkbox" />
                <span> 记住登录状态</span></label
              >
            </div>
            <div v-if="__state.errorMsg" class="form-error">
              {{ __state.errorMsg }}
            </div>
            <button
              type="button"
              class="login-btn"
              :disabled="loading"
              @click="handleLogin">
              <span v-if="!loading"> 登 录</span>
              <span v-else> 登录中…</span>
            </button>
            <div class="form-footer">
              <span> 演示环境默认：学生 / 教师账号均可直接登录</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  // @ts-nocheck
  import { useProvider } from '@vtj/renderer';
  import { ref, reactive } from 'vue';
  import { useRouter } from 'vue-router';

  const __provider = useProvider({ id: 'er0d043h', version: '1794455786678' });

  const __router = useRouter();
  const loading = ref(false);
  const roleOptions = ref([
    { value: 'student', label: '学生' },
    { value: 'teacher', label: '教师 / 管理员' }
  ]);
  const __state = reactive({
    role: 'student',
    errorMsg: '',
    password: '',
    remember: true,
    username: ''
  });
  const handleLogin = () => {
    if (!__state.username.trim()) {
      __state.errorMsg = '请输入账号';
      return;
    }
    if (!__state.password.trim()) {
      __state.errorMsg = '请输入密码';
      return;
    }
    __state.errorMsg = '';
    loading.value = true;
    setTimeout(() => {
      loading.value = false;
      if (__state.role === 'teacher') {
        __router.push('/page/kb-manage');
      } else {
        __router.push('/page/chat-workspace');
      }
    }, 800);
  }
</script>
<style lang="css" scoped>
  .login-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f7fa;
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
  }
  .login-bg {
    width: 100%;
    max-width: 960px;
    padding: 24px;
    box-sizing: border-box;
  }
  .login-container {
    display: flex;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 20px 50px rgba(15, 23, 42, 0.09);
    overflow: hidden;
  }
  .brand-panel {
    flex: 0 0 46%;
    padding: 48px 36px;
    background: linear-gradient(160deg, #1e3a8a 0%, #2f6bff 100%);
    color: #fff;
    display: flex;
    flex-direction: column;
  }
  .brand-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
  }
  .logo-icon {
    font-size: 30px;
  }
  .brand-name {
    font-size: 26px;
    font-weight: 700;
    letter-spacing: 1px;
  }
  .brand-slogan {
    font-size: 16px;
    opacity: 0.9;
    margin-bottom: 16px;
  }
  .brand-desc {
    font-size: 13px;
    line-height: 1.7;
    opacity: 0.75;
    margin-bottom: 28px;
  }
  .brand-features {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .feature-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    opacity: 0.85;
  }
  .feature-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #8ab4ff;
    flex-shrink: 0;
  }
  .form-panel {
    flex: 1;
    padding: 48px 40px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .form-header {
    margin-bottom: 28px;
  }
  .form-title {
    font-size: 24px;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 8px;
  }
  .form-subtitle {
    font-size: 13px;
    color: #6b7280;
  }
  .form-role {
    display: flex;
    background: #f3f4f6;
    border-radius: 8px;
    padding: 4px;
    margin-bottom: 22px;
  }
  .role-btn {
    flex: 1;
    padding: 9px 0;
    border: none;
    border-radius: 6px;
    background: transparent;
    font-size: 13px;
    color: #6b7280;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  .role-btn.active {
    background: #fff;
    color: #2f6bff;
    font-weight: 600;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
  }
  .form-field {
    margin-bottom: 18px;
  }
  .field-label {
    display: block;
    font-size: 13px;
    color: #374151;
    margin-bottom: 7px;
    font-weight: 500;
  }
  .field-input {
    width: 100%;
    height: 42px;
    padding: 0 14px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    color: #1f2937;
    outline: none;
    box-sizing: border-box;
    transition:
      border-color 0.2s ease,
      box-shadow 0.2s ease;
  }
  .field-input:focus {
    border-color: #2f6bff;
    box-shadow: 0 0 0 3px rgba(47, 107, 255, 0.1);
  }
  .field-input::placeholder {
    color: #9ca3af;
  }
  .form-remember {
    margin-bottom: 18px;
  }
  .remember-label {
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 13px;
    color: #6b7280;
    cursor: pointer;
  }
  .remember-checkbox {
    width: 15px;
    height: 15px;
    accent-color: #2f6bff;
    cursor: pointer;
  }
  .form-error {
    padding: 8px 12px;
    border-radius: 6px;
    background: #fef2f2;
    color: #dc2626;
    font-size: 12px;
    margin-bottom: 14px;
  }
  .login-btn {
    width: 100%;
    height: 44px;
    border: none;
    border-radius: 8px;
    background: #2f6bff;
    color: #fff;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    letter-spacing: 2px;
    transition: background 0.2s ease;
  }
  .login-btn:hover {
    background: #1e56d6;
  }
  .login-btn:disabled {
    background: #a5b9e8;
    cursor: not-allowed;
  }
  .form-footer {
    margin-top: 18px;
    text-align: center;
    font-size: 11px;
    color: #9ca3af;
  }
</style>
