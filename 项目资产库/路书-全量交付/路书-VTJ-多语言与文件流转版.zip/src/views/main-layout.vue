<template>
  <div class="app-shell">
    <!-- 路由切换进度条：2px，只动 transform，不重排 -->
    <i v-if="ui.progressKey" :key="ui.progressKey" class="route-progress"></i>

    <div class="demo-banner">
      <span class="demo-banner-tag">{{ isEn ? 'Demo data' : '演示数据' }}</span>
      <span v-if="isEn"
        >Answers come only from groups A–E (37 docs). Every number and case here is for classroom
        demo — not a promise of admission or salary.</span
      >
      <span v-else
        >正式版回答只取 A–E 五组知识库（37 篇）；本页所有数字与案例均为课堂演示用，不构成录取或薪资承诺。</span
      >
      <span class="banner-keys">
        <span class="kbd">Ctrl</span><span class="kbd">K</span>
        <em>{{ isEn ? 'Commands' : '命令面板' }}</em>
        <span class="kbd">Ctrl</span><span class="kbd">B</span>
        <em>{{ isEn ? 'Sidebar' : '收起左栏' }}</em>
      </span>
    </div>

    <div class="main-layout">
      <aside class="left-sidebar">
        <div class="sidebar-top">
          <AppSidebar></AppSidebar>
        </div>
      </aside>
      <main class="main-content">
        <TabBar @palette="paletteOpen = true"></TabBar>
        <div class="view-host">
          <RouterView></RouterView>
        </div>
      </main>
    </div>

    <CommandPalette v-model="paletteOpen" :items="paletteItems" @select="runCommand">
    </CommandPalette>

    <Transition name="gtoast">
      <div v-if="ui.toast" :key="ui.toastSeq" class="global-toast">
        <span class="gt-tick">
          <svg viewBox="0 0 12 12" width="10" height="10" aria-hidden="true">
            <path
              d="M2 6.4l2.6 2.6L10 3.4"
              fill="none"
              stroke="currentColor"
              stroke-width="1.7"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-dasharray="24"
              class="gt-path" />
          </svg>
        </span>
        {{ ui.toast }}
      </div>
    </Transition>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed, onMounted, onBeforeUnmount } from 'vue';
  import { RouterView, useRouter, useRoute } from 'vue-router';
  import AppSidebar from '@/components/AppSidebar.vue';
  import TabBar from '@/components/TabBar.vue';
  import CommandPalette from '@/components/CommandPalette.vue';
  import { ui, notify, startProgress } from '@/store/ui';
  import { useI18n, setLang } from '@/i18n';

  const router = useRouter();
  const route = useRoute();
  const paletteOpen = ref(false);
  const { t, isEn, lang } = useI18n();

  const PAGES = computed(() => [
    { path: '/page/chat-workspace', title: t('nav.chat'), icon: '❝', desc: isEn.value ? 'Ask · answers with sources' : '提问 · 带出处的回答', keys: 'duihua chat wenti' },
    { path: '/page/self-assessment', title: t('nav.assess'), icon: '✎', desc: isEn.value ? '12 questions · six dimensions' : '12 题 · 六维相对分', keys: 'renshi ziji ziping ce ping' },
    { path: '/page/career-library', title: t('nav.career'), icon: '◎', desc: isEn.value ? 'Job cards · three paths' : '岗位卡 · 三条路径对比', keys: 'kan qing lu gangwei luxian' },
    { path: '/page/growth-plan', title: t('nav.plan'), icon: '☰', desc: isEn.value ? 'One goal · term tasks' : '目标一句话 · 学期任务', keys: 'luxiantu jihua renwu' },
    { path: '/page/knowledge-base', title: t('nav.kb'), icon: '▤', desc: isEn.value ? 'Groups A–E · 37 docs' : 'A–E 五组 37 篇', keys: 'zhishiku ziliao' },
    { path: '/page/materials', title: t('nav.materials'), icon: '⇅', desc: isEn.value ? 'Uploads and outputs' : '上传的材料 · 产出的文件', keys: 'cailiao chanchu materials files' },
    { path: '/page/call-logs', title: t('nav.logs'), icon: '≡', desc: isEn.value ? 'Teacher · intents and hits' : '教师侧 · 意图与命中', keys: 'diaoyong rizhi jiaoshi' },
    { path: '/page/kb-manager', title: t('nav.manage'), icon: '⚙', desc: isEn.value ? 'Teacher · intake and review' : '教师侧 · 入库与终审', keys: 'zhishiku guanli shenhe' }
  ]);

  const paletteItems = computed(() => [
    ...PAGES.value.map((p) => ({
      id: 'go' + p.path,
      group: isEn.value ? 'Pages' : '去页面',
      title: p.title,
      desc: p.desc,
      icon: p.icon,
      keywords: p.keys,
      action: () => (route.path === p.path ? notify('已经在「' + p.title + '」了') : router.push(p.path))
    })),
    {
      id: 'toggle-sidebar',
      group: isEn.value ? 'View' : '视图',
      title: isEn.value ? 'Collapse / expand sidebar' : '收起 / 展开左栏',
      desc: isEn.value ? 'Shrinks to an icon rail' : '折叠成图标条，悬停浮出文字',
      icon: '⇤',
      keywords: 'cebian shouqi zhedie sidebar',
      kbd: 'Ctrl B',
      action: () => {
        ui.sidebarCollapsed = !ui.sidebarCollapsed;
        notify(ui.sidebarCollapsed ? '左栏已收成图标条' : '左栏已展开');
      }
    },
    {
      id: 'toggle-sessions',
      group: isEn.value ? 'View' : '视图',
      title: isEn.value ? 'Session column on / off' : '会话列 显示 / 隐藏',
      desc: isEn.value ? 'Three columns ↔ two' : '三栏 ↔ 双栏',
      icon: '◧',
      keywords: 'huihua lie session',
      kbd: 'Ctrl J',
      action: () => {
        ui.showSessions = !ui.showSessions;
        notify(ui.showSessions ? '会话列已显示' : '会话列已收起');
      }
    },
    {
      id: 'toggle-refs',
      group: isEn.value ? 'View' : '视图',
      title: isEn.value ? 'Sources column on / off' : '来源栏 显示 / 隐藏',
      desc: isEn.value ? 'Three columns ↔ two' : '三栏 ↔ 双栏',
      icon: '◨',
      keywords: 'laiyuan lan reference',
      kbd: 'Ctrl \\',
      action: () => {
        ui.showRefs = !ui.showRefs;
        notify(ui.showRefs ? '来源栏已显示' : '来源栏已收起');
      }
    },
    {
      id: 'switch-lang',
      group: isEn.value ? 'View' : '视图',
      title: isEn.value ? '切换到中文' : '切换到 English',
      desc: isEn.value ? 'UI text only; sources stay Chinese' : '只换界面文案，资料正文不翻',
      icon: '文',
      keywords: 'yuyan language lang zhongying',
      action: () => {
        setLang(isEn.value ? 'zh' : 'en');
        notify(isEn.value ? 'UI language: English' : '界面语言：中文');
      }
    },
    {
      id: 'copy-link',
      group: isEn.value ? 'Actions' : '动作',
      title: isEn.value ? 'Copy this page link' : '复制当前页面链接',
      desc: route.path,
      icon: '⧉',
      keywords: 'fuzhi lianjie copy link',
      action: () => {
        const url = location.origin + location.pathname + '#' + route.path;
        if (navigator.clipboard) navigator.clipboard.writeText(url).catch(() => {});
        notify('链接已复制：' + route.path);
      }
    }
  ]);

  const runCommand = (item) => {
    if (item && typeof item.action === 'function') item.action();
  };

  /* 快捷键：⌘/Ctrl + B / J / \ */
  const onKey = (e) => {
    const mod = e.metaKey || e.ctrlKey;
    if (!mod) return;
    const k = e.key.toLowerCase();
    if (k === 'b') {
      e.preventDefault();
      ui.sidebarCollapsed = !ui.sidebarCollapsed;
    } else if (k === 'j') {
      e.preventDefault();
      ui.showSessions = !ui.showSessions;
      notify(ui.showSessions ? '会话列已显示' : '会话列已收起');
    } else if (k === '\\') {
      e.preventDefault();
      ui.showRefs = !ui.showRefs;
      notify(ui.showRefs ? '来源栏已显示' : '来源栏已收起');
    }
  };

  /* 进度条跟着路由生命周期走：before 起跑，after 交给 CSS 收尾 */
  let unHookRoute = null;
  onMounted(() => {
    window.addEventListener('keydown', onKey);
    unHookRoute = router.beforeEach(() => {
      startProgress();
      return true;
    });
  });
  onBeforeUnmount(() => {
    window.removeEventListener('keydown', onKey);
    if (typeof unHookRoute === 'function') unHookRoute();
  });
</script>

<style lang="css" scoped>
  .app-shell {
    display: flex;
    flex-direction: column;
    height: 100vh;
    min-width: 1024px;
    background: #f5f7fa;
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
    overflow: hidden;
    position: relative;
  }
  .route-progress {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 40;
    display: block;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, #2f6bff, #6f9bff);
    transform-origin: left center;
    box-shadow: 0 0 8px rgba(47, 107, 255, 0.45);
    /* 冲到 88% 停一下再补满，然后淡出 —— 一次跑完，不来回动 */
    animation:
      routeGo 0.62s cubic-bezier(0.2, 0.8, 0.2, 1) both,
      routeFade 0.22s linear 0.66s forwards;
  }
  @keyframes routeGo {
    0% {
      transform: scaleX(0);
    }
    55% {
      transform: scaleX(0.72);
    }
    100% {
      transform: scaleX(1);
    }
  }
  @keyframes routeFade {
    to {
      opacity: 0;
    }
  }
  .demo-banner {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 7px 16px;
    background: #fff7e6;
    border-bottom: 1px solid #ffe0a3;
    font-size: 12px;
    color: #96620a;
  }
  .demo-banner-tag {
    flex-shrink: 0;
    padding: 1px 7px;
    border-radius: 4px;
    background: #ffd591;
    color: #8a4b00;
    font-size: 11px;
    font-weight: 600;
  }
  .banner-keys {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
    gap: 3px;
    flex-shrink: 0;
  }
  .banner-keys em {
    font-style: normal;
    margin-right: 6px;
    color: #b07f2a;
    font-size: 11px;
  }
  .banner-keys .kbd {
    border-color: #ecd9b4;
    background: #fffdf7;
    color: #95702a;
  }
  .main-layout {
    flex: 1;
    min-height: 0;
    display: flex;
    overflow: hidden;
  }
  .left-sidebar {
    width: auto;
    flex: 0 0 auto;
    display: flex;
    flex-direction: column;
    background: #fff;
    border-right: 1px solid #eef0f3;
  }
  .sidebar-top {
    flex: 1;
    min-height: 0;
    /* 不能设 overflow：折叠把手是负偏移贴在边界外的，会被裁掉 */
    overflow: visible;
  }
  .main-content {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .view-host {
    flex: 1;
    min-height: 0;
    display: flex;
    overflow: hidden;
  }
  /* 全局 toast：右下角浮出，带一个画出来的勾 */
  .global-toast {
    position: fixed;
    left: 50%;
    bottom: 28px;
    z-index: 3200;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 8px 14px 8px 11px;
    border-radius: 999px;
    background: rgba(24, 30, 42, 0.92);
    color: #fff;
    font-size: 12.5px;
    box-shadow: var(--m-shadow-3);
    animation: toastIn 0.22s var(--m-ease) both;
  }
  .gt-tick {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.16);
    color: #8ee6a8;
  }
  .gt-path {
    animation: tickDraw 0.34s cubic-bezier(0.2, 0.8, 0.2, 1) 0.06s both;
  }
  .gtoast-leave-active {
    transition:
      opacity 0.18s linear,
      transform 0.18s var(--m-ease);
  }
  .gtoast-leave-to {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
  @media (max-width: 1100px) {
    .app-shell {
      min-width: 0;
    }
    .banner-keys {
      display: none;
    }
    .main-layout {
      flex-direction: column;
    }
    .left-sidebar {
      width: 100%;
      border-right: none;
      border-bottom: 1px solid #eef0f3;
    }
  }
</style>
