<template>
  <div class="kb-page">
    <div class="page-header">
      <div class="title-block">
        <h2>知识库</h2>
        <p class="page-desc">
          A–E 五组共 37 篇。对话里的回答只能引这里的内容，没有的就是没有。
        </p>
        <div class="kb-stat">37 篇 · 5 组 · 最近更新 2025-03-09</div>
      </div>
      <div class="tools">
        <ElInput v-model="keyword" class="search" clearable placeholder="搜文档标题或摘要" />
        <ElSelect v-model="category" class="sel" placeholder="全部分组">
          <ElOption label="全部" value="全部" />
          <ElOption label="A 专业与岗位" value="A 专业与岗位" />
          <ElOption label="B 证书与考试" value="B 证书与考试" />
          <ElOption label="C 岗位与能力" value="C 岗位与能力" />
          <ElOption label="D 行业与就业数据" value="D 行业与就业数据" />
          <ElOption label="E 求职技能" value="E 求职技能" />
        </ElSelect>
      </div>
    </div>

    <div v-if="filtered.length === 0" class="empty">
      <ElEmpty description="这个分组下暂时没有文档"></ElEmpty>
    </div>
    <div v-else class="doc-grid" @mousemove="trackSpot">
      <div
        v-for="(doc, di) in paged"
        :key="doc.id"
        class="doc-card spot stagger"
        :style="{ '--i': di }">
        <div class="doc-top">
          <span class="idx">{{ String((currentPage - 1) * pageSize + di + 1).padStart(2, '0') }}</span>
          <ElTag size="small" :type="tagType(doc.category)">{{ doc.category }}</ElTag>
          <span class="citations">被引用 <b class="num">{{ doc.citations }}</b> 次</span>
        </div>
        <h3 class="doc-title">{{ doc.title }}</h3>
        <p class="doc-summary">{{ doc.summary }}</p>
        <div class="doc-foot">
          <span class="date">入库 {{ doc.updatedAt }}</span>
          <span class="action">查看原文 →</span>
        </div>
      </div>
    </div>

    <div v-if="filtered.length > pageSize" class="pager">
      <ElPagination
        v-model:current-page="currentPage"
        :total="filtered.length"
        :page-size="pageSize"
        layout="prev, pager, next"></ElPagination>
    </div>
  </div>
</template>

<script lang="ts" setup>
  // @ts-nocheck
  import { ref, computed } from 'vue';
  import { ElInput, ElSelect, ElOption, ElTag, ElEmpty, ElPagination } from 'element-plus';

  const keyword = ref('');
  const category = ref('全部');
  const pageSize = 9;
  const currentPage = ref(1);

  /* 光标高光：网格上监听一次，写 CSS 变量给 .spot::before 用 */
  let rafId = 0;
  const trackSpot = (e) => {
    if (rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      const card = e.target.closest('.doc-card');
      if (!card) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', e.clientX - r.left + 'px');
      card.style.setProperty('--my', e.clientY - r.top + 'px');
    });
  };

  const docs = [
    {
      id: 1,
      title: '计算机应用技术专业对口岗位表',
      category: 'A 专业与岗位',
      summary: '列出本专业 12 个对口岗位、能力项与学历要求，含本校近两届去向。',
      citations: 46,
      updatedAt: '2025-03-08'
    },
    {
      id: 2,
      title: '电子商务专业对口岗位表',
      category: 'A 专业与岗位',
      summary: '电商运营、跨境电商、客服主管三类岗位的能力项与起薪样本。',
      citations: 38,
      updatedAt: '2025-03-09'
    },
    {
      id: 3,
      title: '高职学生成长路线图模板',
      category: 'A 专业与岗位',
      summary: '按学期拆任务的模板，含目标一句话、任务清单、证书挂载位置。',
      citations: 31,
      updatedAt: '2025-03-05'
    },
    {
      id: 4,
      title: '专插本考试科目说明（校内整理）',
      category: 'B 证书与考试',
      summary: '公共课与专业基础课的科目构成，注明以省考试院当年通知为准。',
      citations: 27,
      updatedAt: '2025-02-28'
    },
    {
      id: 5,
      title: '1+X Web 前端开发（初级）考核要求',
      category: 'B 证书与考试',
      summary: '考核模块、实操时长与通过标准，附备考顺序建议。',
      citations: 22,
      updatedAt: '2025-02-26'
    },
    {
      id: 6,
      title: '全国计算机等级考试二级说明',
      category: 'B 证书与考试',
      summary: '考试科目、报名时间窗口与常见误区。',
      citations: 19,
      updatedAt: '2025-02-24'
    },
    {
      id: 7,
      title: 'Java 后端开发岗位能力清单',
      category: 'C 岗位与能力',
      summary: '7 项要求逐条拆解：语法、数据库、Git、Linux、框架、接口联调、排错。',
      citations: 35,
      updatedAt: '2025-03-07'
    },
    {
      id: 8,
      title: 'Web 前端开发岗位能力清单',
      category: 'C 岗位与能力',
      summary: '页面还原、交互、接口对接三层能力项，附作品集建议。',
      citations: 33,
      updatedAt: '2025-03-07'
    },
    {
      id: 9,
      title: '软件测试岗位能力清单',
      category: 'C 岗位与能力',
      summary: '用例设计、缺陷管理、回归流程，对算法要求较低。',
      citations: 24,
      updatedAt: '2025-03-06'
    },
    {
      id: 10,
      title: '2024 届毕业生就业质量回收样本',
      category: 'D 行业与就业数据',
      summary: '本校 213 条回收样本的岗位分布、起薪区间与专业对口率。',
      citations: 58,
      updatedAt: '2025-01-15'
    },
    {
      id: 11,
      title: '珠三角中小软件企业招聘观察',
      category: 'D 行业与就业数据',
      summary: '近 12 个月招聘要求变化，专科可投岗位占比。',
      citations: 21,
      updatedAt: '2025-03-02'
    },
    {
      id: 12,
      title: '求职简历撰写与面试表达',
      category: 'E 求职技能',
      summary: '无实习经历时的简历写法，附 20 个结构化面试常见问题。',
      citations: 41,
      updatedAt: '2025-03-06'
    },
    {
      id: 13,
      title: '结构化面试常见问题（20 题）',
      category: 'E 求职技能',
      summary: '按「动机 / 经历 / 复盘 / 规划」四类归好的问题与回答框架。',
      citations: 29,
      updatedAt: '2025-03-04'
    }
  ];

  const filtered = computed(() => {
    const kw = keyword.value.trim().toLowerCase();
    return docs.filter((d) => {
      const okCat = category.value === '全部' || d.category === category.value;
      const okKw =
        !kw ||
        d.title.toLowerCase().includes(kw) ||
        d.summary.toLowerCase().includes(kw);
      return okCat && okKw;
    });
  });

  const paged = computed(() => {
    const start = (currentPage.value - 1) * pageSize;
    return filtered.value.slice(start, start + pageSize);
  });

  const tagType = (c) => {
    const map = {
      'A 专业与岗位': 'primary',
      'B 证书与考试': 'warning',
      'C 岗位与能力': 'success',
      'D 行业与就业数据': 'info',
      'E 求职技能': 'danger'
    };
    return map[c] || 'info';
  };
</script>

<style lang="css" scoped>
  .kb-page {
    flex: 1;
    min-width: 0;
    overflow-y: auto;
    padding: 18px 20px 24px;
    box-sizing: border-box;
  }
  .page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
  }
  .title-block h2 {
    margin: 0 0 6px;
    font-size: 18px;
    color: #1f2937;
  }
  .page-desc {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.8;
    color: #6b7280;
  }
  .kb-stat {
    margin-top: 6px;
    font-size: 11.5px;
    color: #9ca3af;
  }
  .tools {
    display: flex;
    gap: 10px;
    flex-shrink: 0;
  }
  .search {
    width: 200px;
  }
  .sel {
    width: 170px;
  }
  .doc-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 12px;
  }
  .doc-card {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 14px 16px;
  }
  .doc-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .citations {
    font-size: 11px;
    color: #9ca3af;
  }
  .doc-title {
    margin: 10px 0 6px;
    font-size: 14.5px;
    color: #1f2937;
    line-height: 1.5;
  }
  .doc-summary {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.75;
    color: #6b7280;
    min-height: 44px;
  }
  .doc-foot {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px dashed #eef0f3;
  }
  .date {
    font-size: 11px;
    color: #b9bdc4;
  }
  .action {
    font-size: 11.5px;
    color: #2f6bff;
    cursor: pointer;
  }
  .pager {
    display: flex;
    justify-content: flex-end;
    margin-top: 14px;
  }
  .empty {
    background: #fff;
    border: 1px solid #eef0f3;
    border-radius: 12px;
    padding: 40px 0;
  }
</style>
