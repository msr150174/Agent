import { ref, computed } from 'vue';

/**
 * 轻量 i18n。
 * 只翻「导航 + 操作 + 状态」这层皮 —— A–E 五组知识库的正文是中文原文，
 * 翻译过去等于二次加工，容易把「原文这么写」变成「我以为它这么写」。
 * 所以资料正文永远保持原文，英文界面下另外给一段标注清楚的英文摘要。
 */
export type Lang = 'zh' | 'en';

const DICT = {
  /* ---------- 导航 ---------- */
  'nav.chat': { zh: '对话', en: 'Chat' },
  'nav.assess': { zh: '认识自己', en: 'Know yourself' },
  'nav.career': { zh: '看清路', en: 'See the paths' },
  'nav.plan': { zh: '路线图', en: 'Roadmap' },
  'nav.kb': { zh: '知识库', en: 'Knowledge base' },
  'nav.materials': { zh: '材料与产出', en: 'Files & outputs' },
  'nav.logs': { zh: '调用日志', en: 'Call logs' },
  'nav.manage': { zh: '知识库管理', en: 'KB admin' },
  'nav.teacher': { zh: '教师入口', en: 'Teacher' },
  'nav.student': { zh: '学生工作台', en: 'Student workspace' },

  /* ---------- 通用 ---------- */
  'c.send': { zh: '发送', en: 'Send' },
  'c.stop': { zh: '停止', en: 'Stop' },
  'c.cancel': { zh: '取消', en: 'Cancel' },
  'c.close': { zh: '关闭', en: 'Close' },
  'c.download': { zh: '下载', en: 'Download' },
  'c.preview': { zh: '预览', en: 'Preview' },
  'c.copy': { zh: '复制', en: 'Copy' },
  'c.copied': { zh: '已复制', en: 'Copied' },
  'c.export': { zh: '导出', en: 'Export' },
  'c.remove': { zh: '移除', en: 'Remove' },
  'c.retry': { zh: '重试', en: 'Retry' },
  'c.empty': { zh: '还没有', en: 'Nothing yet' },
  'c.more': { zh: '展开看', en: 'Details' },
  'c.less': { zh: '收起', en: 'Collapse' },

  /* ---------- 对话 ---------- */
  'chat.sub': {
    zh: '只回答知识库里有的 · 没收录的直接说',
    en: "Only answers what the KB holds — and says when it doesn't"
  },
  'chat.ph': { zh: '问专业、问岗位、问升学政策都行', en: 'Ask about majors, jobs or study policy' },
  'chat.tip': { zh: 'Enter 发送 · Shift + Enter 换行', en: 'Enter to send · Shift+Enter for a new line' },
  'chat.openerTitle': { zh: '你好，我是路书', en: "Hi, I'm Lushu" },
  'chat.openerLede1': {
    zh: '我能做三件事：陪你认识自己（12 道自评）、看清本专业的岗位与三条路、把目标拆成按学期的路线图。',
    en: 'Three things: a 12-question self-assessment, a look at the jobs and three paths for your major, and a road map split by term.'
  },
  'chat.openerLede2': {
    zh: '我只回答知识库里有的内容。没收录的会直接说「现有资料未覆盖」，不猜；政策类会给出来源和生效日期，仅供参考。',
    en: 'I answer only from the knowledge base. If it is not covered I say so instead of guessing; policy answers carry a source and an effective date.'
  },
  'chat.start': { zh: '开始', en: 'Start' },
  'chat.trace': { zh: '检索 {{n}} 组 · 命中 {{n}} 组', en: 'Searched {{n}} groups' },
  'chat.enNote': {
    zh: '英文摘要 · 以中文原文为准',
    en: 'English summary — the Chinese original governs'
  },
  'chat.generating': { zh: '生成中…', en: 'Generating…' },
  'chat.attachedTo': { zh: '这条问题带了 {{n}} 个附件', en: '{{n}} attachment(s) with this question' },
  'chat.sources': { zh: '来源', en: 'Sources' },
  'chat.followUp': { zh: '就这条追问', en: 'Follow up on this' },
  'chat.traceFoot': {
    zh: '只挂载这几组的原文；未命中的分组不参与回答。',
    en: 'Only these groups are mounted; the rest take no part in the answer.'
  },
  'chat.traceAll': { zh: '检索 {{n}} 组', en: 'Searched {{n}} groups' },
  'a.rows': { zh: '{{n}} 行', en: '{{n}} rows' },
  'm.fromChat': { zh: '对话上传', en: 'From chat' },
  'm.foot': {
    zh: '材料只作补充，回答的出处仍然只认 A–E 五组；产出的文件由回答内容拆成，不新增资料里没有的数字。',
    en: 'Attachments add context only — citations stay with groups A–E. Output files are split from the answer, never adding numbers the sources do not hold.'
  },

  /* ---------- 语言 ---------- */
  'lang.title': { zh: '界面语言', en: 'UI language' },
  'lang.zh': { zh: '简体中文（默认）', en: 'Simplified Chinese (default)' },
  'lang.en': { zh: 'English（英文）', en: 'English' },
  'lang.zhDesc': { zh: '导航、按钮、提示都用中文', en: 'Navigation, buttons and hints in Chinese' },
  'lang.enDesc': { zh: '界面用英文，资料正文仍是中文原文', en: 'UI in English; source text stays Chinese' },
  'lang.hint': { zh: 'Enter 确认 · Esc 退出', en: 'Enter to confirm · Esc to exit' },
  'lang.applied': { zh: '界面语言已切换', en: 'UI language switched' },
  'lang.note': {
    zh: '资料正文不翻译：A–E 组原文是中文，翻了就成了二次加工。',
    en: 'Source text is not translated — A–E originals stay as written.'
  },

  /* ---------- 语音 ---------- */
  'v.start': { zh: '语音输入', en: 'Voice input' },
  'v.listening': { zh: '正在听，说完点一下结束', en: 'Listening — tap again to stop' },
  'v.recognizing': { zh: '识别中…', en: 'Transcribing…' },
  'v.done': { zh: '已转成文字，可以改了再发', en: 'Transcribed — edit before sending' },
  'v.unsupported': {
    zh: '这个浏览器不支持语音识别，已切到演示输入',
    en: 'Speech recognition unavailable — switched to demo input'
  },
  'v.demo': { zh: '演示模式 · 未接入真实语音识别', en: 'Demo mode — no real speech recognition' },
  'v.demoFill': { zh: '演示：已填入一句示例问题', en: 'Demo: sample question filled in' },
  'v.read': { zh: '朗读', en: 'Read aloud' },
  'v.reading': { zh: '朗读中', en: 'Reading' },
  'v.readStop': { zh: '停止朗读', en: 'Stop reading' },
  'v.readUnsupported': { zh: '当前浏览器没有可用语音，读不了', en: 'No speech voice available in this browser' },
  'v.micDenied': { zh: '麦克风没授权，先用演示输入', en: 'Microphone blocked — using demo input' },

  /* ---------- 上传 ---------- */
  'u.attach': { zh: '附件', en: 'Attach' },
  'u.drop': { zh: '松手就加上', en: 'Drop to attach' },
  'u.dropHint': {
    zh: 'PDF / Word / Excel / 图片 / 文本，单个不超过 20 MB',
    en: 'PDF, Word, Excel, image or text — up to 20 MB each'
  },
  'u.choose': { zh: '选择文件', en: 'Choose files' },
  'u.paste': { zh: '也可以直接 Ctrl+V 粘贴图片', en: 'Or paste an image with Ctrl+V' },
  'u.parsing': { zh: '解析中', en: 'Reading' },
  'u.queued': { zh: '排队', en: 'Queued' },
  'u.done': { zh: '已读 {{n}} 段', en: '{{n}} chunks read' },
  'u.failed': { zh: '失败', en: 'Failed' },
  'u.tooBig': { zh: '超过 20 MB', en: 'Over 20 MB' },
  'u.badType': { zh: '暂不支持这个格式', en: 'This format is not supported' },
  'u.free': { zh: '上传与解析不计额度', en: "Uploads don't use quota" },
  'u.attached': { zh: '已附 {{n}} 个文件', en: '{{n}} file(s) attached' },
  'u.removeAll': { zh: '全部移除', en: 'Remove all' },
  'u.readNote': {
    zh: '附件只用来补足你的情况，不当作资料出处 —— 出处仍然只认 A–E 五组。',
    en: 'Attachments add context only; citations still come from groups A–E.'
  },

  /* ---------- 产物 ---------- */
  'a.title': { zh: '本次产出', en: 'Outputs' },
  'a.generating': { zh: '生成中', en: 'Generating' },
  'a.ready': { zh: '可下载', en: 'Ready' },
  'a.empty': { zh: '这次回答没有产出文件', en: 'No files produced this time' },
  'a.emptyHint': {
    zh: '要清单、对照表这类东西，直接在问题里说「给我一份…」',
    en: 'Ask for a checklist or table in the question to get a file'
  },
  'a.download': { zh: '下载', en: 'Download' },
  'a.copyLink': { zh: '复制链接', en: 'Copy link' },
  'a.copied': { zh: '链接已复制', en: 'Link copied' },
  'a.demoLink': { zh: '演示环境：链接只在本机有效', en: 'Demo: link only works locally' },
  'a.saved': { zh: '已开始下载 {{name}}', en: 'Downloading {{name}}' },

  /* ---------- 导出 ---------- */
  'e.title': { zh: '导出这个页面', en: 'Export this page' },
  'e.csv': { zh: '导出 CSV', en: 'Export CSV' },
  'e.csvDesc': { zh: '表格格式，Excel 直接打开', en: 'Spreadsheet format, opens in Excel' },
  'e.md': { zh: '导出 Markdown', en: 'Export Markdown' },
  'e.mdDesc': { zh: '纯文本，方便贴进文档', en: 'Plain text, easy to paste into docs' },
  'e.tsv': { zh: '复制为表格', en: 'Copy as table' },
  'e.tsvDesc': { zh: '复制到剪贴板，粘进表格', en: 'Copy to clipboard, paste into a sheet' },
  'e.done': { zh: '已导出 {{name}}', en: 'Exported {{name}}' },
  'e.copied': { zh: '已复制，可直接粘进表格', en: 'Copied — paste into a spreadsheet' },
  'e.free': { zh: '导出不计额度', en: "Exports don't use quota" },

  /* ---------- 材料与产出页 ---------- */
  'm.title': { zh: '材料与产出', en: 'Files & outputs' },
  'm.lede': {
    zh: '你给的材料在这边，我给你的文件在那边。两边都不动额度，也不改 A–E 的出处规则。',
    en: 'Your uploads on one side, files I produced on the other. Neither touches quota or the A–E citation rule.'
  },
  'm.materials': { zh: '我的材料', en: 'My uploads' },
  'm.outputs': { zh: '产出的文件', en: 'Produced files' },
  'm.materialsEmpty': { zh: '还没有上传材料', en: 'No uploads yet' },
  'm.outputsEmpty': { zh: '还没有产出文件', en: 'No outputs yet' },
  'm.goChat': { zh: '去对话里上传', en: 'Upload in chat' },
  'm.statFiles': { zh: '材料', en: 'Files' },
  'm.statParsed': { zh: '已解析', en: 'Parsed' },
  'm.statOutputs': { zh: '产出', en: 'Outputs' },
  'm.statSize': { zh: '合计大小', en: 'Total size' }
} as const;

export type I18nKey = keyof typeof DICT;

const STORE_KEY = 'lushu.lang';

function initial(): Lang {
  // 允许 ?lang=en 直接进英文界面：分享链接、截图、给英语用户试用都用得上
  try {
    const q = new URLSearchParams(location.search).get('lang');
    if (q === 'zh' || q === 'en') return q;
  } catch (e) {
    /* file:// 下没有 URLSearchParams 也无所谓 */
  }
  try {
    const v = localStorage.getItem(STORE_KEY);
    if (v === 'zh' || v === 'en') return v;
  } catch (e) {
    /* 隐私模式读不到 localStorage，用默认值就够了 */
  }
  return 'zh';
}

export const lang = ref<Lang>(initial());

export const isEn = computed(() => lang.value === 'en');

export function setLang(next: Lang) {
  lang.value = next;
  try {
    localStorage.setItem(STORE_KEY, next);
  } catch (e) {
    /* 存不了也不影响本次会话 */
  }
  try {
    document.documentElement.lang = next === 'zh' ? 'zh-CN' : 'en';
    document.title = next === 'zh' ? '路书 · 升学就业规划工作台' : 'Lushu · Study & Career Workbench';
  } catch (e) {
    /* SSR / 无 document 时跳过 */
  }
}

/** 带 {{n}} 占位的替换；参数缺了就把占位原样留着，不吞掉整句。 */
export function t(key: I18nKey, params?: Record<string, string | number>): string {
  const entry = DICT[key];
  if (!entry) return String(key);
  let out = entry[lang.value] || entry.zh;
  if (params) {
    Object.keys(params).forEach((k) => {
      out = out.split('{{' + k + '}}').join(String(params[k]));
    });
  }
  return out;
}

/** 给模板用的组合式入口：解构后 t 仍然是响应式的（内部读 lang.value）。 */
export function useI18n() {
  return { lang, isEn, setLang, t };
}

setLang(lang.value);
