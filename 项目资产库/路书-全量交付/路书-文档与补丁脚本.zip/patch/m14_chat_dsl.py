# -*- coding: utf-8 -*-
"""m14：把附件区、语音按钮、产物卡、语言切换同步进 DSL。

运行版（.vue）能真跑；DSL 这边要保证导回编辑器后节点、样式、演示数据都在，
所以交互先落到 $message 提示上 —— 不假装 DSL 里有真实上传通道。
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import vtj as V

CHAT = '8r0cd8oa'      # ChatPanel 组件
LAYOUT = 'hr0d0qx3'    # MainLayout


def d_for(expr, item):
    return {'id': V.nid('d'), 'name': 'vFor', 'value': V.js(expr),
            'iterator': {'item': item, 'index': 'index'}}


def d_if(expr):
    return {'id': V.nid('d'), 'name': 'vIf', 'value': V.js(expr)}


# ---------------- 附件区 ----------------
def attach_tray():
    chip = V.div('file-chip', [
        V.span(expr='this.context.item.ext', cls='fc-ico'),
        V.span(cls='fc-main', children=[
            V.span(expr='this.context.item.name', cls='fc-name'),
            V.span(cls='fc-meta', children=[
                V.span(expr='this.context.item.size'),
                V.span(' · ', cls='sep'),
                V.span(expr='this.context.item.note', cls='fc-st'),
            ]),
        ]),
        V.el('button', cls='fc-x', text='×'),
    ], directives=[d_for('this.attachments.value', 'item')])

    return V.div('attach-tray', [
        V.div('chips', [chip]),
        V.div('tray-foot', [
            V.el('button', cls='tray-btn', props={'type': 'button'}, children=[
                V.span('＋', cls='tb-ico'),
                V.span('附件'),
                V.span('2', cls='tb-count'),
            ], events={'click': V.fn(
                "() => {\n  this.$message.info('选择文件 / 拖进来 / Ctrl+V 粘贴，三条路都通');\n}")}),
            V.span('上传与解析不计额度', cls='tray-note'),
            V.span('全部移除', cls='tray-clear'),
        ]),
    ])


# ---------------- 语音按钮 ----------------
def voice_btn():
    return V.el('button', cls='voice-btn', props={'type': 'button', 'title': '语音输入'}, children=[
        V.el('svg', props={'viewBox': '0 0 16 16', 'width': '13', 'height': '13'}, children=[
            V.el('path', props={
                'd': 'M8 2.2c.9 0 1.6.7 1.6 1.6v3.4c0 .9-.7 1.6-1.6 1.6S6.4 8.1 6.4 7.2V3.8c0-.9.7-1.6 1.6-1.6Z',
                'fill': 'currentColor'}),
            V.el('path', props={
                'd': 'M4.2 7.1v.6a3.8 3.8 0 0 0 7.6 0v-.6M8 11.5V14M6 14h4',
                'fill': 'none', 'stroke': 'currentColor', 'stroke-width': '1.2',
                'stroke-linecap': 'round'}),
        ]),
    ], events={'click': V.fn(
        "() => {\n  this.$message.info('语音输入：浏览器支持识别时直接转文字，不支持就走演示输入');\n}")})


# ---------------- 产物卡 ----------------
def artifacts():
    card = V.div('art-card', [
        V.span(expr='this.context.item.ext', cls='art-ico'),
        V.div('art-main', [
            V.div(expr='this.context.item.name', cls='art-name'),
            V.div(cls='art-meta', children=[
                V.span(expr='this.context.item.size'),
                V.span(' · ', cls='sep'),
                V.span(expr='this.context.item.items'),
                V.span(' · ', cls='sep'),
                V.span(expr='this.context.item.time'),
            ]),
        ]),
        V.div('art-acts', [
            V.el('button', cls='aa', text='预览', props={'type': 'button'},
                 events={'click': V.fn("() => {\n  this.$message.info('预览：就地摊开前 40 行');\n}")}),
            V.el('button', cls='aa primary', text='下载', props={'type': 'button'},
                 events={'click': V.fn("() => {\n  this.$message.success('已开始下载');\n}")}),
        ]),
    ], directives=[d_for('this.context.msg.artifacts', 'item')])

    return V.div('artifacts', [
        V.div('art-head', [
            V.span('本次产出', cls='art-title'),
            V.span(expr='this.context.msg.artifacts.length', cls='art-count'),
        ]),
        V.div('art-list', [card]),
        V.span('演示环境：链接只在本机有效', cls='art-note'),
    ], directives=[d_if('this.context.msg.artifacts && this.context.msg.artifacts.length')])


# ---------------- 用户气泡里的附件条 ----------------
def msg_files():
    return V.div('msg-files', [
        V.span(cls='mf-item', children=[
            V.span(expr='this.context.att.ext', cls='mf-ico'),
            V.span(expr='this.context.att.name', cls='mf-name'),
            V.span(expr='this.context.att.chunks', cls='mf-chunks'),
        ])
    ], directives=[d_for('this.context.msg.attachments', 'att')])


def patch_chat():
    d = V.load(CHAT)
    root = d['nodes'][0]

    input_area = V.find(root, 'input-area')
    if not input_area:
        print('!! input-area not found')
        return
    if not V.find(root, 'attach-tray'):
        input_area['children'] = [attach_tray()] + input_area['children']

    actions = V.find(root, 'input-actions')
    if actions and not V.find(root, 'voice-btn'):
        tip = V.find(actions, 'input-tip')
        idx = actions['children'].index(tip) if tip in actions['children'] else 0
        actions['children'].insert(idx, voice_btn())

    # 正文气泡里插附件条与产物卡
    item = V.find(root, 'message-item')
    if item:
        bubble = None
        for n in V.walk(item):
            props = n.get('props') or {}
            cls = props.get('class')
            if isinstance(cls, dict) and 'bubble: true' in str(cls.get('value', '')):
                bubble = n
                break
        if bubble:
            kids = bubble['children']
            if not V.find(root, 'msg-files'):
                content_idx = next((i for i, c in enumerate(kids)
                                    if isinstance(c.get('props'), dict) and c['props'].get('class') == 'bubble-content'), 0)
                kids.insert(content_idx + 1, msg_files())
            if not V.find(root, 'artifacts'):
                kids.append(artifacts())

    # 演示数据
    state = d.setdefault('state', {})
    state['attachments'] = V.js("""[
  { name: '成绩单-2024-2025.pdf', ext: 'PDF', size: '175.8 KB', note: '已读 3 段' },
  { name: '简历初稿.md', ext: 'MD', size: '74 B', note: '已读 8 段' }
]""")

    # 给第一条回答挂上产物（演示态）
    msgs = []
    try:
        msgs = json.loads(state['messages']['value'])
    except Exception:
        msgs = []
    if isinstance(msgs, list):
        for m in msgs:
            if m.get('role') == 'assistant':
                m['artifacts'] = [
                    {'name': '专插本准备清单.md', 'ext': 'MD', 'size': '697 B', 'items': '12 行', 'time': '11-12 22:34'},
                    {'name': '升学就业路径对照.csv', 'ext': 'CSV', 'size': '578 B', 'items': '4 行', 'time': '11-12 22:34'},
                ]
                break
        state['messages'] = V.js(json.dumps(msgs, ensure_ascii=False, indent=0))

    V.add_css(d, CSS_CHAT)
    V.save(CHAT, d)
    print('chat DSL patched, nodes =', len(list(V.walk(d['nodes']))))


def patch_layout():
    d = V.load(LAYOUT)
    root = d['nodes'][0]
    tools = V.find(root, 'tab-tools')
    if not tools:
        print('!! tab-tools not found')
        return
    if V.find(root, 'lang-btn'):
        return
    btn = V.el('button', cls='lang-btn', props={'type': 'button', 'title': '界面语言'}, children=[
        V.span('文', cls='lang-globe'),
        V.span('中', cls='lang-now'),
        V.span('›', cls='lang-chev'),
    ], events={'click': V.fn(
        "() => {\n  this.$message.info('界面语言：简体中文 / English（英文界面下资料正文仍是中文原文）');\n}")})
    tools['children'].insert(0, btn)
    V.add_css(d, CSS_LANG)
    V.save(LAYOUT, d)
    print('layout DSL patched, nodes =', len(list(V.walk(d['nodes']))))


CSS_CHAT = r'''
/* 附件区 */
.attach-tray { display: flex; flex-direction: column; gap: 7px; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; }
.file-chip {
  display: flex; align-items: flex-start; gap: 7px; max-width: 264px;
  padding: 6px 7px; border: 1px solid #e8ebf0; border-radius: 8px; background: #fafbfd;
}
.fc-ico {
  width: 22px; height: 22px; flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center;
  border-radius: 5px; background: #eef3ff; color: #2f6bff; font-size: 9px; font-weight: 700;
}
.fc-main { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.fc-name { font-size: 12px; color: #1f2733; max-width: 178px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.fc-meta { font-size: 10.5px; color: #98a1b0; font-variant-numeric: tabular-nums; }
.fc-meta .sep { color: #d0d6e0; }
.fc-st { color: #2c8a4b; }
.fc-x { flex-shrink: 0; border: none; background: transparent; color: #b6bec9; font-size: 14px; cursor: pointer; }
.tray-foot { display: flex; align-items: center; gap: 8px; }
.tray-btn {
  display: inline-flex; align-items: center; gap: 4px; height: 26px; padding: 0 9px;
  border: 1px dashed #d8dee8; border-radius: 7px; background: #fff; color: #5a6473; font-size: 12px; cursor: pointer;
}
.tb-ico { font-size: 12px; }
.tb-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 15px; height: 15px; padding: 0 4px; border-radius: 999px;
  background: #eef3ff; color: #2f6bff; font-size: 10px;
}
.tray-note { font-size: 10.5px; color: #b0b8c4; }
.tray-clear { margin-left: auto; font-size: 10.5px; color: #98a1b0; text-decoration: underline dotted; cursor: pointer; }

/* 语音按钮 */
.voice-btn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; padding: 0; border: 1px solid #e3e8ef; border-radius: 50%;
  background: #fff; color: #6b7585; cursor: pointer;
  transition: color .16s cubic-bezier(.2,.8,.2,1), border-color .16s cubic-bezier(.2,.8,.2,1);
}
.voice-btn:hover { color: #2f6bff; border-color: #c3d3fb; background: #f6f9ff; }

/* 用户气泡下的附件条 */
.msg-files { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 8px; }
.mf-item {
  display: inline-flex; align-items: center; gap: 5px; padding: 3px 7px 3px 4px;
  border: 1px solid #e6ecf7; border-radius: 6px; background: #f8faff; font-size: 11px; color: #4a5566;
}
.mf-ico {
  display: inline-flex; align-items: center; justify-content: center;
  width: 18px; height: 16px; border-radius: 3px; background: #e8f0ff; color: #2f6bff;
  font-size: 8px; font-weight: 700;
}
.mf-chunks { color: #a3acba; font-variant-numeric: tabular-nums; }

/* 产物卡 */
.artifacts { margin-top: 12px; padding-top: 10px; border-top: 1px dashed #e9edf3; }
.art-head { display: flex; align-items: center; gap: 6px; margin-bottom: 7px; }
.art-title { font-size: 11px; font-weight: 600; letter-spacing: .06em; color: #8a94a6; }
.art-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 15px; height: 15px; padding: 0 4px; border-radius: 999px;
  background: #eef3ff; color: #2f6bff; font-size: 10px;
}
.art-list { display: flex; flex-direction: column; gap: 6px; }
.art-card {
  display: flex; align-items: center; gap: 9px; padding: 8px 9px;
  border: 1px solid #e9edf3; border-radius: 9px; background: #fff;
  animation: artIn .24s cubic-bezier(.2,.8,.2,1) both;
}
.art-ico {
  flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center;
  width: 30px; height: 30px; border-radius: 7px;
  background: #eef3ff; color: #2f6bff; font-size: 9px; font-weight: 700;
}
.art-main { flex: 1; min-width: 0; }
.art-name { font-size: 12.5px; color: #1f2733; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.art-meta { display: flex; align-items: center; gap: 5px; margin-top: 2px; font-size: 10.5px; color: #98a1b0; }
.art-meta .sep { color: #ccd3dd; }
.art-acts { display: flex; gap: 4px; }
.aa { height: 24px; padding: 0 8px; border: 1px solid #e6eaf1; border-radius: 6px; background: #fff; color: #5a6473; font-size: 11px; cursor: pointer; }
.aa.primary { color: #2f6bff; border-color: #c9d8fb; background: #f4f8ff; }
.art-note { display: block; margin-top: 6px; font-size: 10px; color: #b6bec9; }
@keyframes artIn { from { opacity: 0; transform: translateY(4px); } }
@media (prefers-reduced-motion: reduce) { .art-card { animation: none; } }
'''

CSS_LANG = r'''
.lang-btn {
  display: inline-flex; align-items: center; gap: 5px; height: 26px; padding: 0 8px 0 6px;
  margin-right: 6px; border: 1px solid #e6e9ee; border-radius: 7px; background: #fff;
  color: #4a5566; font-size: 12px; cursor: pointer;
  transition: color .16s cubic-bezier(.2,.8,.2,1), border-color .16s cubic-bezier(.2,.8,.2,1), background .16s cubic-bezier(.2,.8,.2,1);
}
.lang-btn:hover { color: #2f6bff; border-color: #b9cdfd; background: #f4f7ff; }
.lang-globe {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; border-radius: 4px;
  background: #eef3ff; color: #2f6bff; font-size: 10px; font-weight: 600;
}
.lang-now { font-variant-numeric: tabular-nums; }
.lang-chev { font-size: 11px; opacity: .5; }
'''

if __name__ == '__main__':
    patch_chat()
    patch_layout()
