# -*- coding: utf-8 -*-
"""N4/N8：对话页改成学生入口 —— 开场三问 + 政策固定结尾 + 未覆盖兜底。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, p, h2, js, fn, d_for, d_if, d_else, d_model

FAQ = """[
  {
    id: 'a-zsb',
    keys: ['专插本', '升本', '插本', '升学'],
    content: '按 A 组《高职学生升学与就业路径选择指南》：专插本面向应届高职毕业生，一般要求能如期毕业、在校期间无在校违纪记录；考试科目通常是 2 门公共课加 1 门专业基础课，具体科目由当年省考试院通知确定。\\n\\n你现在大一、计算机应用技术，能提前动的有三件：高数和英语的底子别断；专业课绩点稳在专业前 40%；大二下开始按目标院校的考试科目刷题。\\n\\n今年的报名时间、招生院校和计划数，知识库里没有收录，我不给具体日期 —— 这块要看你所在省考试院当年发布的招生工作通知。',
    sources: [
      { title: '《高职学生升学与就业路径选择指南》', group: 'A 组 · 专业与岗位', date: '2025-03-10' },
      { title: '《专插本考试科目说明（校内整理）》', group: 'B 组 · 证书与考试', date: '2025-02-28' }
    ],
    footer: '以上政策信息来自《高职学生升学与就业路径选择指南》，生效日期 2025-03-10，请以官方最新通知为准。'
  },
  {
    id: 'a-job',
    keys: ['哪些岗位', '什么岗位', '就业', '找工作', '对口', '能去'],
    content: '按 C 组「计算机应用技术 · 对口岗位」，匹配度参考值靠前的有 4 个方向：Java 后端开发（初级）、Web 前端开发、软件测试、IT 运维。\\n\\n这四个岗位的共同门槛是：能独立跑起来一个小项目、会用 Git、看得懂报错。学历要求基本是大专起，更看项目。\\n\\n起薪这块，只有软件测试和 IT 运维有本校近两届的回收样本（9 条和 6 条）；Java 后端和 Web 前端样本不足 5 条，我不给区间 —— 样本太少的数字看着像真的，其实是编的。',
    sources: [
      { title: '《计算机应用技术专业对口岗位表》', group: 'C 组 · 岗位与能力', date: '2025-03-08' },
      { title: '《2024 届毕业生就业质量回收样本》', group: 'D 组 · 行业与就业数据', date: '2025-01-15' }
    ],
    footer: ''
  },
  {
    id: 'a-prep',
    keys: ['先准备', '大一', '该学什么', '从哪开始'],
    content: '大一只用干两件事，别贪多。\\n\\n第一件，把一门语言学通到能写增删改查。计算机应用技术走 Java 或前端都行，选一个，别同时开两个。目标很具体：能自己写出一个带数据库的小系统，能讲清哪一行在干什么。\\n\\n第二件，绩点别掉。专插本看绩点，就业看能不能过简历初筛，两头都用得上。\\n\\nC 组里列了大一这一年的三个动作，你可以直接对着「路线图」勾：语言基础课、每周固定上机、一个能跑的小练习。',
    sources: [
      { title: '《计算机应用技术专业对口岗位表》', group: 'C 组 · 岗位与能力', date: '2025-03-08' },
      { title: '《高职学生成长路线图模板》', group: 'A 组 · 专业与岗位', date: '2025-03-05' }
    ],
    footer: ''
  },
  {
    id: 'a-cv',
    keys: ['简历', '实习', '面试', '项目经历'],
    content: '按 E 组《求职简历撰写与面试表达》：没有实习经历时，项目区用「课程项目 + 竞赛 + 自己练的」三块填，不要空着。\\n\\n写法上一句一个动作。写「用 Vue 做了个图书管理页面，能增删改查，代码在 GitHub」比写「熟悉前端」有用得多 —— 前者能被追问，后者只能被跳过。\\n\\n面试最常问的三个问题也在 E 组里：为什么选这个方向、遇到过什么坑怎么解决的、最近在学什么。这三个各准备两分钟，比背八股有效。',
    sources: [
      { title: '《求职简历撰写与面试表达》', group: 'E 组 · 求职技能', date: '2025-03-06' }
    ],
    footer: ''
  }
]"""

MISS = ('这个问题现有资料未覆盖。\\n\\nA–E 五组知识库里没有收录相关内容，我不能凭印象给你答案。\\n\\n'
        '建议换一种问法：问具体专业、具体岗位或具体政策名；也可以去左侧「知识库」按分组自己找一遍。'
        '如果是要报名、交材料这类必须准确的事，直接问辅导员或学校招生就业处。')

# ================= ChatWorkspace：数据与回答逻辑 =================
WS = 'kr0dwyr8'
data = vtj.load(WS)

data['refs'] = {'faq': js(FAQ)}

data['state'] = {
    'messages': js('[]'),
    'streaming': js('false'),
    'toolStatus': js("''"),
    'references': js('[]'),
    'sessions': js("""[
  { id: 's1', title: '专插本要什么条件', status: 'active', statusText: '进行中', updatedAt: '10:24' },
  { id: 's2', title: '计算机应用技术能去哪些岗位', status: 'done', statusText: '已完成', updatedAt: '昨天' },
  { id: 's3', title: '大一该先准备什么', status: 'done', statusText: '已完成', updatedAt: '周二' },
  { id: 's4', title: '简历没项目经历怎么写', status: 'pending', statusText: '待处理', updatedAt: '周一' }
]"""),
    'profile': js("""({
  name: '李同学',
  major: '计算机应用技术',
  grade: '大一',
  goal: '还没定：专插本 / 就业',
  dims: []
})"""),
}

data['computed'] = {}
data['reactives'] = {}

data['methods'] = {
    'handleStop': fn("""() => {
  this.streaming.value = false;
  this.toolStatus.value = '';
}"""),
    'handleSend': fn("""(text) => {
  const q = String(text || '').trim();
  if (!q) return;
  this.messages.value.push({ id: 'u-' + Date.now(), role: 'user', content: q });
  this.streaming.value = true;
  this.toolStatus.value = 'W-M1 意图分流…';
  setTimeout(() => {
    this.toolStatus.value = 'U2 分组检索 A–E · U3 来源挂载…';
  }, 500);
  setTimeout(() => {
    const hit = this.faq.value.find((item) => item.keys.some((k) => q.indexOf(k) > -1));
    this.streaming.value = false;
    this.toolStatus.value = '';
    if (!hit) {
      this.messages.value.push({
        id: 'a-' + Date.now(),
        role: 'assistant',
        miss: true,
        content: MISS_TEXT,
        sources: []
      });
      this.references.value = [];
      return;
    }
    this.messages.value.push({
      id: 'a-' + Date.now(),
      role: 'assistant',
      content: hit.content,
      sources: hit.sources,
      footer: hit.footer
    });
    this.references.value = hit.sources.map((s, i) => ({
      id: 'r' + i,
      title: s.title,
      group: s.group,
      date: s.date,
      excerpt: '摘自' + s.group + '，' + s.date + ' 入库，可去「知识库」看原文。'
    }));
  }, 1100);
}""".replace('MISS_TEXT', repr(MISS).replace("'", '"'))),
}

session_list = el('SessionList', 'session-col', [], frm={'id': '5r0c26ix', 'type': 'Schema'},
                  props={'sessions': js('this.sessions')})
chat_panel = el('ChatPanel', 'chat-main', [], frm={'id': '8r0cd8oa', 'type': 'Schema'},
                props={'messages': js('this.messages'),
                       'streaming': js('this.streaming'),
                       'tool-status': js('this.toolStatus')},
                events={'send': {'name': 'send', 'handler': js('this.handleSend'), 'modifiers': {}},
                        'stop': {'name': 'stop', 'handler': js('this.handleStop'), 'modifiers': {}}})
ref_panel = el('ReferencePanel', 'ref-col', [], frm={'id': 'br0cz38c', 'type': 'Schema'},
               props={'references': js('this.references'), 'profile': js('this.profile')})

data['nodes'] = [div('chat-page', [session_list, chat_panel, ref_panel])]

data['css'] = """.chat-page {
  flex: 1;
  min-width: 0;
  display: flex;
  gap: 12px;
  padding: 12px;
  box-sizing: border-box;
  height: 100%;
}
.session-col { width: 216px; flex-shrink: 0; min-height: 0; }
.chat-main { flex: 1; min-width: 0; min-height: 0; }
.ref-col { width: 332px; flex-shrink: 0; min-height: 0; }
@media (max-width: 1320px) {
  .session-col { display: none; }
  .ref-col { width: 288px; }
}
@media (max-width: 1100px) {
  .chat-page { flex-direction: column; height: auto; }
  .ref-col { width: 100%; }
}
"""
vtj.save(WS, data)
print('workspace ok')

# ================= ChatPanel：开场三问 + 气泡三态 =================
CP = '8r0cd8oa'
cp = vtj.load(CP)

def select(model, placeholder, options):
    return el('ElSelect', 'opener-select', [
        el('ElOption', None, [], frm='element-plus', props={'label': o, 'value': o}) for o in options
    ], frm='element-plus', props={'placeholder': placeholder},
        directives=[d_model(model)])

def chip(label):
    return el('button', 'chip', text=label,
              events={'click': {'name': 'click',
                                'handler': js("this.handleQuick('%s')" % label),
                                'modifiers': {}}})

opener = div('opener', [
    el('h2', 'opener-title', text='你好，我是路书'),
    el('p', 'opener-lede', text='我能做三件事：陪你认识自己（12 道自评）、看清本专业的岗位与三条路、把目标拆成按学期的路线图。'),
    el('p', 'opener-lede', text='我只回答知识库里有的内容。没收录的会直接说「现有资料未覆盖」，不猜；政策类会给出来源和生效日期，仅供参考。'),
    div('opener-form', [
        select('this.major.value', '你的专业', ['计算机应用技术', '电子商务', '其他专业']),
        select('this.grade.value', '你的年级', ['大一', '大二', '大三']),
        select('this.aim.value', '现在最想解决', ['不知道往哪走', '想确认能去哪些岗位', '想准备专插本', '想找实习、改简历']),
        el('ElButton', 'opener-start', text='开始', frm='element-plus', props={'type': 'primary'},
           events={'click': {'name': 'click', 'handler': js('this.handleStart'), 'modifiers': {}}}),
    ]),
    div('chips', [chip('专插本报名要什么条件'),
                  chip('计算机应用技术能去哪些岗位'),
                  chip('大一该先准备什么'),
                  chip('简历没项目经历怎么写')]),
], directives=[d_if('this.messages.length === 0')])

bubble = el('div', None, [
    div('bubble-content', expr='this.context.msg.content'),
    div('sources', [
        el('div', 'ref-title', text='📚 来源'),
        div('ref-item', [
            span(expr='this.context.src.title'),
            span(expr="this.context.src.group + ' · ' + this.context.src.date", cls='ref-meta'),
        ], directives=[d_for('this.context.msg.sources', 'src')]),
    ], directives=[d_if('this.context.msg.sources && this.context.msg.sources.length')]),
    el('div', 'policy-footer', [span(expr='this.context.msg.footer')],
       directives=[d_if('this.context.msg.footer')]),
], props={'class': js("Object.assign({ bubble: true }, { miss: !!this.context.msg.miss })")})

msg_item = div('message-item', [
    div('avatar', expr="this.context.msg.role === 'user' ? '我' : '路'"),
    bubble,
], directives=[d_for('this.messages', 'msg')])

cp['refs'] = {'inputText': js("''"), 'major': js("'计算机应用技术'"), 'grade': js("'大一'"), 'aim': js("''")}
cp['state'] = {}
cp['computed'] = {}
cp['methods'] = {
    'handleSend': fn("""() => {
  const text = this.inputText.value.trim();
  if (!text || this.streaming) return;
  this.$emit('send', text);
  this.inputText.value = '';
}"""),
    'handleStop': fn("() => {\n  this.$emit('stop');\n}"),
    'handleQuick': fn("(text) => {\n  if (this.streaming) return;\n  this.$emit('send', text);\n}"),
    'handleStart': fn("""() => {
  const major = this.major.value || '我的专业';
  const grade = this.grade.value || '现在';
  const aim = this.aim.value || '不知道往哪走';
  this.$emit('send', '我是' + major + '的' + grade + '学生，现在最想解决的问题是：' + aim);
}"""),
}

cp['nodes'] = [div('chat-panel', [
    div('chat-header', [
        div('header-left', [
            span('对话', cls='header-title'),
            span('只回答知识库里有的 · 没收录的直接说', cls='header-subtitle'),
        ]),
        div('header-actions', [
            span('生成中…', cls='header-status', directives=[d_if('this.streaming')]),
        ]),
    ]),
    div('message-list', [opener, msg_item]),
    div('input-area', [
        el('textarea', 'input-textarea', [],
           props={'rows': '2', 'placeholder': '问专业、问岗位、问升学政策都行'},
           directives=[d_model('this.inputText.value')]),
        div('input-actions', [
            span('Enter 发送 · Shift + Enter 换行', cls='input-tip'),
            el('button', 'send-btn', text='发送',
               events={'click': {'name': 'click', 'handler': js('this.handleSend'), 'modifiers': {}}},
               directives=[d_if('!this.streaming')]),
            el('button', 'stop-btn', text='停止',
               events={'click': {'name': 'click', 'handler': js('this.handleStop'), 'modifiers': {}}},
               directives=[d_else()]),
        ]),
    ]),
])]

vtj.add_css(cp, """
.opener { padding: 6px 2px 0; }
.opener-title { font-size: 19px; font-weight: 600; color: #1f2937; margin: 0 0 10px; }
.opener-lede { font-size: 13px; line-height: 1.8; color: #4b5563; margin: 0 0 8px; }
.opener-form { display: flex; flex-wrap: wrap; gap: 8px; margin: 18px 0 12px; }
.opener-select { width: 148px; }
.chips { display: flex; flex-wrap: wrap; gap: 8px; }
.chip {
  padding: 6px 12px; border: 1px solid #e5e7eb; border-radius: 16px;
  background: #fff; color: #374151; font-size: 12.5px; cursor: pointer; transition: all .15s ease;
}
.chip:hover { border-color: #2f6bff; color: #2f6bff; background: #f4f7ff; }
.sources { margin-top: 10px; padding-top: 8px; border-top: 1px dashed #e5e7eb; }
.sources .ref-title { font-size: 11.5px; color: #9ca3af; margin-bottom: 4px; }
.sources .ref-item { font-size: 12px; color: #2f6bff; line-height: 1.75; }
.sources .ref-meta { margin-left: 6px; color: #9ca3af; font-size: 11px; }
.policy-footer {
  margin-top: 10px; padding: 8px 10px; background: #f7f8fa; border-left: 3px solid #d1d5db;
  border-radius: 4px; font-size: 11.5px; line-height: 1.7; color: #6b7280;
}
.bubble.miss { background: #fffdf7; border: 1px dashed #ffd591; }
.bubble.miss .bubble-content { color: #8a4b00; }
""")
vtj.save(CP, cp)
print('chat panel ok')
