# -*- coding: utf-8 -*-
"""m3：对话页 —— 三档视图、检索链步进、toast 轻提示"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_if

d = vtj.load('kr0dwyr8')

# ---- state ----
st = d['state']
st.pop('toolStatus', None)
st['toolStep'] = js('-1')
st['showSessions'] = js('true')
st['showRefs'] = js('true')
st['toastMsg'] = js("''")

# ---- methods ----
d['methods']['showToast'] = fn(
    "(text) => {\n"
    "  this.toastMsg.value = text;\n"
    "  const self = this;\n"
    "  setTimeout(() => { self.toastMsg.value = ''; }, 2400);\n"
    "}"
)

d['methods']['handleCopy'] = fn(
    "(item) => {\n"
    "  const text = '《' + item.title + '》 ' + item.group + ' · ' + item.date;\n"
    "  try {\n"
    "    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text);\n"
    "  } catch (e) {}\n"
    "  this.showToast('已复制这条来源，可以贴进笔记里');\n"
    "}"
)

d['methods']['handleSend'] = fn(
    "(text) => {\n"
    "  const q = String(text || '').trim();\n"
    "  if (!q) return;\n"
    "  const self = this;\n"
    "  this.messages.value.push({ id: 'u-' + Date.now(), role: 'user', content: q });\n"
    "  this.streaming.value = true;\n"
    "  this.toolStep.value = 0;\n"
    "  [1, 2, 3].forEach((step, i) => {\n"
    "    setTimeout(() => {\n"
    "      if (self.streaming.value) self.toolStep.value = step;\n"
    "    }, 380 * (i + 1));\n"
    "  });\n"
    "  setTimeout(() => {\n"
    "    if (!self.streaming.value) return;\n"
    "    const hit = self.faq.value.find((item) => item.keys.some((k) => q.indexOf(k) > -1));\n"
    "    self.streaming.value = false;\n"
    "    self.toolStep.value = -1;\n"
    "    if (!hit) {\n"
    "      self.messages.value.push({\n"
    "        id: 'a-' + Date.now(),\n"
    "        role: 'assistant',\n"
    "        miss: true,\n"
    "        content: self.missText.value,\n"
    "        sources: []\n"
    "      });\n"
    "      self.references.value = [];\n"
    "      return;\n"
    "    }\n"
    "    self.messages.value.push({\n"
    "      id: 'a-' + Date.now(),\n"
    "      role: 'assistant',\n"
    "      content: hit.content,\n"
    "      sources: hit.sources,\n"
    "      footer: hit.footer\n"
    "    });\n"
    "    self.references.value = hit.sources.map((s, i) => ({\n"
    "      id: 'r' + i,\n"
    "      title: s.title,\n"
    "      group: s.group,\n"
    "      date: s.date,\n"
    "      excerpt: '摘自' + s.group + '，' + s.date + ' 入库，可去「知识库」看原文。'\n"
    "    }));\n"
    "  }, 1520);\n"
    "}"
)

d['methods']['handleStop'] = fn(
    "() => {\n"
    "  this.streaming.value = false;\n"
    "  this.toolStep.value = -1;\n"
    "}"
)

# ---- 未覆盖文案提到 refs 里，供方法引用 ----
if 'missText' not in d['refs']:
    d['refs']['missText'] = js(
        "'这个问题现有资料未覆盖。\\n\\nA–E 五组知识库里没有收录相关内容，我不能凭印象给你答案。\\n\\n"
        "建议换一种问法：问具体专业、具体岗位或具体政策名；也可以去左侧「知识库」按分组自己找一遍。"
        "如果是要报名、交材料这类必须准确的事，直接问辅导员或学校招生就业处。'"
    )

root = d['nodes'][0]
root['props']['class'] = js(
    "Object.assign({ 'chat-page': true }, { 'hide-sessions': !this.showSessions.value, 'hide-refs': !this.showRefs.value })"
)

# ---- ChatPanel: 换 prop、加事件 ----
for c in root['children']:
    if c.get('name') == 'ChatPanel':
        p = c['props']
        p.pop('tool-status', None)
        p['toolStep'] = js('this.toolStep.value')
        p['showSessions'] = js('this.showSessions.value')
        p['showRefs'] = js('this.showRefs.value')
        c['events']['toggleSessions'] = {
            'name': 'toggleSessions',
            'handler': js('this.showSessions.value = !this.showSessions.value'),
            'modifiers': {},
        }
        c['events']['toggleRefs'] = {
            'name': 'toggleRefs',
            'handler': js('this.showRefs.value = !this.showRefs.value'),
            'modifiers': {},
        }
    if c.get('name') == 'ReferencePanel':
        c['events']['copy'] = {
            'name': 'copy',
            'handler': js('this.handleCopy'),
            'modifiers': {},
        }

# ---- toast 节点 ----
root['children'].append(
    div(expr='this.toastMsg.value', cls='motion-toast', directives=[d_if('this.toastMsg.value')])
)

vtj.save('kr0dwyr8', d)
print('kr0dwyr8 ok')
