# -*- coding: utf-8 -*-
"""N1/N2/N12：侧栏按「学生自用」重排，教师入口折叠并标注。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

NAME = '2r0c0a38'
data = vtj.load(NAME)

STUDENT = [
    ('对话', '/page/chat-workspace', 'ChatDotRound'),
    ('认识自己', '/page/self-assessment', 'EditPen'),
    ('看清路', '/page/career-library', 'DataAnalysis'),
    ('路线图', '/page/growth-plan', 'Document'),
    ('知识库', '/page/knowledge-base', 'Collection'),
]
TEACHER = [
    ('调用日志', '/page/call-logs', 'Setting'),
    ('知识库管理', '/page/kb-manager', 'User'),
]

def nav_arr(items):
    rows = []
    for label, route, icon in items:
        rows.append("  { label: '%s', route: '%s', icon: this.$libs.VtjIcons.%s }" % (label, route, icon))
    return '[\n' + ',\n'.join(rows) + '\n]'

data['refs'] = {
    'navItems': js(nav_arr(STUDENT)),
    'teacherNav': js(nav_arr(TEACHER)),
    'teacherOpen': js('false'),
}

data['reactives'] = {
    'currentUser': js("({ name: '李同学', role: '计算机应用技术 · 大一', avatarText: '李' })"),
}

data['methods'] = {
    'isActive': fn("(route) => {\n  return this.$route.path === route;\n}"),
    'handleNav': fn("(route) => {\n  if (this.$route.path !== route) {\n    this.$router.push(route);\n  }\n}"),
    'toggleTeacher': fn("() => {\n  this.teacherOpen.value = !this.teacherOpen.value;\n}"),
    'handleLogout': fn("() => {\n  this.$router.push('/page/login');\n}"),
}

# ---- 导航项复用模板 ----
def nav_item(expr, active_from):
    props = {
        'key': js('this.context.item.route'),
        'class': js("Object.assign(\n  { 'nav-item': true },\n  { active: this.isActive(this.context.item.route) }\n)"),
    }
    node = div(None, [
        el('component', 'nav-icon', [], props={'is': js('this.context.item.icon')}),
        span(expr=expr),
    ], props=props,
        events={'click': {'name': 'click',
                          'handler': js('this.handleNav(this.context.item.route)'),
                          'modifiers': {}}},
        directives=[d_for(active_from, 'item')])
    return node

root = data['nodes'][0]
root['children'] = [
    div('brand', [
        div('brand-logo', text='路'),
        div('brand-info', [
            div('brand-name', text='路书工作台'),
            div('brand-sub', text='你自己的职业规划助手'),
        ]),
    ]),
    div('demo-chip', text='演示数据 · 正式版接 A–E 五组知识库'),
    el('nav', 'nav', [
        span('我用得到的', cls='nav-group-title'),
        nav_item('this.context.item.label', 'this.navItems.value'),
        el('div', 'nav-group-title teacher-toggle',
           children=[
               span(text='教师入口'),
               span(text='学生不可见 · 点击展开', cls='teacher-note'),
           ],
           events={'click': {'name': 'click', 'handler': js('this.toggleTeacher'), 'modifiers': {}}}),
        el('div', 'teacher-block', [
            div('teacher-hint', text='这两页是给老师看链路和维护知识库的，学生端不显示。'),
            nav_item('this.context.item.label', 'this.teacherNav.value'),
        ], directives=[d_if('this.teacherOpen.value')]),
    ]),
    div('current-user', [
        div('user-avatar', expr='this.currentUser.avatarText'),
        div('user-info', [
            div('user-name', expr='this.currentUser.name'),
            div('user-role', expr='this.currentUser.role'),
        ]),
    ]),
]

vtj.add_css(data, """
.demo-chip {
  margin: 10px 12px 0;
  padding: 6px 10px;
  background: #fff7e6;
  border: 1px solid #ffe0a3;
  border-radius: 6px;
  font-size: 11px;
  line-height: 1.5;
  color: #a86a00;
}
.nav-group-title {
  display: block;
  padding: 12px 12px 6px;
  font-size: 11px;
  letter-spacing: .5px;
  color: #9ca3af;
}
.teacher-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  margin-top: 6px;
  border-top: 1px dashed #eef0f3;
  padding-top: 14px;
}
.teacher-toggle .teacher-note {
  font-size: 10.5px;
  color: #b9bdc4;
  letter-spacing: 0;
}
.teacher-block {
  padding: 0 0 6px;
}
.teacher-hint {
  padding: 0 12px 8px;
  font-size: 11px;
  line-height: 1.6;
  color: #9ca3af;
}
.nav-item.subtle {
  color: #6b7280;
}
""")

vtj.save(NAME, data)
print('sidebar patched; refs:', list(data['refs'].keys()))
