# -*- coding: utf-8 -*-
"""m6：调用日志页整体对齐运行版 —— 统计卡带脚注、覆盖度说明、活跃热力图、命中分组占比"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

d = vtj.load('wr0ea12x')

# ---------- state ----------
d['state'] = {
    'onlyAbnormal': js("'全部'"),
    'covOpen': js('false'),
    'refreshing': js('false'),
    'updatedAt': js("'10:34'"),
    'stats': js(
        "[\n"
        "  { label: '今日调用', value: '128', foot: '其中 3 条未计入', tone: '' },\n"
        "  { label: '平均响应', value: '1.8s', foot: 'P95 3.4s', tone: '' },\n"
        "  { label: '知识命中率', value: '62%', foot: '兜底占 31%', tone: '' },\n"
        "  { label: '无出处拦截', value: '9', foot: '终审删句合计 14 处', tone: 'warn' },\n"
        "  { label: '安全熔断', value: '2', foot: 'W-L0 · 已转人工', tone: 'danger' }\n]"
    ),
    'hourLabels': js("['00', '04', '08', '12', '16', '20']"),
    'heat': js(
        "[\n"
        "  [0,0,1,0,0,1,0,0,1,0,0,0,1,0],\n"
        "  [0,0,0,1,0,0,0,1,0,0,0,0,0,1],\n"
        "  [1,2,2,3,1,2,3,4,3,2,1,2,3,2],\n"
        "  [2,3,4,4,2,3,4,4,4,3,2,3,4,3],\n"
        "  [1,2,3,4,3,2,4,4,3,4,2,3,3,4],\n"
        "  [0,1,2,2,3,1,2,3,2,2,1,2,3,2]\n]"
    ),
    'groups': js(
        "[\n"
        "  { key: 'a', name: 'A 组 · 专业与岗位', count: 34, pct: 27 },\n"
        "  { key: 'b', name: 'B 组 · 证书与考试', count: 12, pct: 9 },\n"
        "  { key: 'c', name: 'C 组 · 岗位与能力', count: 38, pct: 30 },\n"
        "  { key: 'd', name: 'D 组 · 行业与就业数据', count: 15, pct: 12 },\n"
        "  { key: 'e', name: 'E 组 · 求职技能', count: 9, pct: 7 },\n"
        "  { key: 'miss', name: '未命中 · 走兜底', count: 20, pct: 15 }\n]"
    ),
}

LOG_ROWS = (
    "[\n"
    "  { id: 1, time: '2025-03-13 10:32:18', user: '李同学', question: '专插本报名要什么条件', intent: 'W-M1 升学政策', groups: 'A 组 ×2', verdict: '只查不改 · 通过', status: '正常' },\n"
    "  { id: 2, time: '2025-03-13 10:31:05', user: '陈同学', question: '计算机应用技术能去哪些岗位', intent: 'W-M1 职业认知', groups: 'C 组 ×2 · D 组 ×1', verdict: '删 1 条无出处', status: '正常' },\n"
    "  { id: 3, time: '2025-03-13 10:29:47', user: '王同学', question: '跨境电商薪资多少', intent: 'W-M1 职业认知', groups: 'D 组（样本 4）', verdict: '降级为未覆盖', status: '未覆盖兜底' },\n"
    "  { id: 4, time: '2025-03-13 10:28:33', user: '李同学', question: '大一该先准备什么', intent: 'W-M1 成长计划', groups: 'A 组 ×2 · C 组 ×1', verdict: '只查不改 · 通过', status: '正常' },\n"
    "  { id: 5, time: '2025-03-13 10:15:12', user: '刘同学', question: '考编要考什么科目', intent: 'W-M1 升学政策', groups: '—', verdict: '短路 · 未检索', status: '未覆盖兜底' },\n"
    "  { id: 6, time: '2025-03-13 09:58:40', user: '张同学', question: '不想读了，觉得没意义', intent: 'W-L0 安全熔断', groups: '—', verdict: '短路 · 转人工', status: '安全熔断' },\n"
    "  { id: 7, time: '2025-03-13 09:45:03', user: '陈同学', question: '简历没项目经历怎么写', intent: 'W-M1 求职技能', groups: 'E 组 ×2', verdict: '只查不改 · 通过', status: '正常' },\n"
    "  { id: 8, time: '2025-03-13 09:30:27', user: '王同学', question: '这个专业是不是没前途', intent: 'W-M1 职业认知', groups: '—', verdict: '拦截 · 无出处', status: '无出处拦截' }\n]"
)
d['state']['logs'] = js(LOG_ROWS)

# ---------- computed ----------
d['computed'] = {
    'filteredLogs': fn(
        "() => {\n"
        "  if (this.state.onlyAbnormal === '全部') return this.state.logs;\n"
        "  return this.state.logs.filter((l) => l.status === this.state.onlyAbnormal);\n"
        "}"
    ),
    'heatCells': fn(
        "() => {\n"
        "  const out = [];\n"
        "  const H = this.state.heat;\n"
        "  const L = this.state.hourLabels;\n"
        "  for (let d = 0; d < 14; d++) {\n"
        "    for (let h = 0; h < 6; h++) {\n"
        "      out.push({\n"
        "        i: d * 6 + h,\n"
        "        lv: H[h][d],\n"
        "        label: '第 ' + (d + 1) + ' 天 · ' + L[h] + ':00 时段 · ' + (H[h][d] * 7) + ' 次'\n"
        "      });\n"
        "    }\n"
        "  }\n"
        "  return out;\n"
        "}"
    ),
}

# ---------- methods ----------
d['methods'] = {
    'intentType': fn(
        "(s) => {\n"
        "  if (s.indexOf('W-L0') > -1) return 'danger';\n"
        "  if (s.indexOf('升学') > -1) return 'warning';\n"
        "  if (s.indexOf('成长') > -1) return 'info';\n"
        "  return 'primary';\n"
        "}"
    ),
    'statusType': fn(
        "(s) => {\n"
        "  if (s === '正常') return 'success';\n"
        "  if (s === '未覆盖兜底') return 'warning';\n"
        "  if (s === '安全熔断') return 'danger';\n"
        "  return 'info';\n"
        "}"
    ),
    'handleRefresh': fn(
        "() => {\n"
        "  if (this.state.refreshing) return;\n"
        "  this.state.refreshing = true;\n"
        "  const self = this;\n"
        "  setTimeout(() => {\n"
        "    self.state.refreshing = false;\n"
        "    const t = new Date();\n"
        "    const pad = (n) => String(n).padStart(2, '0');\n"
        "    self.state.updatedAt = pad(t.getHours()) + ':' + pad(t.getMinutes());\n"
        "  }, 700);\n"
        "}"
    ),
    'toggleCov': fn("() => {\n  this.state.covOpen = !this.state.covOpen;\n}"),
}

# ---------- 节点 ----------
STATUS_OPTS = ['全部状态', '只看正常', '只看未覆盖兜底', '只看无出处拦截', '只看安全熔断']
sel = el('ElSelect', 'sel', [], frm='element-plus',
         props={'modelValue': js('this.state.onlyAbnormal'), 'placeholder': '全部状态'},
         directives=[{'id': vtj.nid('d'), 'name': 'vModel',
                      'value': js('this.state.onlyAbnormal')}])
for o in STATUS_OPTS:
    val = '全部' if o == '全部状态' else o.replace('只看', '')
    sel['children'].append(el('ElOption', frm='element-plus', props={'label': o, 'value': val}))

header = div('page-header', [
    div('title-block', [
        div('side-note', '教师侧 · 学生不可见'),
        el('h2', None, '调用日志'),
        el('p', 'page-desc',
           '看每次回答走了哪条链路、命中几篇、终审删了什么。W-L0 是安全熔断，命中就短路转人工。'),
    ]),
    div('tools', [
        sel,
        el('button',
           js("Object.assign({ 'refresh-btn': true }, { spinning: this.state.refreshing })"),
           [span('↻', cls='rf-ico')],
           events={'click': {'name': 'click', 'handler': js('this.handleRefresh()'), 'modifiers': {}}}),
        span(expr="'更新于 ' + this.state.updatedAt", cls='refresh-at'),
    ]),
])

summary = div('summary', [
    div(
        js("'stat'"),
        [
            span(expr='this.context.s.label', cls='stat-label'),
            span(expr='this.context.s.value', cls=js("'stat-value ' + this.context.s.tone")),
            span(expr='this.context.s.foot', cls='stat-foot'),
        ],
        directives=[d_for('this.state.stats', 's', 'index')],
        style=js("'animation-delay: ' + (this.context.index * 45) + 'ms'"),
    )
])

coverage = div('coverage', [
    span(cls='cov-dot'),
    span('今日 128 次里有 <b>3 条未计入</b>（宿主会话格式不受支持），下表是其中 8 条抽样。'.replace('<b>', '').replace('</b>', ''), cls='cov-text'),
    el('button',
       expr="this.state.covOpen ? '收起' : '怎么算的'",
       cls='cov-toggle',
       events={'click': {'name': 'click', 'handler': js('this.toggleCov()'), 'modifiers': {}}}),
])

cov_detail = div('cov-detail',
                 '只统计能读通的会话：读失败、格式不支持、宿主没有会话接口的三类，单独列在覆盖度里，不按 0 计入，也不在数字前加「≥」假装成下界。全部读不过时这一栏显示「—」，宁可空着。',
                 directives=[d_if('this.state.covOpen')])

heat_card = div('card heat-card', [
    div('card-head', [
        span('活跃热力图', cls='card-title'),
        span('近 14 天 · 每格 4 小时', cls='card-sub'),
        span(cls='legend', children=[
            span('少', cls='lg-text'),
            el('i', 'hm-cell lv0'), el('i', 'hm-cell lv1'), el('i', 'hm-cell lv2'),
            el('i', 'hm-cell lv3'), el('i', 'hm-cell lv4'),
            span('多', cls='lg-text'),
        ]),
    ]),
    div('hm-body', [
        div('hm-axis-y', [span(expr='this.context.h', cls=None)],
            directives=[d_for('this.state.hourLabels', 'h', 'index')]),
        div('hm-wrap', [
            div('hm-grid', [
                el('i',
                   js("'hm-cell lv' + this.context.cell.lv"),
                   [],
                   props={'title': js('this.context.cell.label')},
                   style=js("'animation-delay: ' + (this.context.cell.i * 4) + 'ms'"))
            ], directives=[d_for('this.heatCells.value', 'cell', 'index')]),
            div('hm-axis-x', [span('02-28'), span('03-06'), span('03-13')]),
        ]),
    ]),
])

dist_card = div('card dist-card', [
    div('card-head', [
        span('命中分组分布', cls='card-title'),
        span('今日 128 次', cls='card-sub'),
    ]),
    div('stack', [
        span(cls=js("'stack-seg seg-' + this.context.index"),
             style=js("'width: ' + this.context.g.pct + '%; animation-delay: ' + (this.context.index * 70) + 'ms'"))
    ], directives=[d_for('this.state.groups', 'g', 'index')]),
    div('dist-list', [
        div('dist-row', [
            el('i', js("'dist-dot seg-' + this.context.index")),
            span(expr='this.context.g.name', cls='dist-name'),
            span(expr='this.context.g.count', cls='dist-num'),
            span(expr="this.context.g.pct + '%'", cls='dist-pct'),
        ], directives=[d_for('this.state.groups', 'g', 'index')]),
    ]),
])

insight = div('insight', [heat_card, dist_card])


def col(props, slot_children=None):
    node = el('ElTableColumn', frm='element-plus', props=props,
              children=slot_children or [])
    return node


def tag_col(label, width_expr, type_expr, text_expr):
    tag = el('ElTag', frm='element-plus',
             props={'size': 'small', 'type': js(type_expr)},
             expr=text_expr)
    holder = div(None, [tag])
    holder['slot'] = {'name': 'default', 'scope': 'scope', 'params': []}
    return el('ElTableColumn', frm='element-plus',
              props={'label': label, 'width': width_expr},
              children=[holder])


table = el('ElTable', frm='element-plus',
           props={'data': js('this.filteredLogs.value'), 'size': 'default', 'stripe': ''},
           children=[
               col({'prop': 'time', 'label': '调用时间', 'width': '176'}),
               col({'prop': 'user', 'label': '学生', 'width': '90'}),
               col({'prop': 'question', 'label': '学生的问题', 'min-width': '180'}),
               tag_col('W-M1 意图', '140', 'this.intentType(scope.row.intent)', 'scope.row.intent'),
               col({'prop': 'groups', 'label': '命中分组', 'width': '176'}),
               col({'prop': 'verdict', 'label': '终审 V1.1', 'min-width': '150'}),
               tag_col('状态', '110', 'this.statusType(scope.row.status)', 'scope.row.status'),
           ])

root = div('logs-page', [
    header,
    summary,
    coverage,
    cov_detail,
    insight,
    div('table-wrap', [table]),
    div('page-note',
        '下表是今日 8 条抽样，完整记录按日期分页。终审只有减法权：删掉没有出处的句子，不改写、不补充。这条记录里「删 1 条无出处」「降级为未覆盖」都是它干的。'),
])

d['nodes'] = [root]
vtj.save('wr0ea12x', d)
print('wr0ea12x ok, nodes', len(list(vtj.walk(d['nodes']))))
