# -*- coding: utf-8 -*-
"""
m8：给 MainLayout（hr0d0qx3）的 DSL 加「标签页条 + 命令面板 + 路由进度条」。

运行期那一版用的是独立的 TabBar.vue / CommandPalette.vue 组件；
但 DSL 页面只能引用材料库里注册过的组件，手写 .vue 不在里面，
所以这里把同样的结构用节点 + methods 就地搭出来，做到自包含、能导回编辑器。

两处刻意简化（PATCHES.md 里写明）：
  ① 下划线不做「滑动跟随」，改成 ::after 从左边长出来 —— 滑动要读 DOM offset，DSL 里没有稳定做法
  ② 标签不拖拽换位（运行期有）；拖拽要把 pointermove 绑到 window，会污染设计器

表达式口径：与 VTJ 自己生成的代码保持一致，模板和 methods 里都用 `this.xxx.value`。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_if, d_for, d_model

FID = 'hr0d0qx3'
d = vtj.load(FID)

# ── 1. 脚本层 ────────────────────────────────────────────────
d['state'] = {
    'tabs': {'type': 'JSExpression', 'value': "[{ path: '/page/chat-workspace', title: '对话' }]"},
    'current': {'type': 'JSExpression', 'value': "'/page/chat-workspace'"},
    'progressKey': {'type': 'JSExpression', 'value': '0'},
    'paletteOpen': {'type': 'JSExpression', 'value': 'false'},
    'paletteQuery': {'type': 'JSExpression', 'value': "''"},
}

d['refs'] = {
    'pageList': {'type': 'JSExpression', 'value': """[
  { path: '/page/chat-workspace', title: '对话', icon: '❝', desc: '提问 · 带出处的回答' },
  { path: '/page/self-assessment', title: '认识自己', icon: '✎', desc: '12 题 · 六维相对分' },
  { path: '/page/career-library', title: '看清路', icon: '◎', desc: '岗位卡 · 三条路径对比' },
  { path: '/page/growth-plan', title: '路线图', icon: '☰', desc: '目标一句话 · 学期任务' },
  { path: '/page/knowledge-base', title: '知识库', icon: '▤', desc: 'A–E 五组 37 篇' },
  { path: '/page/call-logs', title: '调用日志', icon: '≡', desc: '教师侧 · 意图与命中' },
  { path: '/page/kb-manager', title: '知识库管理', icon: '⚙', desc: '教师侧 · 入库与终审' }
]"""},
}

d['computed'] = {
    'paletteList': {'type': 'JSFunction', 'value': """() => {
  const q = String(this.paletteQuery.value || '').trim().toLowerCase();
  const all = this.pageList || [];
  if (!q) return all;
  const hit = (text) => {
    let i = 0;
    const t = String(text).toLowerCase();
    for (let k = 0; k < t.length && i < q.length; k++) {
      if (t[k] === q[i]) i++;
    }
    return i === q.length;
  };
  return all.filter((p) => hit(p.title + p.desc));
}"""},
}

d['methods'] = {
    'goTab': {'type': 'JSFunction', 'value': """(path) => {
  const tabs = this.tabs.value;
  this.current.value = path;
  if (!tabs.some((t) => t.path === path)) {
    const meta = (this.pageList || []).find((p) => p.path === path);
    tabs.push({ path: path, title: meta ? meta.title : '页面' });
  }
  this.progressKey.value = this.progressKey.value + 1;
  if (this.$router) this.$router.push(path);
}"""},
    'closeTab': {'type': 'JSFunction', 'value': """(i) => {
  const tabs = this.tabs.value;
  if (tabs.length <= 1) return;
  const closing = tabs[i];
  tabs.splice(i, 1);
  if (closing.path === this.current.value) {
    const next = tabs[Math.min(i, tabs.length - 1)];
    if (next) this.goTab(next.path);
  }
}"""},
    'openPalette': {'type': 'JSFunction', 'value': """() => {
  this.paletteQuery.value = '';
  this.paletteOpen.value = true;
}"""},
    'closePalette': {'type': 'JSFunction', 'value': """() => {
  this.paletteOpen.value = false;
}"""},
    'runPalette': {'type': 'JSFunction', 'value': """(item) => {
  this.paletteOpen.value = false;
  if (item && item.path) this.goTab(item.path);
}"""},
    'onPaletteEnter': {'type': 'JSFunction', 'value': """() => {
  const first = this.paletteList[0];
  if (first) this.runPalette(first);
}"""},
    'syncCurrent': {'type': 'JSFunction', 'value': """() => {
  const p = this.$route && this.$route.path;
  if (!p) return;
  const tabs = this.tabs.value;
  this.current.value = p;
  if (!tabs.some((t) => t.path === p)) {
    const meta = (this.pageList || []).find((x) => x.path === p);
    tabs.push({ path: p, title: meta ? meta.title : '页面' });
  }
}"""},
}

d['lifeCycles'] = {'onMounted': {'type': 'JSFunction', 'value': '() => {\n  this.syncCurrent();\n}'}}

# watch 在 VTJ 里是数组，source 是个 getter
d['watch'] = [{
    'id': vtj.nid('w'),
    'deep': False,
    'source': {'type': 'JSFunction', 'value': '() => this.$route && this.$route.path'},
    'handler': {'type': 'JSFunction', 'value': '() => {\n  this.syncCurrent();\n}'},
}]


# ── 2. 节点层 ────────────────────────────────────────────────
def kbd(t):
    return span(t, cls='kbd')


banner = div('demo-banner', [
    span('演示数据', cls='demo-banner-tag'),
    span('正式版回答只取 A–E 五组知识库（37 篇）；本页所有数字与案例均为课堂演示用，不构成录取或薪资承诺。'),
    div('banner-keys', [
        kbd('Ctrl'), kbd('K'), el('em', children='命令面板'),
        kbd('Ctrl'), kbd('B'), el('em', children='收起左栏'),
    ]),
])

tabbar = div('tabbar', [
    div('tab-strip', [
        div(
            children=[
                span(expr='String(i + 1).padStart(2, "0")', cls='tab-idx'),
                span(expr='tab.title', cls='tab-label'),
                span(
                    '×',
                    cls='tab-x',
                    directives=[d_if('this.tabs.value.length > 1')],
                    events={'click': fn('(e) => { e.stopPropagation(); this.closeTab(i); }')},
                ),
            ],
            props={'class': js("['tab', { active: this.current.value === tab.path }]")},
            directives=[d_for('this.tabs.value', 'tab', 'i')],
            events={'click': fn('() => this.goTab(tab.path)')},
        ),
    ]),
    div('tab-tools', [
        el('button', 'tool-btn', children='⌕', props={'title': '命令面板（Ctrl/⌘ + K）'},
           events={'click': fn('() => this.openPalette()')}),
        span('Ctrl K', cls='tab-hint'),
    ]),
])

main_content = el('main', 'main-content', [
    tabbar,
    div('view-host', [el('RouterView', 'route-view', frm='vue-router')]),
])

layout = div('main-layout', [
    el('aside', 'left-sidebar', [
        div('sidebar-top', [el('AppSidebar', frm='@/components/AppSidebar.vue')])
    ]),
    main_content,
])

palette = div('palette-mask', [
    div('palette', [
        div('palette-input', [
            span('⌕', cls='pi-icon'),
            el('input', 'palette-input-box',
               props={'placeholder': '去哪个页面…', 'spellcheck': 'false'},
               directives=[d_model('this.paletteQuery')],
               events={'keydown.enter': fn('() => this.onPaletteEnter()')}),
            span('Esc', cls='kbd'),
        ]),
        div('palette-body', [
            div('palette-group', [el('span', children='去页面')]),
            el('button', 'palette-item',
               children=[
                   span(expr='item.icon', cls='pi-icon'),
                   span(expr='item.title', cls='pi-title'),
                   span(expr='item.desc', cls='pi-desc'),
               ],
               directives=[d_for('paletteList', 'item', 'pi')],
               events={'click': fn('() => this.runPalette(item)')}),
        ]),
    ]),
], directives=[d_if('this.paletteOpen.value')],
   events={'click.self': fn('() => this.closePalette()')})

d['nodes'] = [div('app-shell', [
    el('i', 'route-progress',
       directives=[d_if('this.progressKey.value')],
       props={'key': js('this.progressKey.value')}),
    banner,
    layout,
    palette,
])]

vtj.save(FID, d)
print('main-layout DSL rebuilt: nodes', len(list(vtj.walk(d['nodes']))))
