# -*- coding: utf-8 -*-
"""m13：新增「材料与产出」页（DSL）+ 注册路由。

为什么要有这一页：上传的文件和产出的文件原来只在对话里一闪而过，
用户回头找不到。单独一页，左边我给的、右边你给的，账目清楚。
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import vtj as V

PID = 'mr0e9k2p'

FILES = """[
  { name: '成绩单-2024-2025.pdf', ext: 'PDF', kind: 'doc', size: '175.8 KB', note: '已读 3 段', time: '11-12 22:30', bad: false },
  { name: '简历初稿.md', ext: 'MD', kind: 'text', size: '74 B', note: '已读 8 段', time: '11-12 22:30', bad: false },
  { name: '课程表.xlsx', ext: 'XLS', kind: 'sheet', size: '39.1 KB', note: '已读 10 段', time: '11-12 22:31', bad: false },
  { name: '安装包.exe', ext: 'EXE', kind: 'doc', size: '2.0 KB', note: '暂不支持这个格式', time: '11-12 22:31', bad: true }
]"""

OUTPUTS = """[
  { name: '专插本准备清单.md', ext: 'MD', size: '697 B', note: '12 行', time: '11-12 22:34' },
  { name: '升学就业路径对照.csv', ext: 'CSV', size: '578 B', note: '4 行', time: '11-12 22:34' }
]"""

STATS = """[
  { label: '材料', value: '4', unit: ' 份', foot: '1 份没读成' },
  { label: '已解析', value: '3', unit: ' 份', foot: '共 21 段' },
  { label: '产出', value: '2', unit: ' 份', foot: '清单 / 表格 / 说明' },
  { label: '合计大小', value: '215 KB', unit: '', foot: '都在本地，没上传服务器' }
]"""


def build():
    # 统计卡
    stat_cards = []
    for i in range(4):
        it = f'this.stats.value[{i}]'
        stat_cards.append(
            V.div('stat', [
                V.span(expr=f'{it}.label', cls='stat-label'),
                V.span(cls='stat-value', children=[
                    V.el('span', expr=f'{it}.value', cls='num'),
                    V.el('em', expr=f'{it}.unit', cls='stat-unit'),
                ]),
                V.span(expr=f'{it}.foot', cls='stat-foot'),
            ])
        )

    # 材料行
    file_rows = [V.div('row', [
        V.span(expr='this.context.item.ext', cls='row-ico'),
        V.div('row-main', [
            V.div('row-name', [V.span(expr='this.context.item.name')]),
            V.div('row-meta', [
                V.span(expr='this.context.item.size'),
                V.span('·', cls='dot'),
                V.span(expr='this.context.item.time'),
            ]),
        ]),
        V.span(expr='this.context.item.note', cls='badge'),
        V.el('button', cls='row-x', text='×'),
    ], directives=[V.d_for('this.files.value', 'item')])]

    # 产物行
    out_rows = [V.div('row', [
        V.span(expr='this.context.item.ext', cls='row-ico out'),
        V.div('row-main', [
            V.div('row-name', [V.span(expr='this.context.item.name')]),
            V.div('row-meta', [
                V.span(expr='this.context.item.size'),
                V.span('·', cls='dot'),
                V.span(expr='this.context.item.note'),
                V.span('·', cls='dot'),
                V.span(expr='this.context.item.time'),
            ]),
        ]),
        V.span('预览', cls='mini-btn'),
        V.span('下载', cls='mini-btn primary'),
    ], directives=[V.d_for('this.outputs.value', 'item')])]

    root = V.div('materials-page', [
        # 头部
        V.div('mp-head', [
            V.div('mph-left', [
                V.h2('材料与产出', cls='mp-title'),
                V.p('你给的材料在这边，我给你的文件在那边。两边都不动额度，也不改 A–E 的出处规则。', cls='mp-lede'),
            ]),
            V.div('mph-acts', [
                V.el('button', cls='mp-go', text='＋ 去对话里上传',
                     events={'click': V.fn("() => {\n  this.$router.push('/page/chat-workspace');\n}")}),
                V.el('button', cls='export-btn', text='⇩ 导出', props={'type': 'button'},
                     events={'click': V.fn("() => {\n  this.$message.info('导出菜单：CSV / Markdown / 复制为表格');\n}")}),
            ]),
        ]),
        # 统计
        V.div('mp-stats', stat_cards),
        # 两栏
        V.div('mp-cols', [
            V.el('section', cls='panel', children=[
                V.div('panel-head', [
                    V.span('我的材料', cls='ph-title'),
                    V.span('4', cls='ph-count'),
                    V.span('上传与解析不计额度', cls='ph-hint'),
                ]),
                V.div('rows', file_rows),
            ]),
            V.el('section', cls='panel', children=[
                V.div('panel-head', [
                    V.span('产出的文件', cls='ph-title'),
                    V.span('2', cls='ph-count'),
                    V.span('演示环境：链接只在本机有效', cls='ph-hint'),
                ]),
                V.div('rows', out_rows),
            ]),
        ]),
        V.p('材料只作补充，回答的出处仍然只认 A–E 五组；产出的文件由回答内容拆成，不新增资料里没有的数字。', cls='mp-foot'),
    ])

    data = {
        'id': PID,
        'css': CSS,
        'name': 'Materials',
        'refs': {},
        'emits': [],
        'nodes': [root],
        'props': [],
        'slots': [],
        'state': {
            'files': V.js(FILES),
            'outputs': V.js(OUTPUTS),
            'stats': V.js(STATS),
        },
        'watch': [],
        'expose': [],
        'inject': [],
        'locked': False,
        'apiMode': 'composition',
        'methods': {},
        'provide': {},
        'computed': {},
        'reactives': {},
        'lifeCycles': {},
        '__VERSION__': 1794500000000,
        'composables': [],
        'dataSources': {},
        '__VTJ_BLOCK__': False,
    }
    V.save(PID, data)
    return data


def register():
    d = V.load_project()
    for page in d['pages']:
        kids = page.get('children') or []
        if any(c['id'] == PID for c in kids):
            return
        if page.get('id') == 'hr0d0qx3':
            idx = next((i for i, c in enumerate(kids) if c['filePath'] == 'knowledge-base'), len(kids) - 1)
            kids.insert(idx + 1, {
                'id': PID, 'dir': False, 'raw': False, 'icon': '', 'mask': False,
                'meta': '', 'name': 'Materials', 'page': 'page', 'pure': True,
                'type': 'page', 'cache': False, 'style': None, 'title': '材料与产出',
                'hidden': False, 'layout': False, 'filePath': 'materials',
                'needLogin': False, 'routePath': '/page/materials',
            })
    V.save_project(d)


CSS = r'''
.materials-page {
  flex: 1;
  min-width: 0;
  overflow: auto;
  padding: 18px 22px 26px;
  box-sizing: border-box;
  background: #f5f7fa;
}
.mp-head { display: flex; align-items: flex-start; gap: 16px; margin-bottom: 14px; }
.mph-left { flex: 1; min-width: 0; }
.mp-title { margin: 0; font-size: 19px; font-weight: 600; color: #1b2431; }
.mp-lede { margin: 5px 0 0; max-width: 660px; font-size: 12.5px; line-height: 1.7; color: #7d8797; }
.mph-acts { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
.mp-go, .export-btn {
  height: 28px; padding: 0 11px; border-radius: 7px; font-size: 12px; cursor: pointer;
  border: 1px solid #cfdcfb; background: #f4f8ff; color: #2f6bff;
  transition: background .16s cubic-bezier(.2,.8,.2,1), border-color .16s cubic-bezier(.2,.8,.2,1);
}
.export-btn { border-color: #e4e9f0; background: #fff; color: #4a5566; }
.mp-go:hover { background: #eaf1ff; border-color: #b9cdfd; }
.export-btn:hover { color: #2f6bff; border-color: #c3d3fb; background: #f6f9ff; }

.mp-stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; margin-bottom: 16px; }
.stat {
  padding: 11px 13px; border: 1px solid #eef1f6; border-radius: 10px; background: #fff;
  animation: statIn .32s cubic-bezier(.2,.8,.2,1) both;
}
.stat:nth-child(2) { animation-delay: 55ms; }
.stat:nth-child(3) { animation-delay: 110ms; }
.stat:nth-child(4) { animation-delay: 165ms; }
.stat-label { display: block; font-size: 11px; color: #939cab; }
.stat-value { display: block; margin: 3px 0 2px; font-size: 24px; font-weight: 600; color: #1b2431; line-height: 1.2; }
.stat-value .num { font-variant-numeric: tabular-nums; }
.stat-unit { margin-left: 2px; font-style: normal; font-size: 12px; font-weight: 500; color: #9aa3b2; }
.stat-foot { font-size: 10.5px; color: #b3bac6; }

.mp-cols { display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); gap: 12px; align-items: start; }
.panel { border: 1px solid #eef1f6; border-radius: 12px; background: #fff; overflow: hidden; }
.panel-head { display: flex; align-items: center; gap: 7px; padding: 10px 13px; border-bottom: 1px solid #f3f5f9; }
.ph-title { font-size: 13px; font-weight: 600; color: #26303d; }
.ph-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 17px; height: 16px; padding: 0 5px; border-radius: 999px;
  background: #eef3ff; color: #2f6bff; font-size: 10px; font-variant-numeric: tabular-nums;
}
.ph-hint { margin-left: auto; font-size: 10px; color: #b6bec9; }

.rows { display: flex; flex-direction: column; }
.row {
  display: flex; align-items: center; gap: 9px; padding: 9px 13px;
  border-bottom: 1px solid #f7f8fb; transition: background .14s linear;
}
.row:last-child { border-bottom: none; }
.row:hover { background: #fbfcfe; }
.row-ico {
  flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; border-radius: 6px;
  background: #eef3ff; color: #2f6bff; font-size: 8.5px; font-weight: 700;
}
.row-ico.out { background: #eaf7ef; color: #2c8a4b; }
.row-main { flex: 1; min-width: 0; }
.row-name { font-size: 12.5px; color: #1f2733; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.row-meta { display: flex; align-items: center; gap: 5px; margin-top: 2px; font-size: 10.5px; color: #9aa3b2; font-variant-numeric: tabular-nums; }
.row-meta .dot { color: #d0d6e0; }
.badge { flex-shrink: 0; padding: 2px 6px; border-radius: 4px; background: #f0faf3; color: #2c8a4b; font-size: 10px; }
.mini-btn {
  flex-shrink: 0; height: 24px; line-height: 22px; padding: 0 8px;
  border: 1px solid #e6eaf1; border-radius: 6px; background: #fff;
  color: #5a6473; font-size: 11px; cursor: pointer;
}
.mini-btn.primary { color: #2f6bff; border-color: #c9d8fb; background: #f4f8ff; }
.row-x { flex-shrink: 0; border: none; background: transparent; color: #c3cad5; font-size: 14px; cursor: pointer; }
.mp-foot { margin: 14px 2px 0; font-size: 11px; line-height: 1.7; color: #a8b1bf; }
@keyframes statIn { from { opacity: 0; transform: translateY(5px); } }
@media (max-width: 1180px) {
  .mp-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .mp-cols { grid-template-columns: minmax(0, 1fr); }
}
@media (prefers-reduced-motion: reduce) {
  .stat { animation: none; }
}
'''

if __name__ == '__main__':
    build()
    register()
    print('materials DSL written:', PID)
