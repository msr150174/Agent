cd /c/Users/ASUS/WorkBuddy/2026-11-12-20-44-44/unz2 && python - <<'PYEOF'
p='src/views/materials.vue'
s=open(p,encoding='utf-8').read()

s=s.replace("""  const { t } = useI18n();""","""  const { t, isEn } = useI18n();""")

s=s.replace("""  const statCards = computed(() => [
    {
      label: t('m.statFiles'),
      value: stats.value.count,
      unit: ' 份',
      foot: stats.value.failed ? stats.value.failed + ' 份没读成' : '三种方式都能加'
    },
    {
      label: t('m.statParsed'),
      value: stats.value.parsed,
      unit: ' 份',
      foot: '共 ' + stats.value.chunks + ' 段'
    },
    {
      label: t('m.statOutputs'),
      value: stats.value.outputs,
      unit: ' 份',
      foot: '清单 / 表格 / 说明'
    },
    {
      label: t('m.statSize'),
      value: humanSize(stats.value.bytes),
      unit: '',
      foot: '都在本地，没上传服务器'
    }
  ]);""","""  const statCards = computed(() => {
    const u = isEn.value ? '' : ' 份';
    return [
      {
        label: t('m.statFiles'),
        value: stats.value.count,
        unit: u,
        foot: stats.value.failed
          ? isEn.value
            ? stats.value.failed + ' could not be read'
            : stats.value.failed + ' 份没读成'
          : isEn.value
            ? 'Drop, paste or pick'
            : '三种方式都能加'
      },
      {
        label: t('m.statParsed'),
        value: stats.value.parsed,
        unit: u,
        foot: isEn.value ? stats.value.chunks + ' chunks' : '共 ' + stats.value.chunks + ' 段'
      },
      {
        label: t('m.statOutputs'),
        value: stats.value.outputs,
        unit: u,
        foot: isEn.value ? 'checklists / tables / notes' : '清单 / 表格 / 说明'
      },
      {
        label: t('m.statSize'),
        value: humanSize(stats.value.bytes),
        unit: '',
        foot: isEn.value ? 'Local only — not uploaded' : '都在本地，没上传服务器'
      }
    ];
  });""")

s=s.replace("""                <span>{{ m.from }}</span>""","""                <span>{{ m.from === '对话上传' ? t('m.fromChat') : m.from }}</span>""")

s=s.replace("""    <p class="mp-foot">
      材料只作补充，回答的出处仍然只认 A–E 五组；产出的文件由回答内容拆成，不新增资料里没有的数字。
    </p>""","""    <p class="mp-foot">{{ t('m.foot') }}</p>""")
open(p,'w',encoding='utf-8').write(s)
print('materials i18n ok')
PYEOF