# -*- coding: utf-8 -*-
"""m11：知识库 DSL 的文档卡加序号徽标 + 光标高光。

序号用 this.context.index 算（vFor 的索引在 VTJ 里挂在 context 上），
不自己编号，避免分页时对不上。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, span


def find(n, c):
    if isinstance(n, list):
        for i in n:
            r = find(i, c)
            if r:
                return r
    elif isinstance(n, dict):
        if (n.get('props') or {}).get('class') == c:
            return n
        return find(n.get('children'), c)


d = vtj.load('nr0dxtni')
card = find(d['nodes'], 'doc-card')
assert card is not None

card['props']['class'] = 'doc-card spot stagger'
card['props']['style'] = {'type': 'JSExpression', 'value': "{ '--i': this.context.index }"}

head = card['children'][0] if card.get('children') else None
assert head and (head.get('props') or {}).get('class') == 'doc-card-top', '结构变了'

idx = span(
    expr='String((this.currentPage.value - 1) * this.pageSize.value + this.context.index + 1).padStart(2, "0")',
    cls='idx',
)
# 序号排在最前面（参考实现的约定：序号在前、标题随后、按钮靠右）
if idx['id'] in [c.get('id') for c in head['children']]:
    head['children'] = [c for c in head['children'] if c.get('id') != idx['id']]
head['children'].insert(0, idx)

vtj.save('nr0dxtni', d)
print('kb doc-card: head children =', len(head['children']))
