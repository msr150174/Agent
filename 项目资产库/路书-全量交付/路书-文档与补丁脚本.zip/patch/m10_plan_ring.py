# -*- coding: utf-8 -*-
"""m10：路线图页 DSL 的「计划总进度」改成环形进度（替换 ElProgress 长条）。"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, span, js

FID = 'tr0e9af6'
d = vtj.load(FID)

box = vtj.find(d['nodes'], 'overview-right')
assert box is not None, '没找到 overview-right'

R = 19
LEN = round(2 * 3.141592653589793 * R, 2)  # 119.38

# 只改 offset，不改半径；表达式与运行期那一版同一公式
OFFSET = js(
    '{ strokeDashoffset: %s * (1 - (this.overallProgress.value || 0) / 100) }' % LEN
)

svg = el('svg', 'ring', children=[
    el('circle', 'ring-bg', props={'cx': '24', 'cy': '24', 'r': str(R)}),
    el('circle', 'ring-fg', props={'cx': '24', 'cy': '24', 'r': str(R), 'style': OFFSET}),
], props={'viewBox': '0 0 48 48', 'aria-hidden': 'true'})

num = span(expr='(this.overallProgress.value || 0) + "%"', cls='ring-num num')

box['children'] = [el('div', 'ring-wrap', [svg, num])]

# 数字旁边那句「还剩几件」：用已有 state 算，不新增字段
d['state'].pop('_x', None)
vtj.save(FID, d)
print('growth-plan ring ok, children of overview-right:', len(box['children']))
