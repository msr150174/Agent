# -*- coding: utf-8 -*-
"""N3：主布局补 RouterView（原本 6 个子页根本渲染不出来）+ 顶部演示横幅。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js

NAME = 'hr0d0qx3'
data = vtj.load(NAME)

sidebar = el('AppSidebar', None, [], frm={'id': '2r0c0a38', 'type': 'Schema'}, props={})
router_view = el('RouterView', 'route-view', [], frm='vue-router', props={})

shell = div('app-shell', [
    div('demo-banner', [
        span(text='演示数据', cls='demo-banner-tag'),
        span(text='正式版回答只取 A–E 五组知识库（37 篇）；本页所有数字与案例均为课堂演示用，不构成录取或薪资承诺。'),
    ]),
    div('main-layout', [
        el('aside', 'left-sidebar', [div('sidebar-top', [sidebar])]),
        el('main', 'main-content', [router_view]),
    ]),
])

data['nodes'] = [shell]

# 布局层不再持有对话状态，全部下沉到 ChatWorkspace
data['state'] = {}
data['methods'] = {}
data['reactives'] = {}
data['refs'] = {}
data['computed'] = {}

data['css'] = """.app-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  min-width: 1024px;
  background: #f5f7fa;
  font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
  overflow: hidden;
}
.demo-banner {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 16px;
  background: #fff7e6;
  border-bottom: 1px solid #ffe0a3;
  font-size: 12px;
  color: #96620a;
}
.demo-banner-tag {
  flex-shrink: 0;
  padding: 1px 7px;
  border-radius: 4px;
  background: #ffd591;
  color: #8a4b00;
  font-size: 11px;
  font-weight: 600;
}
.main-layout {
  flex: 1;
  min-height: 0;
  display: flex;
  overflow: hidden;
}
.left-sidebar {
  width: 264px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  background: #fff;
  border-right: 1px solid #eef0f3;
}
.sidebar-top {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
}
.main-content {
  flex: 1;
  min-width: 0;
  display: flex;
  background: #f5f7fa;
}
.route-view {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
}
@media (max-width: 1100px) {
  .app-shell { min-width: 0; }
  .main-layout { flex-direction: column; }
  .left-sidebar {
    width: 100%;
    flex-direction: row;
    align-items: center;
    border-right: none;
    border-bottom: 1px solid #eef0f3;
    overflow-x: auto;
  }
  .sidebar-top { flex: 1; min-width: 0; }
}
"""

vtj.save(NAME, data)
print('layout patched')
