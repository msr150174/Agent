# -*- coding: utf-8 -*-
"""m9：把 TabBar.vue / CommandPalette.vue 的样式并进 MainLayout 的 DSL css。

这两个组件只存在于运行期（手写 .vue，没注册进材料库），
DSL 里是把它们的结构就地搭出来的，所以样式得单独搬过来。
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj

B = '/* ==== 标签栏 / 命令面板（由 patch/m9_tab_css.py 同步） ==== */'
E = '/* ==== 标签栏 / 命令面板结束 ==== */'


def style_of(rel):
    src = open(os.path.join(vtj.ROOT, 'src', rel), encoding='utf-8').read()
    m = re.search(r'<style[^>]*>(.*?)</style>', src, re.S)
    return m.group(1).strip() if m else ''


tabs = style_of('components/TabBar.vue')
pal = style_of('components/CommandPalette.vue')

# DSL 里的下划线是 ::after（滑动版要读 DOM offset，这里换成从左边长出来）
tabs += """
/* DSL 版下划线：从左边长出来，不做滑动跟随 */
.tab::after {
  content: '';
  position: absolute;
  left: 6px;
  right: 6px;
  bottom: -1px;
  height: 2px;
  border-radius: 2px 2px 0 0;
  background: var(--m-accent);
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform var(--m-mid) var(--m-ease);
}
.tab.active::after {
  transform: scaleX(1);
}
.tab-ink {
  display: none;
}
"""

d = vtj.load('hr0d0qx3')
css = d.get('css') or ''
if B in css and E in css:
    a = css.index(B)
    b = css.index(E) + len(E)
    css = (css[:a] + css[b:]).strip()

d['css'] = css.rstrip() + '\n\n' + B + '\n' + tabs + '\n\n' + pal + '\n' + E + '\n'
vtj.save('hr0d0qx3', d)
print('layout css ->', len(d['css']))
