# -*- coding: utf-8 -*-
"""m15：给三个页面加「导出」——真的能下到文件，不是摆个按钮。

岗位表 → CSV / 任务清单 → Markdown / 调用日志 → CSV。
数据全部取页面现有变量，不另外造一份。
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'unz2', 'src', 'views'))


def patch(name, pairs):
    p = os.path.join(ROOT, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if old not in s:
            print('!! anchor missing in', name, ':', old[:50])
            continue
        s = s.replace(old, new, 1)
    open(p, 'w', encoding='utf-8').write(s)
    print('patched', name)


IMPORTS = """  import ExportMenu from '@/components/ExportMenu.vue';
  import { notify } from '@/store/ui';
  import { useI18n } from '@/i18n';
  import { downloadCsv, downloadMarkdown, toTsv, copyText } from '@/utils/download';
"""

# ---------------- 看清路 ----------------
CAREER_EXPORT = """
  const { t } = useI18n();

  /* 导出：列顺序跟岗位表本身一致，不额外加结论列 */
  const exportRows = () => {
    const head = ['岗位', '方向', '匹配度参考', '需求', '经验门槛', '薪资口径', '核心技能', '本轮要补的', '来源'];
    const body = filtered.value.map((c) => [
      c.name,
      c.category,
      c.match,
      c.demand,
      c.experience,
      c.salary ? c.salary + '（' + c.salaryNote + '）' : '不给区间（' + c.salaryNote + '）',
      c.skills.join(' / '),
      c.gap,
      c.source
    ]);
    return [head].concat(body);
  };

  const doExport = async (type) => {
    if (!filtered.value.length) {
      notify('当前筛选下没有岗位可导出');
      return;
    }
    if (type === 'csv') {
      const name = downloadCsv('看清路-岗位对照', exportRows());
      notify(t('e.done', { name }));
    } else if (type === 'md') {
      const md =
        '# 看清路 · 岗位对照\\n\\n' +
        '> 匹配度是逐条比对算出来的参考值，不是录取概率。薪资没样本的写「不给区间」。\\n\\n' +
        filtered.value
          .map(
            (c) =>
              '## ' + c.name + '（' + c.category + '）\\n' +
              '- 匹配度参考：' + c.match + ' · 需求 ' + c.demand + ' · 经验 ' + c.experience + '\\n' +
              '- 核心技能：' + c.skills.join(' / ') + '\\n' +
              '- 本轮要补的：' + c.gap + '\\n' +
              '- 薪资口径：' + (c.salary ? c.salary + '（' + c.salaryNote + '）' : '不给区间（' + c.salaryNote + '）') + '\\n' +
              '- 来源：' + c.source + '\\n'
          )
          .join('\\n');
      const name = downloadMarkdown('看清路-岗位对照', md);
      notify(t('e.done', { name }));
    } else {
      const ok = await copyText(toTsv(exportRows()));
      notify(ok ? t('e.copied') : '复制失败');
    }
  };
"""

patch('career-library.vue', [
    (
        '      <div class="tip">匹配度是逐条比对算出来的参考值，不是录取概率。</div>',
        '      <div class="header-right">\n'
        '        <div class="tip">匹配度是逐条比对算出来的参考值，不是录取概率。</div>\n'
        '        <ExportMenu @export="doExport"></ExportMenu>\n'
        '      </div>'
    ),
    (
        "  import { ElInput, ElSelect, ElOption, ElTag } from 'element-plus';\n",
        "  import { ElInput, ElSelect, ElOption, ElTag } from 'element-plus';\n" + IMPORTS
    ),
    ('  const keyword = ref(\'\');', CAREER_EXPORT + "\n  const keyword = ref('');"),
    (
        '  .page-header {',
        '  .header-right {\n    display: flex;\n    align-items: center;\n    gap: 10px;\n    flex-shrink: 0;\n  }\n  .page-header {'
    )
])

# ---------------- 路线图 ----------------
PLAN_EXPORT = """
  const { t } = useI18n();

  /* 勾选状态照着页面上真实的 done 走，导出的是「你现在做到哪」 */
  const exportRows = () => {
    const head = ['阶段', '时间', '任务', '状态', '证书/比赛'];
    const body = [];
    phases.forEach((ph) => {
      ph.steps.forEach((st) => {
        body.push([
          ph.name,
          ph.period,
          st.label,
          st.done ? '已完成' : '未完成',
          st.cert || '—'
        ]);
      });
    });
    return [head].concat(body);
  };

  const doneCount = () => {
    let total = 0;
    let done = 0;
    phases.forEach((ph) =>
      ph.steps.forEach((st) => {
        total += 1;
        if (st.done) done += 1;
      })
    );
    return { total, done };
  };

  const doExport = async (type) => {
    if (type === 'csv') {
      const name = downloadCsv('路线图-任务清单', exportRows());
      notify(t('e.done', { name }));
      return;
    }
    if (type === 'md') {
      const c = doneCount();
      const md =
        '# 路线图 · ' + targetCareer.value + '\\n\\n' +
        '**目标一句话**：' + goalSentence.value + '\\n\\n' +
        '**进度**：' + c.done + ' / ' + c.total + ' 项完成\\n\\n' +
        phases
          .map(
            (ph) =>
              '## ' + ph.name + '（' + ph.period + '）\\n\\n' +
              ph.desc + '\\n\\n' +
              ph.steps.map((st) => '- [' + (st.done ? 'x' : ' ') + '] ' + st.label + (st.cert ? ' · ' + st.cert : '')).join('\\n') +
              '\\n'
          )
          .join('\\n');
      const name = downloadMarkdown('路线图-任务清单', md);
      notify(t('e.done', { name }));
      return;
    }
    const ok = await copyText(toTsv(exportRows()));
    notify(ok ? t('e.copied') : '复制失败');
  };
"""

patch('growth-plan.vue', [
    (
        '      <div class="target">\n        <span class="target-label">目标职业</span>',
        '      <div class="header-right">\n        <ExportMenu @export="doExport"></ExportMenu>\n        <div class="target">\n          <span class="target-label">目标职业</span>'
    ),
    (
        '        <ElTag type="primary" effect="plain">{{ targetCareer }}</ElTag>\n      </div>',
        '          <ElTag type="primary" effect="plain">{{ targetCareer }}</ElTag>\n        </div>\n      </div>'
    ),
    (
        "  import { ElTag, ElTimeline, ElTimelineItem, ElProgress, ElButton, ElMessage } from 'element-plus';\n",
        "  import { ElTag, ElTimeline, ElTimelineItem, ElProgress, ElButton, ElMessage } from 'element-plus';\n" + IMPORTS
    ),
    ('  const targetCareer = ref(\'Java 后端开发（初级）\');', PLAN_EXPORT + "\n  const targetCareer = ref('Java 后端开发（初级）');"),
    (
        '  .page-header {',
        '  .header-right {\n    display: flex;\n    align-items: center;\n    gap: 10px;\n    flex-shrink: 0;\n  }\n  .page-header {'
    )
])

# ---------------- 调用日志 ----------------
LOGS_EXPORT = """
  const { t } = useI18n();

  const exportRows = () => {
    const head = ['时间', '学生', '问题', '意图', '命中分组', '终审', '状态'];
    const body = filtered.value.map((l) => [l.time, l.user, l.question, l.intent, l.groups, l.verdict, l.status]);
    return [head].concat(body);
  };

  const doExport = async (type) => {
    if (!filtered.value.length) {
      notify('当前筛选下没有日志可导出');
      return;
    }
    if (type === 'csv') {
      const name = downloadCsv('调用日志-导出', exportRows());
      notify(t('e.done', { name }));
      return;
    }
    if (type === 'md') {
      const md =
        '# 调用日志\\n\\n' +
        '> 导出时间 ' + new Date().toLocaleString('zh-CN') + '，共 ' + filtered.value.length + ' 条。\\n\\n' +
        '| 时间 | 学生 | 问题 | 意图 | 命中 | 终审 | 状态 |\\n' +
        '| --- | --- | --- | --- | --- | --- | --- |\\n' +
        filtered.value
          .map((l) => '| ' + [l.time, l.user, l.question, l.intent, l.groups, l.verdict, l.status].join(' | ') + ' |')
          .join('\\n') +
        '\\n';
      const name = downloadMarkdown('调用日志-导出', md);
      notify(t('e.done', { name }));
      return;
    }
    const ok = await copyText(toTsv(exportRows()));
    notify(ok ? t('e.copied') : '复制失败');
  };
"""

patch('call-logs.vue', [
    (
        '      <div class="tools">',
        '      <div class="tools">\n        <ExportMenu @export="doExport"></ExportMenu>'
    ),
    (
        "  import { ElTable, ElTableColumn, ElTag, ElSelect, ElOption } from 'element-plus';\n",
        "  import { ElTable, ElTableColumn, ElTag, ElSelect, ElOption } from 'element-plus';\n" + IMPORTS
    ),
    ("  const onlyAbnormal = ref('全部');", LOGS_EXPORT + "\n  const onlyAbnormal = ref('全部');")
])
