# -*- coding: utf-8 -*-
"""回填：把 Vue 侧的细节修正同步回 DSL（列宽、统计口径、路径行距）。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, span

# ---- 调用日志：列宽 + 安全熔断统计 ----
NAME = 'wr0ea12x'
d = vtj.load(NAME)
for node in vtj.walk(d['nodes']):
    if node.get('name') != 'ElTableColumn':
        continue
    pr = node.get('props') or {}
    if pr.get('prop') == 'time':
        pr['width'] = '176'
    elif pr.get('prop') == 'groups':
        pr['width'] = '176'
    elif pr.get('prop') == 'verdict':
        pr['min-width'] = '150'
    elif pr.get('prop') == 'user':
        pr['width'] = '90'
    elif pr.get('prop') == 'status':
        pr['width'] = '110'

root = d['nodes'][0]
summary = vtj.find(root, 'logs-summary')
if summary is not None and len(summary['children']) == 4:
    summary['children'].append(el('div', 'summary-item', [
        span('安全熔断', cls='summary-label'),
        span('2', cls='summary-value danger'),
    ]))

vtj.add_css(d, """
.logs-summary { grid-template-columns: repeat(5, minmax(0, 1fr)); }
.summary-value.warning { color: #d97706; }
.summary-value.danger { color: #dc2626; }
""")
vtj.save(NAME, d)
print('logs synced')

# ---- 看清路：路径行距 ----
NAME = 'qr0e8iq5'
d = vtj.load(NAME)
vtj.add_css(d, """
.path-row { margin-bottom: 4px; }
.path-row:last-child { margin-bottom: 0; }
""")
vtj.save(NAME, d)
print('career synced')
