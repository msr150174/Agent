# -*- coding: utf-8 -*-
"""N2/N5：会话列表与登录页口径对齐（学生为主，教师账号收进收起项）。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, span, js, fn

# ---- SessionList ----
NAME = '5r0c26ix'
d = vtj.load(NAME)
for prop in d['props']:
    if prop['name'] == 'sessions':
        prop['default'] = {'type': 'JSExpression', 'value': """() => [
  { id: 's1', title: '专插本要什么条件', status: 'active', statusText: '进行中', updatedAt: '10:24' },
  { id: 's2', title: '计算机应用技术能去哪些岗位', status: 'done', statusText: '已完成', updatedAt: '昨天' },
  { id: 's3', title: '大一该先准备什么', status: 'done', statusText: '已完成', updatedAt: '周二' },
  { id: 's4', title: '简历没项目经历怎么写', status: 'pending', statusText: '待处理', updatedAt: '周一' }
]"""}
root = d['nodes'][0]
for node in vtj.walk(root):
    if node.get('children') == '会话':
        node['children'] = '我的提问'
    if node.get('children') == '暂无会话':
        node['children'] = '还没有提问，右边问一句试试'
    pr = node.get('props') or {}
    if isinstance(pr.get('placeholder'), str) and '会话' in pr['placeholder']:
        pr['placeholder'] = '搜我问过的问题'
vtj.save(NAME, d)
print('session list ok')

# ---- Login ----
NAME = 'er0d043h'
d = vtj.load(NAME)
root = d['nodes'][0]
REPL = {
    '面向高职学生的智能职业规划工作台，帮你发现方向、规划路径、找到答案。':
        '面向高职学生自己的职业规划工作台：认识自己、看清路、把目标拆到学期。',
    '知识库可溯源回答': '只答知识库里有的 · 带来源',
    '行业与职业数据支撑': '本校回收样本 · 标样本量',
    '个性化成长计划': '按学期拆的路线图',
    '请使用学号或教师账号登录工作台': '用学号登录。这是给你自己用的，不是教师后台。',
    '演示环境默认：学生 / 教师账号均可直接登录': '演示环境：学生账号直接进；教师账号在「教师入口」里看链路。',
    '欢迎登录': '登录路书',
}
for node in vtj.walk(root):
    t = node.get('children')
    if isinstance(t, str) and t in REPL:
        node['children'] = REPL[t]
vtj.save(NAME, d)
print('login ok')
