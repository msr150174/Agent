# -*- coding: utf-8 -*-
"""m2：对话面板 —— 检索链进度光条 + 两个视图开关 + 气泡/来源逐条浮入"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

d = vtj.load('8r0cd8oa')

# ---- props / emits ----
props = d['props']
props[:] = [p for p in props if p['name'] != 'toolStatus']
props.append({'name': 'toolStep', 'type': 'Number',
              'default': {'type': 'JSExpression', 'value': '-1'}, 'required': False})
props.append({'name': 'showSessions', 'type': 'Boolean',
              'default': {'type': 'JSExpression', 'value': 'true'}, 'required': False})
props.append({'name': 'showRefs', 'type': 'Boolean',
              'default': {'type': 'JSExpression', 'value': 'true'}, 'required': False})

names = [e['name'] for e in d['emits']]
for n in ('toggleSessions', 'toggleRefs'):
    if n not in names:
        d['emits'].append({'name': n, 'params': []})

# ---- 四段链路文案 ----
d['refs']['chainSteps'] = js(
    "['理解问题', '检索 A–E', '挂载来源', '终审 V1.1']"
)
d['methods']['toggleSessions'] = fn(
    "() => {\n  try { this.$emit('toggleSessions'); } catch (e) {}\n}"
)
d['methods']['toggleRefs'] = fn(
    "() => {\n  try { this.$emit('toggleRefs'); } catch (e) {}\n}"
)

root = d['nodes'][0]
head = vtj.find(root, 'chat-header')
actions = vtj.find(root, 'header-actions')

# ---- 1. 头部两个视图开关 ----
actions['children'].append(
    el('button', js("Object.assign({ 'view-btn': true }, { off: !this.showSessions })"),
       ['◧'],
       props={'title': '显示 / 隐藏「我的提问」列'},
       events={'click': {'name': 'click', 'handler': js('this.toggleSessions()'), 'modifiers': {}}})
)
actions['children'].append(
    el('button', js("Object.assign({ 'view-btn': true }, { off: !this.showRefs })"),
       ['◨'],
       props={'title': '显示 / 隐藏「来源」栏'},
       events={'click': {'name': 'click', 'handler': js('this.toggleRefs()'), 'modifiers': {}}})
)

# ---- 2. 检索链：插在 chat-header 之后 ----
chain = div(
    'chain',
    [
        div(
            js("Object.assign({ 'chain-step': true }, { done: this.context.index < this.toolStep, active: this.context.index === this.toolStep })"),
            [
                span(expr="this.context.index < this.toolStep ? '✓' : (this.context.index + 1)", cls='chain-dot'),
                span(expr='this.context.step', cls='chain-text'),
            ],
            directives=[d_for('this.chainSteps.value', 'step', 'index')],
        )
    ],
    directives=[d_if('this.streaming')],
)
root['children'].insert(1, chain)

# ---- 3. 快捷问题 chip 依次入场 ----
chips = vtj.find(root, 'chips')
for i, btn in enumerate(chips['children']):
    btn['props']['style'] = 'animation-delay: %dms' % (i * 50)

# ---- 4. 来源行依次入场 ----
ref_item = vtj.find(root, 'ref-item')
ref_item['props']['style'] = js("'animation-delay: ' + (this.context.index * 60) + 'ms'")

vtj.save('8r0cd8oa', d)
print('8r0cd8oa ok')
