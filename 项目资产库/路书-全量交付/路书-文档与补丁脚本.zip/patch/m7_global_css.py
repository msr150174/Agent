# -*- coding: utf-8 -*-
"""
m7：把 index.scss 里 @motion-begin … @motion-end 之间的动效基线 + 工具类，
原样拷进每个 DSL 页面的 css 前面。

为什么要拷：这些类（.num / .spot / .kbd / .idx / .stagger …）定义在全局样式里，
而 DSL 页面重建时只带自己那一份 css。不拷过去，导回编辑器后类名就成了空壳。

两处必要的改写：
  ① `:root` → `*`：VTJ 生成的是 <style scoped>，`:root` 会被编译成 `:root[data-v-x]`，
     永远匹配不到；`*` 会被编译成 `*[data-v-x]`，页面内每个元素都命中，变量照常继承。
  ② 去掉 `.view-host > *` 那条 —— 它属于布局壳，页面里没有这个父级。
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj

SCSS = os.path.join(vtj.ROOT, 'src', 'style', 'index.scss')
BEGIN = '/* @motion-begin'
END = '/* @motion-end */'
WRAP_B = '/* ==== 动效基线（由 patch/m7_global_css.py 同步，勿手改） ==== */'
WRAP_E = '/* ==== 动效基线结束 ==== */'


def motion_block():
    src = open(SCSS, encoding='utf-8').read()
    i = src.index(BEGIN)
    j = src.index(END)
    block = src[i:j].strip()
    # 去掉自己的临时标记行
    block = block.split('\n', 1)[1] if block.startswith('/* @motion-begin') else block
    # ① :root → *
    block = re.sub(r'^:root\s*\{', '* {', block, count=1, flags=re.M)
    # ② 去掉布局壳那条规则
    block = re.sub(r'\.view-host\s*>\s*\*\s*\{[^}]*\}\n?', '', block)
    return block.strip()


def strip_old(css):
    if WRAP_B in css and WRAP_E in css:
        a = css.index(WRAP_B)
        b = css.index(WRAP_E) + len(WRAP_E)
        return (css[:a] + css[b:]).strip()
    return css


BLOCK = motion_block()
print('motion block chars:', len(BLOCK))

FILES = ['2r0c0a38', 'hr0d0qx3', '8r0cd8oa', 'kr0dwyr8', 'br0cz38c',
         'qr0e8iq5', 'tr0e9af6', 'wr0ea12x', 'nr0dxtni', 'zr0eap34',
         'er0d043h', 'sr0ne7wq', '5r0c26ix']

for fid in FILES:
    p = os.path.join(vtj.ROOT, '.vtj', 'files', fid + '.json')
    if not os.path.exists(p):
        print('skip', fid)
        continue
    d = vtj.load(fid)
    css = strip_old(d.get('css') or '')
    d['css'] = WRAP_B + '\n' + BLOCK + '\n' + WRAP_E + '\n\n' + css
    vtj.save(fid, d)
    print(fid, 'css ->', len(d['css']))
print('ok')
