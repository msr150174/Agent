# -*- coding: utf-8 -*-
"""N5/N6/N9：看清路 —— 本校口径岗位、岗位卡三段式、三条路径对比。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

NAME = 'qr0e8iq5'
d = vtj.load(NAME)

CAREERS = """[
  {
    id: 1,
    name: 'Java 后端开发（初级）',
    category: '后端',
    match: '82%',
    demand: '中',
    salary: '',
    salaryNote: '现有资料未覆盖',
    experience: '0–1 年',
    summary: '写接口、连数据库、把业务逻辑落到能跑的代码上。中小公司居多，看项目不看学校。',
    skills: ['Java 基础', 'MySQL', 'Git'],
    reasons: [
      'C 组岗位表列了 7 项要求，你在校期间能覆盖 5 项（Java 基础、MySQL、Git、Linux 常用命令、一个框架）',
      '本校近两届去向里有 6 人进了中小公司后端岗，这条路是通的'
    ],
    gap: '还差一个能讲清楚的项目，和一次真实的接口联调经历',
    source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
  },
  {
    id: 2,
    name: 'Web 前端开发',
    category: '前端',
    match: '78%',
    demand: '高',
    salary: '6–9K',
    salaryNote: '本校样本 12 条',
    experience: '0–1 年',
    summary: '把设计稿做成页面，调接口、处理交互。入门门槛相对低，作品能直接看。',
    skills: ['HTML/CSS', 'JavaScript', 'Vue'],
    reasons: [
      'C 组把前端列为「作品可替代经验」的岗位，在校做的页面能直接放进作品集',
      '本校 12 条回收样本里，9 条在毕业前有过自主项目'
    ],
    gap: '还差一个部署上线、能发链接给人看的作品',
    source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
  },
  {
    id: 3,
    name: '软件测试',
    category: '测试',
    match: '74%',
    demand: '高',
    salary: '5–8K',
    salaryNote: '本校样本 9 条',
    experience: '0–1 年',
    summary: '写用例、跑回归、提缺陷单。对细心程度要求高，入门比开发平缓。',
    skills: ['测试用例', '缺陷管理', '基础 SQL'],
    reasons: [
      'C 组列出的能力项里，测试岗对算法要求最低，更看你有没有耐心把流程走完',
      'D 组样本显示这个岗位近两届招聘量稳定，专科可投'
    ],
    gap: '还差一次完整的用例设计练习（从需求到缺陷单走一遍）',
    source: '《2024 届毕业生就业质量回收样本》D 组 · 2025-01-15'
  },
  {
    id: 4,
    name: 'IT 运维 / 桌面运维',
    category: '运维',
    match: '70%',
    demand: '中',
    salary: '5–7K',
    salaryNote: '本校样本 6 条',
    experience: '0–1 年',
    summary: '管机房、装系统、处理日常故障。稳定，但要能接受值班和琐碎。',
    skills: ['Windows/Linux', '网络基础', '故障排查'],
    reasons: [
      'C 组把这个岗位列为「上手快、需求稳」的方向，适合先就业再择业',
      '本校 6 条样本里，4 条来自校企合作单位'
    ],
    gap: '还差一张网络或系统方向的入门证书，或一次校内机房维护经历',
    source: '《计算机应用技术专业对口岗位表》C 组 · 2025-03-08'
  },
  {
    id: 5,
    name: '电商运营专员',
    category: '电商',
    match: '80%',
    demand: '高',
    salary: '5–8K',
    salaryNote: '本校样本 11 条',
    experience: '应届可投',
    summary: '管店铺日常、做活动、看数据。电子商务专业的对口主方向。',
    skills: ['店铺后台', '活动策划', 'Excel 数据'],
    reasons: [
      'C 组把电商运营列为电子商务专业匹配度最高的岗位，专业课程能直接对上',
      '本校 11 条样本里，7 条在大三实习后转正'
    ],
    gap: '还差一次真实店铺的运营数据复盘（哪怕是校园店铺）',
    source: '《电子商务专业对口岗位表》C 组 · 2025-03-09'
  },
  {
    id: 6,
    name: '跨境电商运营',
    category: '电商',
    match: '76%',
    demand: '中',
    salary: '',
    salaryNote: '现有资料未覆盖',
    experience: '0–1 年',
    summary: '面向海外平台的选品、上架、投放。英语要求比国内运营高。',
    skills: ['平台规则', '选品', '英语读写'],
    reasons: [
      'C 组把跨境电商单列，因为它对英语的要求和国内运营不是一个标准',
      'D 组提到这个方向近两年岗位数在涨，但本校回收样本不足 5 条'
    ],
    gap: '还差英语能力的证明（四级或平台实操），否则简历初筛容易被跳过',
    source: '《电子商务专业对口岗位表》C 组 · 2025-03-09'
  }
]"""

d['state']['careers'] = js(CAREERS)
d['state']['pageSize'] = js('6')

PATHS = """[
  {
    key: 'job',
    name: '直接就业',
    threshold: '大专学历 + 一个能演示的项目',
    time: '大三上开始投递，边实习边定岗',
    risk: '起薪偏低，岗位集中在中小公司',
    covered: true
  },
  {
    key: 'zsb',
    name: '专插本',
    threshold: '应届毕业 + 无违纪 + 通过省考试院考试',
    time: '2 年全日制本科',
    risk: '名额少、专业受限，需提前确认目标院校',
    covered: true
  },
  {
    key: 'kb',
    name: '考编 / 考公',
    threshold: '现有资料未覆盖',
    time: '现有资料未覆盖',
    risk: '现有资料未覆盖（建议问招生就业处）',
    covered: false
  }
]"""

d['refs'] = {'paths': js(PATHS)}

def path_card():
    return div('path-card', [
        span(expr='this.context.p.name', cls='path-name'),
        div('path-row', [span('起步门槛', cls='path-k'), span(expr='this.context.p.threshold', cls='path-v')]),
        div('path-row', [span('时间成本', cls='path-k'), span(expr='this.context.p.time', cls='path-v')]),
        div('path-row', [span('主要风险', cls='path-k'), span(expr='this.context.p.risk', cls='path-v')]),
    ], props={'class': js("Object.assign({ 'path-card': true }, { miss: !this.context.p.covered })")},
        directives=[d_for('this.paths.value', 'p')])

compare = div('path-compare', [
    div('path-compare-head', [
        span('三条路的差别', cls='path-compare-title'),
        span('就业与专插本按知识库原文；考编没收录，如实标出来', cls='path-compare-sub'),
    ]),
    div('path-grid', [path_card()]),
])

def why_item():
    return div('why-item', [
        span('·', cls='why-dot'),
        span(expr='this.context.r'),
    ], directives=[d_for('this.context.career.reasons', 'r')])

def enrich_card(card):
    """在原卡片里插入：推荐理由 2 条 / 还差什么 / 来源"""
    children = card['children']
    why = div('career-why', [
        span('为什么推荐', cls='why-title'),
        why_item(),
    ])
    gap = div('career-gap', [
        span('还差什么', cls='gap-title'),
        span(expr='this.context.career.gap', cls='gap-text'),
    ])
    src = div('career-source', expr='this.context.career.source')
    # 插在 skills 之前，来源放最后
    idx = next(i for i, c in enumerate(children) if (c.get('props') or {}).get('class') == 'career-skills')
    children[idx:idx] = [why, gap]
    children.append(src)
    # 薪资：有样本才给数字，没样本写「现有资料未覆盖」
    for node in vtj.walk(card):
        if (node.get('props') or {}).get('class') == 'info-item':
            spans = node.get('children')
            if isinstance(spans, list) and len(spans) >= 2:
                inner = spans[0].get('children') if isinstance(spans[0], dict) else None
                if isinstance(inner, list):
                    for s in inner:
                        if isinstance(s, dict) and s.get('children') == '薪资：':
                            spans[0]['children'][1]['children'] = js('this.salaryText(this.context.career)')
    return card

root = d['nodes'][0]
# 1) 标题与描述
for node in vtj.walk(root):
    cls = (node.get('props') or {}).get('class')
    if cls == 'career-desc':
        node['children'] = '本专业的对口岗位，以及就业 / 专插本 / 考编三条路的差别。每个数字都标了来源，没有样本的不给数字。'
    if cls == 'career-header':
        node['children'].append(el('div', 'career-tip', text='匹配度是按知识库要求项逐条比对算出来的参考值，不是录取概率。'))

# 2) 路径对比插在 header 之后
kids = root['children']
hi = next(i for i, c in enumerate(kids) if (c.get('props') or {}).get('class') == 'career-header')
kids.insert(hi + 1, compare)

# 3) 岗位卡补三段式
grid = vtj.find(root, 'career-grid')
enrich_card(grid['children'][0])

# 4) 分类选项换成岗位方向
sel = vtj.find(root, 'career-select')
sel['children'] = [el('ElOption', None, [], frm='element-plus', props={'label': x, 'value': x})
                   for x in ['全部', '后端', '前端', '测试', '运维', '电商']]

# 5) 分析匹配按钮改成「看这条的来源」
btn = None
for node in vtj.walk(root):
    if node.get('name') == 'ElButton' and node.get('children') == '分析匹配':
        btn = node
if btn:
    btn['children'] = '看能力对照'
    btn['events'] = {'click': {'name': 'click', 'handler': js('this.handleAnalyze(this.context.career)'), 'modifiers': {}}}

d['methods']['handleAnalyze'] = fn("""(career) => {
  this.$message.info(
    career.name + '：' + career.reasons.length + ' 条理由、1 条差距，来源是' + career.source
  );
}""")
d['methods']['salaryText'] = fn("""(career) => {
  return career.salary ? career.salary + '（' + career.salaryNote + '）' : '现有资料未覆盖';
}""")

vtj.add_css(d, """
.path-compare {
  background: #fff;
  border: 1px solid #eef0f3;
  border-radius: 12px;
  padding: 14px 16px;
  margin-bottom: 14px;
}
.path-compare-head { display: flex; align-items: baseline; gap: 8px; margin-bottom: 10px; }
.path-compare-title { font-size: 14px; font-weight: 600; color: #1f2937; }
.path-compare-sub { font-size: 11.5px; color: #9ca3af; }
.path-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
.path-card {
  border: 1px solid #eef0f3;
  border-radius: 8px;
  padding: 10px 12px;
  background: #fbfcfe;
}
.path-card.miss { background: #fffdf7; border-color: #ffe0a3; }
.path-name { display: block; font-size: 13px; font-weight: 600; color: #2f6bff; margin-bottom: 6px; }
.path-card.miss .path-name { color: #a86a00; }
.path-row { display: flex; gap: 6px; font-size: 12px; line-height: 1.7; }
.path-k { flex-shrink: 0; width: 56px; color: #9ca3af; }
.path-v { color: #4b5563; }
.career-tip { font-size: 11.5px; color: #9ca3af; }
.career-why { margin-top: 8px; padding-top: 8px; border-top: 1px dashed #eef0f3; }
.why-title { display: block; font-size: 11.5px; color: #9ca3af; margin-bottom: 4px; }
.why-item { display: flex; gap: 4px; font-size: 12px; line-height: 1.7; color: #374151; }
.why-dot { color: #2f6bff; }
.career-gap { margin-top: 6px; font-size: 12px; line-height: 1.7; }
.gap-title {
  display: inline-block; margin-right: 6px; padding: 0 6px; border-radius: 4px;
  background: #fff2e8; color: #b25b00; font-size: 11px;
}
.gap-text { color: #4b5563; }
.career-source { margin-top: 8px; font-size: 11px; color: #b9bdc4; }
""")

vtj.save(NAME, d)
print('career patched')
