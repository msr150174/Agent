# -*- coding: utf-8 -*-
"""VTJ DSL 补丁工具：节点构造、读写、校验。"""
import json, os, random, re, string, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'unz2'))
ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyz'
_used = set()

def nid(prefix='px'):
    while True:
        s = prefix + ''.join(random.choice(ALPHABET) for _ in range(8))
        if s not in _used:
            _used.add(s)
            return s

def js(expr):
    return {'type': 'JSExpression', 'value': expr}

def fn(body):
    return {'type': 'JSFunction', 'value': body}

def d_for(expr, item, index='index'):
    return {'id': nid('d'), 'name': 'vFor', 'value': js(expr),
            'iterator': {'item': item, 'index': index}}

def d_if(expr):
    return {'id': nid('d'), 'name': 'vIf', 'value': js(expr)}

def d_else(val=True):
    return {'id': nid('d'), 'name': 'vElse', 'value': val}

def d_model(expr, arg=None):
    d = {'id': nid('d'), 'name': 'vModel', 'value': js(expr)}
    if arg:
        d['arg'] = arg
    return d

def el(name, cls=None, children=None, props=None, directives=None,
       frm='', text=None, expr=None, events=None, key=None, style=None):
    p = dict(props or {})
    if cls:
        p['class'] = cls
    if style:
        p['style'] = style
    if key is not None:
        p['key'] = js(key)
    node = {'id': nid(), 'from': frm, 'name': name, 'props': p,
            'events': events or {}, 'locked': False}
    if text is not None:
        node['children'] = text
    elif expr is not None:
        node['children'] = js(expr)
    elif children is not None:
        node['children'] = children
    else:
        node['children'] = []
    node['invisible'] = False
    node['directives'] = directives or []
    return node

def tag(text=None, expr=None, props=None):
    return el('ElTag', props=props or {'size': 'small', 'effect': 'plain'},
              text=text, expr=expr, frm='element-plus')

def div(cls=None, children=None, **kw):
    return el('div', cls, children, **kw)

def span(text=None, expr=None, cls=None, **kw):
    return el('span', cls, text=text, expr=expr, **kw)

def p(text=None, expr=None, cls=None, **kw):
    return el('p', cls, text=text, expr=expr, **kw)

def h3(text=None, expr=None, cls=None, **kw):
    return el('h3', cls, text=text, expr=expr, **kw)

def h2(text=None, expr=None, cls=None, **kw):
    return el('h2', cls, text=text, expr=expr, **kw)

def icon_el(cls=None):
    return el('component', cls, children=[], props={'is': js('this.$libs.VtjIcons.ArrowRight')})

def load(name):
    path = os.path.join(ROOT, '.vtj', 'files', name + '.json')
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def save(name, data):
    path = os.path.join(ROOT, '.vtj', 'files', name + '.json')
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, separators=(',', ':'))

def load_project():
    path = os.path.join(ROOT, '.vtj', 'projects', 'msr150174.pages9.json')
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def save_project(d):
    path = os.path.join(ROOT, '.vtj', 'projects', 'msr150174.pages9.json')
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        json.dump(d, f, ensure_ascii=False, separators=(',', ':'))

def add_css(data, css):
    data['css'] = data['css'].rstrip() + '\n\n/* ---- 补丁新增 ---- */\n' + css.strip() + '\n'

def find(node, cls):
    if isinstance(node, list):
        for i in node:
            r = find(i, cls)
            if r is not None:
                return r
        return None
    if not isinstance(node, dict):
        return None
    props = node.get('props') or {}
    if props.get('class') == cls:
        return node
    return find(node.get('children'), cls)

def walk(node):
    if isinstance(node, list):
        for i in node:
            yield from walk(i)
    elif isinstance(node, dict):
        yield node
        yield from walk(node.get('children'))

# ---------- 校验 ----------
BANNED = ['保证', '百分百', '稳过', '承诺', '包过', '一定可以', '必然', '精准匹配']

def collect_strings(o, out):
    if isinstance(o, str):
        out.append(o)
    elif isinstance(o, list):
        for i in o:
            collect_strings(i, out)
    elif isinstance(o, dict):
        for k, v in o.items():
            if k in ('id', 'from', 'name', 'type'):
                continue
            collect_strings(v, out)
    return out
