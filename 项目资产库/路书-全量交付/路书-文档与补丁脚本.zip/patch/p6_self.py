# -*- coding: utf-8 -*-
"""N7：新增「认识自己」12 题自评 —— 六类相对分，不给类型名，不下结论。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

PID = 'sr0ne7wq'

Q = [
    (0, '动手实践', '拆装、调试、把坏掉的东西弄好，这类事我愿意花时间'),
    (0, '动手实践', '比起先把文档看完，我更愿意直接上手试'),
    (1, '逻辑分析', '一个报错我能顺着往下查，非搞明白为什么不可'),
    (1, '逻辑分析', '数据、表格、规律这类需要坐得住的事，我不排斥'),
    (2, '创意表达', '做海报、短视频、页面这种要「好看」的东西，我有兴趣'),
    (2, '创意表达', '我常能想出让别人觉得新鲜的点子'),
    (3, '沟通协作', '我愿意主动去问、去把话说清楚'),
    (3, '沟通协作', '小组作业里，我常是那个把大家串起来的人'),
    (4, '组织统筹', '排计划、盯进度、把事情推着往前走，我愿意做'),
    (4, '组织统筹', '给我一个目标，我能自己拆成几步'),
    (5, '细节规范', '按规范一步步来、不漏步骤，我做得住'),
    (5, '细节规范', '错别字、对不齐这种小问题，我一眼能看出来'),
]

rows = []
for i, (d, name, text) in enumerate(Q):
    rows.append("  { idx: %d, dim: '%s', text: '%s', score: 0 }" % (i, name, text))
QUESTIONS = '[\n' + ',\n'.join(rows) + '\n]'

def group_block():
    return div('dim-block', [
        div('dim-head', [
            span(expr='this.context.g.name', cls='dim-name'),
            span(expr="this.context.g.items.length + ' 题'", cls='dim-count'),
        ]),
        div('q-list', [
            div('q-row', [
                span(expr="this.context.i + 1", cls='q-idx'),
                span(expr='this.context.q.text', cls='q-text'),
                el('ElRate', 'q-rate', [], frm='element-plus',
                   props={'max': '5', 'size': 'large'},
                   directives=[vtj.d_model('this.context.q.score')]),
            ], directives=[d_for('this.context.g.items', 'q', 'i')]),
        ]),
    ], directives=[d_for('this.dimGroups.value', 'g')])

def score_bar():
    return div('score-row', [
        span(expr='this.context.s.name', cls='score-name'),
        div('score-track', [
            div('score-fill', [], props={'class': js("Object.assign({ 'score-fill': true })"),
                                         'style': js("'width:' + this.context.s.rel + '%'")}),
        ]),
        span(expr="this.context.s.rel + '%'", cls='score-val'),
    ], directives=[d_for('this.dimScores.value', 's')])

nodes = [div('self-page', [
    div('self-header', [
        div('self-title', [
            el('h2', None, text='认识自己'),
            el('p', 'self-desc',
               text='12 道题，六类。1 = 完全不像我，5 = 很像我。结果只把偏好摆出来看，不做判定、不给类型名。'),
        ]),
        span(expr="this.answered.value + ' / 12 已答'", cls='self-progress'),
    ]),
    div('self-body', [
        el('div', 'self-form', [
            group_block(),
            div('self-actions', [
                el('ElButton', None, text='重新作答', frm='element-plus',
                   events={'click': {'name': 'click', 'handler': js('this.handleReset'), 'modifiers': {}}}),
                el('ElButton', None, text='看结果', frm='element-plus',
                   props={'type': 'primary'},
                   events={'click': {'name': 'click', 'handler': js('this.handleSubmit'), 'modifiers': {}}}),
            ]),
        ], directives=[d_if('!this.showResult.value')]),
        div('self-result', [
            div('result-card', [
                span('六类相对分', cls='result-title'),
                span('相对分只表示你在六类里更偏向哪边，不表示能力强弱。', cls='result-sub'),
                score_bar(),
                el('p', 'result-note',
                   text='这只是把你刚才的选择摆出来看，不是测评结论，也不代表你适合或不适合什么。'),
                div('result-actions', [
                    el('ElButton', None, text='拿这份结果去看岗位', frm='element-plus',
                       props={'type': 'primary'},
                       events={'click': {'name': 'click', 'handler': js('this.handleToCareer'), 'modifiers': {}}}),
                    el('ElButton', None, text='重新作答', frm='element-plus',
                       events={'click': {'name': 'click', 'handler': js('this.handleReset'), 'modifiers': {}}}),
                ]),
            ]),
        ], directives=[d_if('this.showResult.value')]),
    ]),
])]

data = {
    'id': PID,
    'css': """.self-page {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  padding: 20px 28px 24px;
  box-sizing: border-box;
  background: #fff;
  border-radius: 12px;
  margin: 12px;
  overflow-y: auto;
}
.self-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  padding-bottom: 14px;
  border-bottom: 1px solid #f0f1f3;
}
.self-title h2 { margin: 0 0 6px; font-size: 18px; color: #1f2937; }
.self-desc { margin: 0; font-size: 12.5px; line-height: 1.8; color: #6b7280; max-width: 640px; }
.self-progress {
  flex-shrink: 0;
  font-size: 12px;
  color: #2f6bff;
  background: #eef3fe;
  border-radius: 14px;
  padding: 4px 10px;
}
.self-body { padding-top: 16px; }
.self-form { display: flex; flex-direction: column; gap: 18px; }
.dim-block { border: 1px solid #eef0f3; border-radius: 10px; padding: 14px 16px; }
.dim-head { display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px; }
.dim-name { font-size: 13.5px; font-weight: 600; color: #1f2937; }
.dim-count { font-size: 11px; color: #9ca3af; }
.q-row { display: flex; align-items: center; gap: 10px; padding: 6px 0; }
.q-idx {
  flex-shrink: 0; width: 20px; height: 20px; line-height: 20px; text-align: center;
  border-radius: 50%; background: #f3f4f6; color: #6b7280; font-size: 11px;
}
.q-text { flex: 1; min-width: 0; font-size: 13px; color: #374151; line-height: 1.7; }
.q-rate { flex-shrink: 0; }
.self-actions {
  display: flex; justify-content: flex-end; gap: 10px;
  padding-top: 4px;
}
.self-result { padding-top: 4px; }
.result-card { border: 1px solid #eef0f3; border-radius: 10px; padding: 18px 20px; }
.result-title { display: block; font-size: 14px; font-weight: 600; color: #1f2937; }
.result-sub { display: block; margin-top: 4px; font-size: 11.5px; color: #9ca3af; }
.score-row { display: flex; align-items: center; gap: 10px; margin-top: 12px; }
.score-name { width: 76px; flex-shrink: 0; font-size: 12.5px; color: #4b5563; }
.score-track { flex: 1; height: 8px; background: #f3f4f6; border-radius: 4px; overflow: hidden; }
.score-fill { height: 100%; background: #2f6bff; border-radius: 4px; }
.score-val { width: 42px; text-align: right; font-size: 12px; color: #6b7280; }
.result-note {
  margin: 16px 0 0; padding: 10px 12px; background: #f7f8fa; border-radius: 6px;
  font-size: 12px; line-height: 1.8; color: #6b7280;
}
.result-actions { display: flex; gap: 10px; margin-top: 14px; }
""",
    'name': 'SelfAssessment',
    'refs': {'showResult': js('false')},
    'emits': [],
    'nodes': nodes,
    'props': [],
    'slots': [],
    'state': {'questions': js(QUESTIONS)},
    'watch': [],
    'expose': [],
    'inject': [],
    'locked': False,
    'apiMode': 'composition',
    'methods': {
        'handleSubmit': fn("""() => {
  if (this.answered.value < 12) {
    this.$message.warning('还剩 ' + (12 - this.answered.value) + ' 题没答');
    return;
  }
  this.showResult.value = true;
}"""),
        'handleReset': fn("""() => {
  this.state.questions.forEach((q) => {
    q.score = 0;
  });
  this.showResult.value = false;
}"""),
        'handleToCareer': fn("""() => {
  this.$router.push('/page/career-library');
}"""),
    },
    'provide': {},
    'computed': {
        'answered': fn("() => {\n  return this.state.questions.filter((q) => q.score > 0).length;\n}"),
        'dimGroups': fn("""() => {
  const order = ['动手实践', '逻辑分析', '创意表达', '沟通协作', '组织统筹', '细节规范'];
  return order.map((name) => ({
    name: name,
    items: this.state.questions.filter((q) => q.dim === name)
  }));
}"""),
        'dimScores': fn("""() => {
  const groups = this.dimGroups.value;
  const totals = groups.map((g) => ({
    name: g.name,
    score: g.items.reduce((a, q) => a + (q.score || 0), 0)
  }));
  const max = Math.max.apply(null, totals.map((t) => t.score));
  return totals.map((t) => ({
    name: t.name,
    score: t.score,
    rel: max > 0 ? Math.round((t.score / max) * 100) : 0
  }));
}"""),
    },
    'reactives': {},
    'lifeCycles': {},
    '__VERSION__': '1794500000000',
    'composables': [],
    'dataSources': {},
    '__VTJ_BLOCK__': False,
}

vtj.save(PID, data)

proj = vtj.load_project()
ml = next(p for p in proj['pages'] if p['name'] == 'MainLayout')
if not any(c['name'] == 'SelfAssessment' for c in ml['children']):
    entry = {
        'id': PID, 'dir': False, 'raw': False, 'icon': '', 'mask': False, 'meta': '',
        'name': 'SelfAssessment', 'page': 'page', 'pure': True, 'type': 'page',
        'cache': False, 'style': None, 'title': '认识自己', 'hidden': False,
        'layout': False, 'filePath': 'self-assessment', 'needLogin': False,
        'routePath': '/page/self-assessment'
    }
    idx = next(i for i, c in enumerate(ml['children']) if c['name'] == 'ChatWorkspace')
    ml['children'].insert(idx + 1, entry)
    vtj.save_project(proj)
    print('registered SelfAssessment')
print('self page ok')
