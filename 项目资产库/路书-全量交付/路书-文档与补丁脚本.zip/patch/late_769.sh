cd /c/Users/ASUS/WorkBuddy/2026-11-12-20-44-44/unz2 && python - <<'PYEOF'
import re

# 1) i18n 补 key
p='src/i18n/index.ts'
s=open(p,encoding='utf-8').read()
s=s.replace("""  'chat.attachedTo': { zh: '这条问题带了 {{n}} 个附件', en: '{{n}} attachment(s) with this question' },""",
"""  'chat.attachedTo': { zh: '这条问题带了 {{n}} 个附件', en: '{{n}} attachment(s) with this question' },
  'chat.sources': { zh: '来源', en: 'Sources' },
  'chat.followUp': { zh: '就这条追问', en: 'Follow up on this' },
  'chat.traceFoot': {
    zh: '只挂载这几组的原文；未命中的分组不参与回答。',
    en: 'Only these groups are mounted; the rest take no part in the answer.'
  },
  'chat.traceAll': { zh: '检索 {{n}} 组', en: 'Searched {{n}} groups' },
  'a.rows': { zh: '{{n}} 行', en: '{{n}} rows' },
  'm.fromChat': { zh: '对话上传', en: 'From chat' },
  'm.foot': {
    zh: '材料只作补充，回答的出处仍然只认 A–E 五组；产出的文件由回答内容拆成，不新增资料里没有的数字。',
    en: 'Attachments add context only — citations stay with groups A–E. Output files are split from the answer, never adding numbers the sources do not hold.'
  },""")
open(p,'w',encoding='utf-8').write(s)

# 2) ChatPanel 文案
p='src/components/ChatPanel.vue'
s=open(p,encoding='utf-8').read()
s=s.replace("""              <span class="trace-label"
                >检索 {{ msg.hitGroups.length }} 组 · 命中 {{ msg.hitGroups.length }} 组</span
              >""","""              <span class="trace-label">{{ t('chat.traceAll', { n: msg.hitGroups.length }) }}</span>""")
s=s.replace("""              <span class="trace-toggle">{{ traceOpen[msg.id] ? '收起' : '展开看' }}</span>""",
"""              <span class="trace-toggle">{{ traceOpen[msg.id] ? t('c.less') : t('c.more') }}</span>""")
s=s.replace("""              <div class="trace-foot">
                只挂载这几组的原文；未命中的分组不参与回答。
              </div>""","""              <div class="trace-foot">{{ t('chat.traceFoot') }}</div>""")
s=s.replace("""            <div class="ref-title">📚 来源</div>""","""            <div class="ref-title">📚 {{ t('chat.sources') }}</div>""")
s=s.replace("""              @click="quoteMsg(msg)">↩ 就这条追问</button>""","""              @click="quoteMsg(msg)">↩ {{ t('chat.followUp') }}</button>""")
s=s.replace("""              <span class="mf-chunks">{{ f.chunks }} 段</span>""","""              <span class="mf-chunks">{{ t('u.done', { n: f.chunks }) }}</span>""")

# en-sum 前置：英文用户先看摘要，再决定要不要读中文原文
en_block = """          <!-- 英文界面下的摘要：明确标注「以中文原文为准」，不冒充原文 -->
          <div v-if="isEn && msg.enSummary" class="en-sum">
            <div class="en-tag">{{ t('chat.enNote') }}</div>
            <div class="en-body">{{ msg.enSummary }}</div>
          </div>

"""
s = s.replace(en_block, "")
s = s.replace("""          <div :class="['bubble-content', { caret: msg.typing }]">{{ msg.content }}</div>""",
en_block + """          <div :class="['bubble-content', { caret: msg.typing }]">{{ msg.content }}</div>""")
open(p,'w',encoding='utf-8').write(s)

# 3) ArtifactList 行数后缀
p='src/components/ArtifactList.vue'
s=open(p,encoding='utf-8').read()
s=s.replace("""              <span>{{ f.items || 0 }} 行</span>""","""              <span>{{ t('a.rows', { n: f.items || 0 }) }}</span>""")
open(p,'w',encoding='utf-8').write(s)
print('done')
PYEOF