cd /c/Users/ASUS/WorkBuddy/2026-11-12-20-44-44/unz2 && python - <<'PYEOF'
p='src/components/ChatPanel.vue'
s=open(p,encoding='utf-8').read()

# 输入区顶部加一行语音状态
s=s.replace("""      <div class="input-shell">""","""      <Transition name="vline">
        <div v-if="voiceHint" class="voice-line">
          <i class="vl-dot"></i>
          <span class="vl-text">{{ voiceHint }}</span>
        </div>
      </Transition>

      <div class="input-shell">""")

s=s.replace("""          <div class="ia-left">
            <VoiceButton @text="insertVoice"></VoiceButton>""","""          <div class="ia-left">
            <VoiceButton @text="insertVoice" @hint="voiceHint = $event"></VoiceButton>""")

s=s.replace("""  /* ---------- 语音 ---------- */""","""  /* ---------- 语音 ---------- */
  const voiceHint = ref('');""")

s=s.replace("""  .input-shell {
    display: flex;
    flex-direction: column;
  }""","""  .input-shell {
    display: flex;
    flex-direction: column;
  }
  .voice-line {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 5px 9px;
    border-radius: 7px;
    background: #f4f7fd;
    border: 1px solid #e3eaf8;
    font-size: 11.5px;
    color: #4b5768;
  }
  .vl-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #2f6bff;
    animation: vlPulse 1.1s ease-in-out infinite;
  }
  .vl-text {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  @keyframes vlPulse {
    50% {
      opacity: 0.3;
    }
  }
  .vline-enter-active {
    animation: vlIn 0.18s var(--m-ease) both;
  }
  .vline-leave-active {
    transition: opacity 0.14s linear;
  }
  .vline-leave-to {
    opacity: 0;
  }
  @keyframes vlIn {
    from {
      opacity: 0;
      transform: translateY(-3px);
    }
  }""")
open(p,'w',encoding='utf-8').write(s)
print('chat voice line ok')
PYEOF