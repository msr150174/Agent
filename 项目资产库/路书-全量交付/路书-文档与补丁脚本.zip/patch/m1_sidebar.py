# -*- coding: utf-8 -*-
"""m1：侧栏折叠成图标条（对应 07-顶栏与菜单栏「未激活收成图标」的招）"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if

d = vtj.load('2r0c0a38')

# ---- 脚本：折叠状态 ----
d['refs']['collapsed'] = js('false')
d['methods']['toggleCollapse'] = fn(
    '() => {\n  this.collapsed.value = !this.collapsed.value;\n}'
)

# ---- 图标改回文字符号，和 .vue 一致 ----
d['refs']['navItems'] = js(
    "[\n  { label: '对话', route: '/page/chat-workspace', icon: '❝' },\n"
    "  { label: '认识自己', route: '/page/self-assessment', icon: '✎' },\n"
    "  { label: '看清路', route: '/page/career-library', icon: '◎' },\n"
    "  { label: '路线图', route: '/page/growth-plan', icon: '☰' },\n"
    "  { label: '知识库', route: '/page/knowledge-base', icon: '▤' }\n]"
)
d['refs']['teacherNav'] = js(
    "[\n  { label: '调用日志', route: '/page/call-logs', icon: '≡' },\n"
    "  { label: '知识库管理', route: '/page/kb-manager', icon: '⚙' }\n]"
)


def nav_item(item_expr, extra_cls, route_expr):
    return div(
        js(
            "Object.assign({ %s }, { active: this.isActive(%s) })"
            % (extra_cls, route_expr)
        ),
        [
            span(expr='this.context.item.icon', cls='nav-ico'),
            span(expr='this.context.item.label', cls='nav-label'),
            span(expr='this.context.item.label', cls='nav-tip'),
        ],
        directives=[d_for(item_expr, 'item', 'index')],
        events={'click': {'name': 'click', 'handler': js('this.handleNav(this.context.item.route)'), 'modifiers': {}}},
    )


item_student = nav_item('this.navItems.value', "'nav-item': true", 'this.context.item.route')

# nav-badge 只在「认识自己」那一项出现
item_student['children'].insert(
    2,
    span(
        '12 题',
        cls='nav-badge',
        directives=[d_if("this.context.item.route === '/page/self-assessment'")],
    ),
)

item_teacher = nav_item(
    'this.teacherNav.value', "'nav-item': true, subtlish: true", 'this.context.item.route'
)
# 教师项用 nav-item subtle
item_teacher['props']['class'] = js(
    "Object.assign({ 'nav-item': true, subtle: true }, { active: this.isActive(this.context.item.route) })"
)

tree = el(
    'aside',
    js("Object.assign({ 'app-sidebar': true }, { collapsed: this.collapsed.value })"),
    [
        div(
            'brand',
            [
                div('brand-logo', '路'),
                div(
                    'brand-info',
                    [
                        div('brand-name', '路书工作台'),
                        div('brand-sub', '你自己的职业规划助手'),
                    ],
                ),
            ],
        ),
        el(
            'button',
            'collapse-btn',
            [span('‹', cls=js("Object.assign({ chev: true }, { flip: this.collapsed.value })"))],
            props={'title': js("this.collapsed.value ? '展开侧栏' : '收成图标条'")},
            events={'click': {'name': 'click', 'handler': js('this.toggleCollapse()'), 'modifiers': {}}},
        ),
        div('demo-chip', '演示数据 · 正式版接 A–E 五组知识库'),
        el(
            'nav',
            'nav',
            [
                span('我用得到的', cls='nav-group-title'),
                item_student,
                div(
                    'nav-group-title teacher-toggle',
                    [
                        span('教师入口', cls='nav-label'),
                        span(
                            expr="'学生不可见 · ' + (this.teacherOpen.value ? '收起' : '展开')",
                            cls='teacher-note',
                        ),
                    ],
                    events={'click': {'name': 'click', 'handler': js('this.toggleTeacher'), 'modifiers': {}}},
                ),
                div(
                    'teacher-block',
                    [
                        div('teacher-hint', '这两页是给老师看链路和维护知识库的，学生端不显示。'),
                        item_teacher,
                    ],
                    directives=[d_if('this.teacherOpen.value')],
                ),
            ],
        ),
        div(
            'current-user',
            [
                div(expr='this.currentUser.avatarText', cls='user-avatar'),
                div(
                    'user-info',
                    [
                        div(expr='this.currentUser.name', cls='user-name'),
                        div(expr='this.currentUser.role', cls='user-role'),
                    ],
                ),
            ],
        ),
    ],
)

d['nodes'] = [tree]
vtj.save('2r0c0a38', d)
print('2r0c0a38 ok, nodes:', len(list(vtj.walk(d['nodes']))))
