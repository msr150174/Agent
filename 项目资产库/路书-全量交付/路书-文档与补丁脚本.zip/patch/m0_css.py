# -*- coding: utf-8 -*-
"""
m0：把 .vue 的 <style> 同步进 DSL 的 css 字段。

两种模式：
  ① 覆盖（默认）：DSL 节点类名与 .vue 一致时，视觉以运行期为准，整份替换最干净。
  ② 追加（APPEND 里的两页）：DSL 沿用自己那套类名（career-card / growth-plan-page），
     与手写 .vue 不同。整份覆盖会让节点失去全部样式，所以保留原有块、把 .vue 的样式追加在后面。
     追加顺序刚好：原有在前（保结构可用），新的在后（视觉以运行期为准）。
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj

VUE = os.path.join(vtj.ROOT, 'src')

B = '/* ==== 以下由 patch/m0_css.py 从 .vue 同步 ==== */'
E = '/* ==== .vue 同步结束 ==== */'

MAP = {
    '2r0c0a38': 'components/AppSidebar.vue',
    'hr0d0qx3': 'views/main-layout.vue',
    '8r0cd8oa': 'components/ChatPanel.vue',
    'kr0dwyr8': 'views/chat-workspace.vue',
    'br0cz38c': 'components/ReferencePanel.vue',
    'qr0e8iq5': 'views/career-library.vue',
    'tr0e9af6': 'views/growth-plan.vue',
    'wr0ea12x': 'views/call-logs.vue',
    'nr0dxtni': 'views/knowledge-base.vue',
    'sr0ne7wq': 'views/self-assessment.vue',
    'zr0eap34': 'views/kb-manager.vue',
    'er0d043h': 'views/login.vue',
    '5r0c26ix': 'components/SessionList.vue',
}

# 这两页 DSL 用的是自己的类名，只能追加
APPEND = {'qr0e8iq5', 'tr0e9af6'}


def style_of(path):
    if not os.path.exists(path):
        return None
    src = open(path, encoding='utf-8').read()
    m = re.search(r'<style[^>]*>(.*?)</style>', src, re.S)
    return m.group(1).strip() if m else None


def strip_wrapped(css):
    while B in css and E in css:
        a = css.index(B)
        b = css.index(E) + len(E)
        css = (css[:a] + css[b:]).strip()
    return css


for fid, rel in MAP.items():
    p = os.path.join(vtj.ROOT, '.vtj', 'files', fid + '.json')
    if not os.path.exists(p):
        print('skip', fid)
        continue
    css = style_of(os.path.join(VUE, rel))
    if css is None:
        print('no style', fid, rel)
        continue
    d = vtj.load(fid)
    if fid in APPEND:
        base = strip_wrapped(d.get('css') or '')
        d['css'] = base.rstrip() + '\n\n' + B + '\n' + css + '\n' + E + '\n'
        mode = 'append'
    else:
        d['css'] = css
        mode = 'replace'
    vtj.save(fid, d)
    print(fid, mode, rel, len(d['css']))
print('ok')
