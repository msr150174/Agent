# -*- coding: utf-8 -*-
"""N11：右栏收敛为「本次来源 / 知识库 / 我的档案」，去掉类型代号，加免责句。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_for, d_if, d_else

NAME = 'br0cz38c'
d = vtj.load(NAME)

KB = """[
  { id: 'A', name: 'A 专业与岗位', count: 8, description: '各专业对口岗位、能力项与本校去向' },
  { id: 'B', name: 'B 证书与考试', count: 6, description: '1+X、等级考试、专插本科目说明' },
  { id: 'C', name: 'C 岗位与能力', count: 9, description: '按岗位拆到能力项，可逐条对照' },
  { id: 'D', name: 'D 行业与就业数据', count: 7, description: '本校回收样本与招聘观察' },
  { id: 'E', name: 'E 求职技能', count: 7, description: '简历、面试、项目表达' }
]"""

PROFILE = """({
  name: '李同学',
  major: '计算机应用技术',
  grade: '大一',
  goal: '还没定：专插本 / 就业',
  dims: []
})"""

d['props'] = [
    {'name': 'references', 'type': 'Array', 'default': {'type': 'JSExpression', 'value': '() => []'}, 'required': False},
    {'name': 'profile', 'type': 'Object', 'default': {'type': 'JSExpression', 'value': '() => ' + PROFILE}, 'required': False},
    {'name': 'knowledgeList', 'type': 'Array', 'default': {'type': 'JSExpression', 'value': '() => ' + KB}, 'required': False},
]

d['refs'] = {
    'tabs': js("""[
  { key: 'references', label: '本次来源' },
  { key: 'knowledge', label: '知识库' },
  { key: 'profile', label: '我的档案' }
]"""),
    'activeTab': js("'references'"),
}
d['state'] = {}
d['computed'] = {}
d['reactives'] = {}
d['methods'] = {
    'handleTabChange': fn("(key) => {\n  this.activeTab.value = key;\n}"),
}

def tab_btn():
    return el('button', None, expr='this.context.tab.label',
              props={'key': js('this.context.tab.key'),
                     'class': js("Object.assign({ 'tab-btn': true }, { active: this.activeTab.value === this.context.tab.key })")},
              events={'click': {'name': 'click', 'handler': js('this.handleTabChange(this.context.tab.key)'), 'modifiers': {}}},
              directives=[d_for('this.tabs.value', 'tab')])

def ref_card():
    return div('ref-card', [
        div('ref-title', expr='this.context.item.title'),
        div('ref-excerpt', expr='this.context.item.excerpt'),
        div('ref-meta', [
            span(expr='this.context.item.group'),
            span(expr='this.context.item.date'),
        ]),
    ], directives=[d_for('this.references', 'item')])

def kb_card():
    return div('kb-card', [
        div('kb-top', [
            span(expr='this.context.kb.name', cls='kb-name'),
            span(expr="this.context.kb.count + ' 篇'", cls='kb-badge'),
        ]),
        div('kb-desc', expr='this.context.kb.description'),
    ], directives=[d_for('this.knowledgeList', 'kb')])

def dim_bar():
    return div('dim-row', [
        span(expr='this.context.d.name', cls='dim-name'),
        div('dim-track', [
            el('div', 'dim-fill', [], props={'style': js("'width:' + this.context.d.rel + '%'")}),
        ]),
    ], directives=[d_for('this.profile.dims', 'd')])

profile_card = div('profile-card', [
    div('profile-header', [
        div('profile-avatar', expr="this.profile.name ? this.profile.name.slice(0, 1) : '学'"),
        div('profile-info', [
            div('profile-name', expr='this.profile.name'),
            div('profile-meta', [
                span(expr='this.profile.major'),
                span(' · '),
                span(expr='this.profile.grade'),
            ]),
        ]),
    ]),
    div('profile-section', [
        div('profile-label', text='现在想解决'),
        div('profile-value', expr='this.profile.goal'),
    ]),
    div('profile-section', [
        div('profile-label', text='六类相对分'),
        el('div', 'dim-list', [dim_bar()], directives=[d_if('this.profile.dims && this.profile.dims.length')]),
        el('div', 'dim-hint', text='还没做「认识自己」的 12 道题，做完这里会显示六类偏好。',
           directives=[d_else()]),
    ]),
    el('p', 'profile-note',
       text='相对分只表示你在这六类里更偏向哪边，不是测评结论，也不代表你适合或不适合什么。'),
])

section_refs = el('div', 'panel-section', [
    div('section-title', text='本次来源'),
    div('ref-list', [ref_card()]),
    el('div', 'empty', text='这次回答没有引用 —— 没有出处的答案，我不给。',
       directives=[d_if('!this.references || this.references.length === 0')]),
], directives=[d_if("this.activeTab.value === 'references'")])

section_kb = el('div', 'panel-section', [
    div('section-title', text='知识库 · A–E 五组 37 篇'),
    div('kb-list', [kb_card()]),
], directives=[d_if("this.activeTab.value === 'knowledge'")])

section_profile = el('div', 'panel-section', [
    div('section-title', text='我的档案'),
    profile_card,
], directives=[d_if("this.activeTab.value === 'profile'")])

d['nodes'] = [div('reference-panel', [
    div('tab-header', [tab_btn()]),
    div('tab-content', [section_refs, section_kb, section_profile]),
])]

d['css'] = """.reference-panel {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #fff;
  border: 1px solid #eef0f3;
  border-radius: 12px;
  box-sizing: border-box;
  overflow: hidden;
}
.tab-header {
  display: flex;
  flex-shrink: 0;
  border-bottom: 1px solid #f0f1f3;
}
.tab-btn {
  flex: 1;
  padding: 12px 0;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 12.5px;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: all .15s ease;
}
.tab-btn:hover { color: #1f2937; }
.tab-btn.active { color: #2f6bff; border-bottom-color: #2f6bff; font-weight: 500; }
.tab-content { flex: 1; min-height: 0; overflow-y: auto; padding: 14px; }
.section-title { font-size: 12px; color: #9ca3af; margin-bottom: 10px; letter-spacing: .3px; }
.ref-list { display: flex; flex-direction: column; gap: 10px; }
.ref-card {
  border: 1px solid #eef0f3;
  border-radius: 8px;
  padding: 10px 12px;
  background: #fbfcfe;
}
.ref-title { font-size: 12.5px; font-weight: 600; color: #1f2937; line-height: 1.6; }
.ref-excerpt { margin-top: 4px; font-size: 11.5px; line-height: 1.7; color: #6b7280; }
.ref-meta { margin-top: 6px; display: flex; gap: 8px; font-size: 11px; color: #9ca3af; }
.kb-list { display: flex; flex-direction: column; gap: 8px; }
.kb-card { border: 1px solid #eef0f3; border-radius: 8px; padding: 9px 12px; }
.kb-top { display: flex; align-items: center; justify-content: space-between; }
.kb-name { font-size: 12.5px; color: #1f2937; font-weight: 500; }
.kb-badge { font-size: 11px; color: #2f6bff; background: #eef3fe; border-radius: 10px; padding: 1px 7px; }
.kb-desc { margin-top: 4px; font-size: 11.5px; line-height: 1.6; color: #9ca3af; }
.profile-card { border: 1px solid #eef0f3; border-radius: 8px; padding: 12px; }
.profile-header { display: flex; align-items: center; gap: 10px; }
.profile-avatar {
  width: 34px; height: 34px; border-radius: 50%; background: #e0e7ff; color: #2f6bff;
  display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 13px;
}
.profile-name { font-size: 13px; font-weight: 600; color: #1f2937; }
.profile-meta { font-size: 11.5px; color: #9ca3af; margin-top: 2px; }
.profile-section { margin-top: 12px; }
.profile-label { font-size: 11px; color: #9ca3af; margin-bottom: 4px; }
.profile-value { font-size: 12.5px; color: #374151; }
.dim-row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.dim-name { width: 58px; flex-shrink: 0; font-size: 11.5px; color: #6b7280; }
.dim-track { flex: 1; height: 6px; background: #f3f4f6; border-radius: 3px; overflow: hidden; }
.dim-fill { height: 100%; background: #2f6bff; border-radius: 3px; }
.dim-hint { font-size: 11.5px; line-height: 1.7; color: #b9bdc4; }
.profile-note {
  margin: 12px 0 0; padding-top: 10px; border-top: 1px dashed #eef0f3;
  font-size: 11px; line-height: 1.7; color: #9ca3af;
}
.empty { padding: 24px 0; text-align: center; font-size: 12px; line-height: 1.8; color: #b9bdc4; }
"""
vtj.save(NAME, d)
print('reference panel ok')
