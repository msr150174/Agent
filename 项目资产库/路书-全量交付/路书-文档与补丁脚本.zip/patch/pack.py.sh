cd /c/Users/ASUS/WorkBuddy/2026-11-12-20-44-44 && cp "路书-多语言与文件流转说明.md" pkg_doc.md 2>/dev/null; python - <<'EOF'
import os, zipfile

root = 'unz2'
out = '路书-VTJ-多语言与文件流转版.zip'
skip_dirs = {'node_modules', 'dist', '.git', '.vite', 'tmp_files'}
skip_files = {'chkdsl.mjs'}
skip_prefix = ('cdp',)

include_root_files = [
    '.editorconfig', '.gitignore', '.npmrc', '.prettierrc', 'index.html',
    'package.json', 'package-lock.json', 'proxy.config.ts', 'tsconfig.json',
    'tsconfig.node.json', 'vite.config.ts', 'env.json', 'env.local.json',
    'env.sit.json', 'env.uat.json'
]
docs = {
    '路书-多语言与文件流转说明.md': 'I18N-FILES.md',
    '路书-交互与视觉移植清单-v2.md': 'MOTION-v2.md',
    '路书-交互与视觉移植清单.md': 'MOTION.md',
    '路书-原型补丁清单-v2.md': 'PATCHES.md',
}

files = []
for f in include_root_files:
    p = os.path.join(root, f)
    if os.path.exists(p):
        files.append((p, f))
for d in ('src', '.vtj', '.vscode'):
    for base, dirs, fs in os.walk(os.path.join(root, d)):
        dirs[:] = [x for x in dirs if x not in skip_dirs]
        for fn in fs:
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, root).replace('\\', '/')
            if fn in skip_files or fn.startswith(skip_prefix):
                continue
            files.append((p, rel))

for src, arc in docs.items():
    if os.path.exists(src):
        files.append((src, arc))

with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, arc in files:
        z.write(p, arc)

size = os.path.getsize(out)
print(f'{out}: {len(files)} files, {size/1024:.0f} KB')
EOF