# -*- coding: utf-8 -*-
"""m5：职业库（岗位卡匹配度行内条）+ 路线图（勾选回报 toast）
   这两页 DSL 的类名是 career-* / growth-*，和 .vue 不同，
   所以这里的样式按 DSL 自己的类名补，不动原有映射。"""
import os, sys, json
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn

PKG = os.path.join(vtj.ROOT, '..', 'pkg')


def restore_css(fid):
    b = json.load(open(os.path.join(PKG, '.vtj', 'files', fid + '.json'), encoding='utf-8'))
    d = vtj.load(fid)
    d['css'] = b['css']
    return d


# ══════════════ 职业库 ══════════════
d = restore_css('qr0e8iq5')
root = d['nodes'][0]

badges = vtj.find(root, 'career-badges')
if badges:
    keep = None
    for c in badges['children']:
        # 只留「需求」那个标签
        for n in vtj.walk(c):
            if isinstance(n.get('children'), str) and '需求' in n['children']:
                keep = c
    badges['children'] = [keep] if keep else []

summary = vtj.find(root, 'career-summary')
row = div('career-match', [
    span('匹配度参考', cls='career-match-label'),
    span(cls='career-match-track', children=[
        el('i', style=js("'width: ' + this.context.career.match")),
    ]),
    span(expr='this.context.career.match', cls='career-match-val'),
])
card = vtj.find(root, 'career-card')
idx = card['children'].index(summary)
card['children'].insert(idx + 1, row)
card['props']['style'] = js("'animation-delay: ' + (this.context.index * 45) + 'ms'")

d['css'] = d['css'].rstrip() + """

/* ---- 岗位卡匹配度行内条 ---- */
@keyframes careerBar { from { transform: scaleX(0); } to { transform: scaleX(1); } }
@keyframes careerIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
.career-card { animation: careerIn .34s cubic-bezier(.2,.8,.2,1) both; }
.career-card:hover { border-color: #dbe4ff; box-shadow: 0 6px 20px rgba(47,107,255,.09); }
.career-match { display: flex; align-items: center; gap: 8px; margin: 2px 0 10px; }
.career-match-label { font-size: 11px; color: #9ca3af; flex-shrink: 0; }
.career-match-track { flex: 1; min-width: 0; height: 5px; border-radius: 3px; background: #f1f4f9; overflow: hidden; }
.career-match-track i { display: block; height: 100%; border-radius: 3px; background: linear-gradient(90deg, #a9c2ff, #2f6bff); transform-origin: left center; animation: careerBar .55s cubic-bezier(.2,.8,.2,1) both; }
.career-match-val { width: 34px; text-align: right; font-size: 11.5px; font-weight: 600; color: #2f6bff; flex-shrink: 0; }
"""
vtj.save('qr0e8iq5', d)
print('qr0e8iq5 ok')

# ══════════════ 路线图 ══════════════
d = restore_css('tr0e9af6')
d['state']['toastMsg'] = js("''")
d['methods']['showToast'] = fn(
    "(text) => {\n"
    "  this.state.toastMsg = text;\n"
    "  const self = this;\n"
    "  setTimeout(() => { self.state.toastMsg = ''; }, 2200);\n"
    "}"
)
d['methods']['toggleStep'] = fn(
    "(step) => {\n"
    "  step.done = !step.done;\n"
    "  const all = [];\n"
    "  this.state.phases.forEach((p) => p.steps.forEach((s) => all.push(s)));\n"
    "  const done = all.filter((s) => s.done).length;\n"
    "  this.showToast(step.done\n"
    "    ? '记上了 · 已完成 ' + done + '/' + all.length + ' 项'\n"
    "    : '已撤回 · 还剩 ' + (all.length - done) + ' 项');\n"
    "}"
)

root = d['nodes'][0]
root['children'].append(
    div(expr='this.state.toastMsg', cls='growth-toast', directives=[{'id': vtj.nid('d'), 'name': 'vIf', 'value': js('this.state.toastMsg')}])
)

d['css'] = d['css'].rstrip() + """

/* ---- 勾选回报 toast ---- */
@keyframes gToast { from { opacity: 0; transform: translate(-50%, 10px); } to { opacity: 1; transform: translate(-50%, 0); } }
.growth-toast { position: fixed; left: 50%; bottom: 28px; z-index: 40; padding: 8px 16px; border-radius: 8px;
  background: #1f2937; color: #fff; font-size: 12.5px; line-height: 1.5; white-space: nowrap;
  box-shadow: 0 8px 24px rgba(20,25,35,.22); animation: gToast .24s cubic-bezier(.2,.8,.2,1) both; }
"""
vtj.save('tr0e9af6', d)
print('tr0e9af6 ok')
