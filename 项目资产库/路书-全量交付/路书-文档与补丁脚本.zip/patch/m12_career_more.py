# -*- coding: utf-8 -*-
"""m12：职业库 DSL 的岗位卡加「展开细看」（参考实现里「▲ 展开到最高」那招）。

展开区只把已有事实重排成三步，不新增结论：
  门槛 / 本轮要补的 / 薪资口径（没样本就明说没样本）
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn, d_if, d_for


def find(n, c):
    if isinstance(n, list):
        for i in n:
            r = find(i, c)
            if r is not None:
                return r
        return None
    if not isinstance(n, dict):
        return None
    p = n.get('props') or {}
    if isinstance(p.get('class'), str) and p['class'] == c:
        return n
    return find(n.get('children'), c)


d = vtj.load('qr0e8iq5')

d['state']['opened'] = {'type': 'JSExpression', 'value': '{}'}

d['methods']['toggleCareerDetail'] = {'type': 'JSFunction', 'value': """(id) => {
  const o = this.opened.value;
  o[id] = !o[id];
}"""}

d['methods']['careerDetailLines'] = {'type': 'JSFunction', 'value': """(career) => {
  const skills = (career.skills || []).join(' / ');
  return [
    '门槛：' + (career.experience || '知识库未标注') + '；核心技能 ' + skills + '。',
    '本轮要补的：' + (career.gap || '知识库未收录'),
    career.salary
      ? '薪资口径：' + career.salary + '，来源说明为「' + (career.salaryNote || '') + '」。'
      : '薪资口径：本校近两届回收样本不足 5 条，按事实规则留空，不给区间。'
  ];
}"""}

card = find(d['nodes'], 'career-card')
assert card is not None
card['props']['class'] = 'career-card spot'

more = el('button', 'job-more press',
          children=[
              span(expr="this.opened.value[career.id] ? '收起' : '展开细看'", cls='jm-label'),
              span('▾', cls='jm-chev'),
          ],
          events={'click': fn('() => this.toggleCareerDetail(career.id)')})

detail = div('job-detail', [
    div('jd-row', [
        span(expr='String(li + 1).padStart(2, "0")', cls='idx'),
        span(expr='line', cls='jd-text'),
    ], directives=[d_for('this.careerDetailLines(career)', 'line', 'li')]),
    div('jd-note', [el('span', children='这三条都能在知识库对上原文，不是额外的建议。')]),
], directives=[d_if('this.opened.value[career.id]')])

# 插在 career-source 之后（展开区永远在卡片最底部）
kids = card['children']
src_i = next(i for i, c in enumerate(kids) if ((c.get('props') or {}).get('class') == 'career-source'))
kids[src_i + 1:src_i + 1] = [more, detail]

vtj.save('qr0e8iq5', d)
print('career card children:', len(card['children']))
