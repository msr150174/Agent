# -*- coding: utf-8 -*-
"""N5/N10：路线图、知识库、调用日志、知识库管理四页的数据与文案换口径。"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, p, h2, js, fn, d_for, d_if

def set_text(root, cls, text):
    n = vtj.find(root, cls)
    if n is not None:
        n['children'] = text
        return True
    return False

# ================= 路线图 =================
NAME = 'tr0e9af6'
d = vtj.load(NAME)
root = d['nodes'][0]

d['state'] = {
    'targetCareer': js("'Java 后端开发（初级）'"),
    'goalSentence': js("'把一门后端语言学通到能写增删改查，绩点稳在专业前 40%，大二下把「专插本还是就业」定下来。'"),
    'totalSteps': js('12'),
    'completedSteps': js('6'),
    'overallProgress': js('50'),
    'phases': js("""[
  {
    id: 1,
    name: '大一上 · 把底子打住',
    period: '2025-09 ~ 2026-01',
    status: 'done',
    desc: '目标：不挂科，把一门语言的基础语法写熟。',
    steps: [
      { id: 11, label: 'C 语言或 Java 基础课学完，独立写完 3 个小练习', done: true, cert: null },
      { id: 12, label: '每周固定 6 小时上机，不攒到期末', done: true, cert: null },
      { id: 13, label: '把《计算机应用技术专业对口岗位表》读一遍', done: true, cert: null }
    ]
  },
  {
    id: 2,
    name: '大一下 · 能独立跑起一个小项目',
    period: '2026-02 ~ 2026-07',
    status: 'done',
    desc: '目标：从「会语法」到「能做出东西」，把数据库接上。',
    steps: [
      { id: 21, label: 'MySQL 建库建表，写完增删改查', done: true, cert: null },
      { id: 22, label: '用 Git 管一个自己的仓库', done: true, cert: null },
      { id: 23, label: '做完一个课程项目，写清楚 README', done: true, cert: '校内程序设计实训' }
    ]
  },
  {
    id: 3,
    name: '大二上 · 定方向，开始攒作品',
    period: '2026-09 ~ 2027-01',
    status: 'doing',
    desc: '目标：后端或前端选一个，别再摇摆；作品能发链接给人看。',
    steps: [
      { id: 31, label: '选定后端或前端方向，停掉另一个', done: true, cert: null },
      { id: 32, label: '刷 50 道基础面试题（数据结构 + SQL）', done: false, cert: null },
      { id: 33, label: '做一份能演示的作品集，部署上线', done: false, cert: '省级职业院校技能大赛（软件类）' }
    ]
  },
  {
    id: 4,
    name: '大二下 · 专插本还是就业，二选一',
    period: '2027-02 ~ 2027-07',
    status: 'todo',
    desc: '目标：把选择落到具体动作上，而不是一直想着。',
    steps: [
      { id: 41, label: '确认专插本目标院校与考试科目（或确认放弃）', done: false, cert: null },
      { id: 42, label: '选就业：开始投第一份实习', done: false, cert: null },
      { id: 43, label: '更新简历，投 10 家看回音', done: false, cert: '1+X Web 前端开发（初级）' }
    ]
  }
]"""),
    'skills': js("""[
  { name: 'SQL 与数据库设计', score: 70, tip: '能建表写查询，建议补一次索引与慢查询的练习' },
  { name: '一门后端语言（Java）', score: 55, tip: '语法够用，缺的是把接口和数据库串起来的完整项目' },
  { name: '项目表达与简历', score: 30, tip: '还没写过项目介绍，先把大一下那个项目写成 5 行' }
]"""),
}
d['refs'] = {}
d['computed'] = {}
d['reactives'] = {}
d['methods'] = {
    'getStatusLabel': fn("""(status) => {
  if (status === 'done') return '已完成';
  if (status === 'doing') return '进行中';
  return '待开始';
}"""),
    'getStatusType': fn("""(status) => {
  if (status === 'done') return 'success';
  if (status === 'doing') return 'primary';
  return 'info';
}"""),
    'toggleStep': fn("""(step) => {
  step.done = !step.done;
  const all = this.state.phases.reduce((acc, ph) => acc.concat(ph.steps), []);
  this.state.completedSteps = all.filter((s) => s.done).length;
  this.state.totalSteps = all.length;
  this.state.overallProgress = Math.round(
    (this.state.completedSteps / this.state.totalSteps) * 100
  );
}"""),
    'handleExportPlan': fn("() => {\n  this.$message.success('已生成可打印的路线图（演示环境不落盘）');\n}"),
    'handleRefreshPlan': fn("() => {\n  this.$message.info('重新生成需要先完成「认识自己」的 12 道自评');\n}"),
}

set_text(root, 'growth-desc', '目标拆到学期：每学期一句话、几件能勾的事、对应的证书或比赛。勾选只存在这台设备上。')

# 目标一句话卡片，插在 overview-card 之后
goal_card = div('goal-card', [
    span('目标一句话', cls='goal-label'),
    span(expr='this.state.goalSentence', cls='goal-text'),
])
kids = root['children']
oi = next(i for i, c in enumerate(kids) if (c.get('props') or {}).get('class') == 'overview-card')
kids.insert(oi + 1, goal_card)

# 任务行加勾选交互
for node in vtj.walk(root):
    cls = (node.get('props') or {}).get('class')
    if cls == 'step-item':
        node['props'] = dict(node.get('props') or {})
        node['props']['class'] = js("Object.assign({ 'step-item': true }, { done: this.context.step.done })")
        node['events'] = {'click': {'name': 'click', 'handler': js('this.toggleStep(this.context.step)'), 'modifiers': {}}}
        node['directives'] = node.get('directives') or []

# 按钮文案
for node in vtj.walk(root):
    if node.get('name') == 'ElButton' and node.get('children') == '重新生成计划':
        node['children'] = '按自评结果重排'

vtj.add_css(d, """
.goal-card {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  background: #eef3fe;
  border: 1px solid #d8e3ff;
  border-radius: 10px;
  padding: 12px 16px;
  margin-bottom: 12px;
}
.goal-label { flex-shrink: 0; font-size: 12px; color: #2f6bff; font-weight: 600; }
.goal-text { font-size: 13px; line-height: 1.8; color: #1f2937; }
.step-item { cursor: pointer; }
.step-item .step-text { transition: color .15s ease; }
.step-item.done .step-text { color: #9ca3af; text-decoration: line-through; }
""")
vtj.save(NAME, d)
print('plan ok')

# ================= 知识库 =================
NAME = 'nr0dxtni'
d = vtj.load(NAME)
root = d['nodes'][0]

DOCS = [
    ('计算机应用技术专业对口岗位表', 'A 专业与岗位', '列出本专业 12 个对口岗位、能力项与学历要求，含本校近两届去向。', 46, '2025-03-08'),
    ('电子商务专业对口岗位表', 'A 专业与岗位', '电商运营、跨境电商、客服主管三类岗位的能力项与起薪样本。', 38, '2025-03-09'),
    ('高职学生成长路线图模板', 'A 专业与岗位', '按学期拆任务的模板，含目标一句话、任务清单、证书挂载位置。', 31, '2025-03-05'),
    ('专插本考试科目说明（校内整理）', 'B 证书与考试', '公共课与专业基础课的科目构成，注明以省考试院当年通知为准。', 27, '2025-02-28'),
    ('1+X Web 前端开发（初级）考核要求', 'B 证书与考试', '考核模块、实操时长与通过标准，附备考顺序建议。', 22, '2025-02-26'),
    ('全国计算机等级考试二级说明', 'B 证书与考试', '考试科目、报名时间窗口与常见误区。', 19, '2025-02-24'),
    ('Java 后端开发岗位能力清单', 'C 岗位与能力', '7 项要求逐条拆解：语法、数据库、Git、Linux、框架、接口联调、排错。', 35, '2025-03-07'),
    ('Web 前端开发岗位能力清单', 'C 岗位与能力', '页面还原、交互、接口对接三层能力项，附作品集建议。', 33, '2025-03-07'),
    ('软件测试岗位能力清单', 'C 岗位与能力', '用例设计、缺陷管理、回归流程，对算法要求较低。', 24, '2025-03-06'),
    ('2024 届毕业生就业质量回收样本', 'D 行业与就业数据', '本校 213 条回收样本的岗位分布、起薪区间与专业对口率。', 58, '2025-01-15'),
    ('珠三角中小软件企业招聘观察', 'D 行业与就业数据', '近 12 个月招聘要求变化，专科可投岗位占比。', 21, '2025-03-02'),
    ('求职简历撰写与面试表达', 'E 求职技能', '无实习经历时的简历写法，附 20 个结构化面试常见问题。', 41, '2025-03-06'),
    ('结构化面试常见问题（20 题）', 'E 求职技能', '按「动机 / 经历 / 复盘 / 规划」四类归好的问题与回答框架。', 29, '2025-03-04'),
]

rows = []
for i, (title, cat, summary, cit, date) in enumerate(DOCS, 1):
    rows.append("""  {
    id: %d,
    title: '%s',
    category: '%s',
    summary: '%s',
    citations: %d,
    updatedAt: '%s'
  }""" % (i, title, cat, summary, cit, date))
d['state']['docs'] = js('[\n' + ',\n'.join(rows) + '\n]')

set_text(root, 'kb-desc', 'A–E 五组共 37 篇。对话里的回答只能引这里的内容，没有的就是没有。')

sel = vtj.find(root, 'kb-select')
sel['children'] = [el('ElOption', None, [], frm='element-plus', props={'label': x, 'value': x}) for x in
                   ['全部', 'A 专业与岗位', 'B 证书与考试', 'C 岗位与能力', 'D 行业与就业数据', 'E 求职技能']]

d['methods']['getTagType'] = fn("""(category) => {
  const map = {
    'A 专业与岗位': 'primary',
    'B 证书与考试': 'warning',
    'C 岗位与能力': 'success',
    'D 行业与就业数据': 'info',
    'E 求职技能': 'danger'
  };
  return map[category] || 'info';
}""")

# 头部加一行统计
hdr = vtj.find(root, 'kb-header')
if hdr is not None:
    hdr['children'].append(el('div', 'kb-stat', text='37 篇 · 5 组 · 最近更新 2025-03-09'))

vtj.add_css(d, """
.kb-stat {
  margin: 6px 0 0;
  font-size: 11.5px;
  color: #9ca3af;
}
""")
vtj.save(NAME, d)
print('kb ok')

# ================= 调用日志 =================
NAME = 'wr0ea12x'
d = vtj.load(NAME)
root = d['nodes'][0]

LOGS = [
    ('2025-03-13 10:32:18', '李同学', '专插本报名要什么条件', 'W-M1 升学政策', 'A 组 ×2', '只查不改 · 通过', '正常'),
    ('2025-03-13 10:31:05', '陈同学', '计算机应用技术能去哪些岗位', 'W-M1 职业认知', 'C 组 ×2 · D 组 ×1', '删 1 条无出处', '正常'),
    ('2025-03-13 10:29:47', '王同学', '跨境电商薪资多少', 'W-M1 职业认知', 'D 组 (样本 4)', '降级为未覆盖', '未覆盖兜底'),
    ('2025-03-13 10:28:33', '李同学', '大一该先准备什么', 'W-M1 成长计划', 'A 组 ×2 · C 组 ×1', '只查不改 · 通过', '正常'),
    ('2025-03-13 10:15:12', '刘同学', '考编要考什么科目', 'W-M1 升学政策', '—', '短路 · 未检索', '未覆盖兜底'),
    ('2025-03-13 09:58:40', '张同学', '不想读了，觉得没意义', 'W-L0 安全熔断', '—', '短路 · 转人工', '安全熔断'),
    ('2025-03-13 09:45:03', '陈同学', '简历没项目经历怎么写', 'W-M1 求职技能', 'E 组 ×2', '只查不改 · 通过', '正常'),
    ('2025-03-13 09:30:27', '王同学', '这个专业是不是没前途', 'W-M1 职业认知', '—', '拦截 · 无出处', '无出处拦截'),
]
rows = []
for i, (t, u, q, it, g, v, st) in enumerate(LOGS, 1):
    rows.append("""  {
    id: %d,
    time: '%s',
    user: '%s',
    question: '%s',
    intent: '%s',
    groups: '%s',
    verdict: '%s',
    status: '%s'
  }""" % (i, t, u, q, it, g, v, st))
d['state']['logs'] = js('[\n' + ',\n'.join(rows) + '\n]')
d['state']['todayCount'] = js('128')
d['state']['blockedCount'] = js('9')

set_text(root, 'logs-desc', '教师侧 · 学生不可见。看每次回答走了哪条链路、命中几篇、终审删了什么。')
for node in vtj.walk(root):
    if node.get('name') == 'ElTableColumn':
        pr = node.get('props') or {}
        if pr.get('prop') == 'session':
            pr['prop'] = 'question'
            pr['label'] = '学生的问题'
            pr['min-width'] = '180'
        elif pr.get('prop') == 'sources':
            pr['prop'] = 'groups'
            pr['label'] = '命中分组'
        elif pr.get('prop') == 'tokens':
            pr['prop'] = 'verdict'
            pr['label'] = '终审 V1.1'
            pr['min-width'] = '130'
        elif pr.get('prop') == 'intent':
            pr['label'] = 'W-M1 意图'
# 知识命中率改成 62%
for node in vtj.walk(root):
    if (node.get('props') or {}).get('class') == 'summary-value' and node.get('children') == '87%':
        node['children'] = '62%'
# 顶部教师标注
hdr = vtj.find(root, 'logs-header')
if hdr is not None:
    hdr['children'].insert(0, el('div', 'side-note', text='教师侧 · 学生不可见'))
vtj.add_css(d, """
.side-note {
  display: inline-block;
  margin-bottom: 8px;
  padding: 2px 8px;
  border-radius: 4px;
  background: #f3f4f6;
  color: #6b7280;
  font-size: 11px;
}
""")
vtj.save(NAME, d)
print('logs ok')

# ================= 知识库管理 =================
NAME = 'zr0eap34'
d = vtj.load(NAME)
root = d['nodes'][0]

DOCS = [
    ('计算机应用技术专业对口岗位表', 'A 专业与岗位', '王老师', 'C 组岗位调研', '已发布', '2025-03-08 16:20:08'),
    ('电子商务专业对口岗位表', 'A 专业与岗位', '李老师', '企业访谈整理', '已发布', '2025-03-09 14:32:45'),
    ('专插本考试科目说明（校内整理）', 'B 证书与考试', '张老师', '教务处整理', '已发布', '2025-02-28 09:12:31'),
    ('1+X Web 前端开发（初级）考核要求', 'B 证书与考试', '刘老师', '证书管理中心', '待审核', '2025-03-13 08:45:22'),
    ('2024 届毕业生就业质量回收样本', 'D 行业与就业数据', '陈老师', '就业质量报告', '已发布', '2025-01-15 10:05:14'),
    ('珠三角中小软件企业招聘观察', 'D 行业与就业数据', '赵老师', '招聘平台观测', '待审核', '2025-03-13 09:12:56'),
    ('求职简历撰写与面试表达', 'E 求职技能', '孙老师', '就业指导中心', '已驳回', '2025-03-12 17:48:56'),
    ('Java 后端开发岗位能力清单', 'C 岗位与能力', '周老师', '岗位拆解（缺 source 字段）', '待审核', '2025-03-13 10:02:49'),
]
rows = []
for i, (t, c, u, s, st, ua) in enumerate(DOCS, 1):
    rows.append("""  {
    id: %d,
    title: '%s',
    category: '%s',
    uploader: '%s',
    source: '%s',
    status: '%s',
    updatedAt: '%s'
  }""" % (i, t, c, u, s, st, ua))
d['state']['docs'] = js('[\n' + ',\n'.join(rows) + '\n]')

set_text(root, 'km-desc', '教师侧 · 学生不可见。上传后必须过 front-matter 校验（title / group / source / effective_date），缺一项就驳回。')

sel = vtj.find(root, 'km-select')
if sel is not None:
    sel['children'] = [el('ElOption', None, [], frm='element-plus', props={'label': x, 'value': x}) for x in
                       ['全部', 'A 专业与岗位', 'B 证书与考试', 'C 岗位与能力', 'D 行业与就业数据', 'E 求职技能']]

for node in vtj.walk(root):
    txt = node.get('children')
    if txt == '仅支持 .md / .txt / .pdf，须包含 front-matter 必填字段':
        node['children'] = '仅支持 .md / .txt / .pdf；front-matter 必填 title / group / source / effective_date'
    if txt == '提交校验':
        node['children'] = '提交校验'

hdr = vtj.find(root, 'km-header')
if hdr is not None:
    hdr['children'].insert(0, el('div', 'side-note', text='教师侧 · 学生不可见'))

vtj.add_css(d, """
.side-note {
  display: inline-block;
  margin-bottom: 8px;
  padding: 2px 8px;
  border-radius: 4px;
  background: #f3f4f6;
  color: #6b7280;
  font-size: 11px;
}
""")
vtj.save(NAME, d)
print('admin ok')
