# -*- coding: utf-8 -*-
"""m4：右栏 —— 滑动页签指示条、来源卡可点复制、逐条入场"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import vtj
from vtj import el, div, span, js, fn

d = vtj.load('br0cz38c')

d['refs']['activeIndex'] = js('0')
d['computed']['activeIndex'] = fn(
    "() => {\n"
    "  const i = this.tabs.value.findIndex((t) => t.key === this.activeTab.value);\n"
    "  return i < 0 ? 0 : i;\n"
    "}"
)
d['refs'].pop('activeIndex', None)

names = [e['name'] for e in d['emits']]
if 'copy' not in names:
    d['emits'].append({'name': 'copy', 'params': []})

d['methods']['handleCopy'] = fn(
    "(item) => {\n  try { this.$emit('copy', item); } catch (e) {}\n}"
)

root = d['nodes'][0]
head = vtj.find(root, 'tab-header')
head['children'].append(
    span(
        cls='tab-indicator',
        props={'style': js("'transform: translateX(' + (this.activeIndex.value * 100) + '%)'")},
    )
)

# 来源卡：可点 + 依次入场
card = vtj.find(root, 'ref-card')
card['props']['style'] = js("'animation-delay: ' + (this.context.index * 60) + 'ms'")
card['events']['click'] = {
    'name': 'click',
    'handler': js('this.handleCopy(this.context.item)'),
    'modifiers': {},
}

kb = vtj.find(root, 'kb-card')
if kb is not None:
    kb['props']['style'] = js("'animation-delay: ' + (this.context.index * 50) + 'ms'")

# 标题补一句引导
for n in vtj.walk(root):
    if n.get('props', {}).get('class') == 'section-title' and n.get('children') == '本次来源':
        n['children'] = '本次来源 · 点一条可复制引用'

vtj.save('br0cz38c', d)
print('br0cz38c ok')
